import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { pangatStore } from './server/store';
import { dispatchWhatsAppSmsNotification } from './server/notifications';
import type { BookingStatus, MealSession, MenuCategory, RegionalCuisine, SeatingPreference, SpiceLevel } from './src/types';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const VALID_SESSIONS: MealSession[] = ['Breakfast / Nashta', 'Lunch', 'Evening Snacks', 'Dinner'];
const VALID_SEATING: SeatingPreference[] = [
  'Indoor AC',
  'Outdoor Patio',
  'Family Booth',
  'Traditional Baithak Seating',
];
const VALID_STATUSES: BookingStatus[] = ['Confirmed', 'Seated', 'Completed', 'Cancelled'];
const VALID_CATEGORIES: MenuCategory[] = [
  'Starters & Farsan',
  'Special Thalis',
  'Main Course',
  'Breads (Bhakri/Poli)',
  'Desserts',
  'Beverages (Solkadhi/Piyush/Taak)',
];
const VALID_CUISINES: RegionalCuisine[] = [
  'Malvani & Konkani',
  'Kolhapuri',
  'Varhadi & Nagpuri',
  'Puneri & Deshastha',
  'Khandeshi & Marathwada',
];

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '1mb' }));

  // Serve public/ assets (including generated showcase video)
  app.use(express.static(path.resolve(__dirname, 'public')));

  // --- Restaurant Discovery API ---
  app.get('/api/restaurants', (req, res) => {
    const city = typeof req.query.city === 'string' ? req.query.city : undefined;
    const cuisine = typeof req.query.cuisine === 'string' ? req.query.cuisine : undefined;
    const q = typeof req.query.q === 'string' ? req.query.q : undefined;
    const pureVeg = req.query.pureVeg === 'true';

    const restaurants = pangatStore.listRestaurants({ city, cuisine, q, pureVeg });
    res.json({ restaurants });
  });

  app.get('/api/restaurants/:id', (req, res) => {
    const restaurant = pangatStore.getRestaurantById(req.params.id);
    if (!restaurant) {
      res.status(404).json({ error: 'Restaurant not found.' });
      return;
    }
    res.json({ restaurant });
  });

  app.post('/api/restaurants/:id/reviews', (req, res) => {
    const { author, city, rating, comment, orderedDish } = req.body ?? {};
    if (
      typeof author !== 'string' ||
      !author.trim() ||
      typeof comment !== 'string' ||
      !comment.trim() ||
      typeof rating !== 'number' ||
      rating < 1 ||
      rating > 5
    ) {
      res.status(400).json({ error: 'Please provide your name, rating (1-5), and review comment.' });
      return;
    }

    const updated = pangatStore.addReview(req.params.id, {
      author: author.trim().slice(0, 80),
      city: typeof city === 'string' && city.trim() ? city.trim().slice(0, 60) : 'Maharashtra',
      rating: Math.round(rating * 10) / 10,
      comment: comment.trim().slice(0, 500),
      orderedDish:
        typeof orderedDish === 'string' && orderedDish.trim()
          ? orderedDish.trim().slice(0, 100)
          : 'Special Thali',
    });

    if (!updated) {
      res.status(404).json({ error: 'Restaurant not found.' });
      return;
    }
    res.status(201).json({ restaurant: updated });
  });

  // --- Slot Availability & Atomic Soft-Locking API ---
  app.get('/api/slots', (req, res) => {
    const restaurantId = typeof req.query.restaurantId === 'string' ? req.query.restaurantId : '';
    const date = typeof req.query.date === 'string' ? req.query.date : '';
    const session = typeof req.query.session === 'string' ? (req.query.session as MealSession) : 'Lunch';

    if (!restaurantId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !VALID_SESSIONS.includes(session)) {
      res.status(400).json({ error: 'Valid restaurantId, YYYY-MM-DD date, and meal session are required.' });
      return;
    }

    const slots = pangatStore.getSlotAvailability(restaurantId, date, session);
    if (!slots) {
      res.status(404).json({ error: 'Restaurant not found.' });
      return;
    }
    res.json({ slots });
  });

  app.post('/api/bookings/lock', async (req, res) => {
    const { restaurantId, date, session, time, guests, seatingPreference } = req.body ?? {};
    const guestCount = Number(guests);

    if (
      typeof restaurantId !== 'string' ||
      typeof date !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
      !VALID_SESSIONS.includes(session) ||
      typeof time !== 'string' ||
      !Number.isInteger(guestCount) ||
      guestCount < 1 ||
      guestCount > 16 ||
      !VALID_SEATING.includes(seatingPreference)
    ) {
      res.status(400).json({ error: 'Invalid reservation slot parameters.' });
      return;
    }

    const result = await pangatStore.acquireSlotLock({
      restaurantId,
      date,
      session,
      time,
      guests: guestCount,
      seatingPreference,
    });

    if (result.error) {
      res.status(result.statusCode ?? 409).json({ error: result.error });
      return;
    }
    res.status(201).json({ lock: result.lock });
  });

  app.post('/api/bookings/release', async (req, res) => {
    const { lockId } = req.body ?? {};
    if (typeof lockId !== 'string' || !lockId.trim()) {
      res.status(400).json({ error: 'lockId is required.' });
      return;
    }
    const released = await pangatStore.releaseSlotLock(lockId);
    res.json({ released });
  });

  app.post('/api/bookings/confirm', async (req, res) => {
    const { lockId, guestName, guestPhone, specialRequests, notifyWhatsAppSms } = req.body ?? {};
    const cleanPhone = typeof guestPhone === 'string' ? guestPhone.replace(/\D/g, '') : '';

    if (
      typeof lockId !== 'string' ||
      !lockId.trim() ||
      typeof guestName !== 'string' ||
      guestName.trim().length < 2 ||
      cleanPhone.length < 10
    ) {
      res.status(400).json({ error: 'Valid lockId, guest name, and 10-digit mobile number are required.' });
      return;
    }

    const result = await pangatStore.confirmBooking({
      lockId: lockId.trim(),
      guestName: guestName.trim().slice(0, 80),
      guestPhone: `+91${cleanPhone.slice(-10)}`,
      specialRequests: typeof specialRequests === 'string' ? specialRequests.slice(0, 240) : '',
      notifyWhatsAppSms: Boolean(notifyWhatsAppSms),
    });

    if (result.error) {
      res.status(result.statusCode ?? 400).json({ error: result.error });
      return;
    }
    res.status(201).json({ booking: result.booking });
  });

  // --- Modular WhatsApp/SMS Notification Webhook Endpoint ---
  app.post('/api/notifications/whatsapp-sms', async (req, res) => {
    const { bookingId, event } = req.body ?? {};
    if (typeof bookingId !== 'string' || !bookingId.trim()) {
      res.status(400).json({ error: 'bookingId is required.' });
      return;
    }
    const booking = pangatStore.listBookings().find((b) => b.bookingId === bookingId);
    if (!booking) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    const notifEvent = event === 'booking.reminder_2h' ? 'booking.reminder_2h' : 'booking.confirmed';
    const payload = await dispatchWhatsAppSmsNotification(booking, notifEvent);
    res.json({ notification: payload });
  });

  // --- My Bookings API ---
  app.get('/api/bookings', (req, res) => {
    const restaurantId = typeof req.query.restaurantId === 'string' ? req.query.restaurantId : undefined;
    const bookings = pangatStore.listBookings(restaurantId);
    res.json({ bookings });
  });

  app.patch('/api/bookings/:bookingId', async (req, res) => {
    const { guests, time, session, date, seatingPreference } = req.body ?? {};
    const updates: {
      guests?: number;
      time?: string;
      session?: MealSession;
      date?: string;
      seatingPreference?: SeatingPreference;
    } = {};

    if (guests !== undefined) {
      const n = Number(guests);
      if (!Number.isInteger(n) || n < 1 || n > 16) {
        res.status(400).json({ error: 'Guests must be between 1 and 16.' });
        return;
      }
      updates.guests = n;
    }
    if (date !== undefined) {
      if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        res.status(400).json({ error: 'Invalid date format.' });
        return;
      }
      updates.date = date;
    }
    if (session !== undefined) {
      if (!VALID_SESSIONS.includes(session)) {
        res.status(400).json({ error: 'Invalid meal session.' });
        return;
      }
      updates.session = session;
    }
    if (time !== undefined) {
      if (typeof time !== 'string' || !time.trim()) {
        res.status(400).json({ error: 'Invalid time slot.' });
        return;
      }
      updates.time = time.trim();
    }
    if (seatingPreference !== undefined) {
      if (!VALID_SEATING.includes(seatingPreference)) {
        res.status(400).json({ error: 'Invalid seating preference.' });
        return;
      }
      updates.seatingPreference = seatingPreference;
    }

    const result = await pangatStore.modifyBooking(req.params.bookingId, updates);
    if (result.error) {
      res.status(result.statusCode ?? 400).json({ error: result.error });
      return;
    }
    res.json({ booking: result.booking });
  });

  app.post('/api/bookings/:bookingId/cancel', async (req, res) => {
    const result = await pangatStore.cancelBooking(req.params.bookingId);
    if (result.error) {
      res.status(result.statusCode ?? 404).json({ error: result.error });
      return;
    }
    res.json({ booking: result.booking });
  });

  // --- Restaurant Partner Dashboard API ---
  app.get('/api/partner/overview', (req, res) => {
    const restaurantId = typeof req.query.restaurantId === 'string' ? req.query.restaurantId : undefined;
    const bookings = pangatStore.listBookings(restaurantId);
    const activeLocks = pangatStore.getActiveLocks(restaurantId);
    const menuItems = pangatStore.getMenuItems(restaurantId);
    res.json({ bookings, activeLocks, menuItems });
  });

  app.patch('/api/partner/bookings/:bookingId/status', (req, res) => {
    const { status } = req.body ?? {};
    if (!VALID_STATUSES.includes(status)) {
      res.status(400).json({ error: 'Invalid booking status.' });
      return;
    }
    const updated = pangatStore.updateBookingStatus(req.params.bookingId, status);
    if (!updated) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    res.json({ booking: updated });
  });

  app.patch('/api/partner/menu/:itemId', (req, res) => {
    const { in_stock, price, spice_level, is_chefs_special, description, name } = req.body ?? {};
    const patch: {
      in_stock?: boolean;
      price?: number;
      spice_level?: SpiceLevel;
      is_chefs_special?: boolean;
      description?: string;
      name?: string;
    } = {};

    if (typeof in_stock === 'boolean') patch.in_stock = in_stock;
    if (typeof price === 'number' && price > 0) patch.price = Math.round(price);
    if ([1, 2, 3, 4].includes(spice_level)) patch.spice_level = spice_level as SpiceLevel;
    if (typeof is_chefs_special === 'boolean') patch.is_chefs_special = is_chefs_special;
    if (typeof description === 'string' && description.trim()) patch.description = description.trim().slice(0, 300);
    if (typeof name === 'string' && name.trim()) patch.name = name.trim().slice(0, 120);

    const updated = pangatStore.updateMenuItem(req.params.itemId, patch);
    if (!updated) {
      res.status(404).json({ error: 'Menu item not found.' });
      return;
    }
    res.json({ item: updated });
  });

  app.post('/api/partner/menu', (req, res) => {
    const {
      restaurantId,
      name,
      marathiName,
      category,
      description,
      price,
      dietary,
      jain_friendly,
      is_thali,
      thali_type,
      thali_components,
      regional_style,
      spice_level,
      is_chefs_special,
    } = req.body ?? {};

    const numPrice = Number(price);
    const spice = Number(spice_level);
    if (
      typeof restaurantId !== 'string' ||
      !pangatStore.getRestaurantById(restaurantId) ||
      typeof name !== 'string' ||
      !name.trim() ||
      !VALID_CATEGORIES.includes(category) ||
      typeof description !== 'string' ||
      !description.trim() ||
      !Number.isFinite(numPrice) ||
      numPrice <= 0 ||
      (dietary !== 'Pure Veg' && dietary !== 'Non-Veg') ||
      !VALID_CUISINES.includes(regional_style) ||
      ![1, 2, 3, 4].includes(spice)
    ) {
      res.status(400).json({ error: 'Please provide valid dish name, restaurant, category, price, and spice level.' });
      return;
    }

    const components = Array.isArray(thali_components)
      ? thali_components.filter((c): c is string => typeof c === 'string' && c.trim().length > 0).map((c) => c.trim())
      : undefined;

    const item = pangatStore.addMenuItem({
      restaurantId,
      name: name.trim().slice(0, 120),
      marathiName: typeof marathiName === 'string' ? marathiName.trim().slice(0, 120) : undefined,
      category,
      description: description.trim().slice(0, 300),
      price: Math.round(numPrice),
      dietary,
      jain_friendly: Boolean(jain_friendly),
      is_thali: Boolean(is_thali),
      thali_type: Boolean(is_thali) ? (thali_type === 'Limited' ? 'Limited' : 'Unlimited') : undefined,
      thali_components: Boolean(is_thali) && components && components.length > 0 ? components : undefined,
      regional_style,
      spice_level: spice as SpiceLevel,
      is_chefs_special: Boolean(is_chefs_special),
      in_stock: true,
    });

    res.status(201).json({ item });
  });

  // --- Vite Middleware in Development / Static Build in Production ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pangat server running on http://localhost:${PORT}`);
  });
}

startServer();
