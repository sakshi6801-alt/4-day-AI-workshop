import type {
  Booking,
  BookingStatus,
  CityHub,
  MealSession,
  MenuItem,
  Restaurant,
  RestaurantWithMenu,
  Review,
  SeatingPreference,
  SlotLock,
  TimeSlotAvailability,
} from '../src/types';
import { SEED_MENU_ITEMS, SEED_RESTAURANTS } from './seedData';
import { buildWhatsAppMessage, dispatchWhatsAppSmsNotification } from './notifications';

export const SESSION_TIME_SLOTS: Record<MealSession, string[]> = {
  'Breakfast / Nashta': ['08:30 AM', '09:30 AM', '10:30 AM'],
  Lunch: ['12:00 PM', '12:45 PM', '01:30 PM', '02:15 PM'],
  'Evening Snacks': ['04:30 PM', '05:30 PM', '06:15 PM'],
  Dinner: ['07:15 PM', '08:00 PM', '08:45 PM', '09:30 PM'],
};

const CITY_CODES: Record<CityHub, string> = {
  Mumbai: 'MUM',
  Pune: 'PUN',
  Nagpur: 'NAG',
  Nashik: 'NSK',
  Kolhapur: 'KOL',
  'Chhatrapati Sambhajinagar': 'CSN',
  Satara: 'SAT',
};

const LOCK_TTL_MS = 5 * 60 * 1000; // 5-minute soft lock

function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

class PangatStore {
  private restaurants: Restaurant[] = structuredClone(SEED_RESTAURANTS);
  private menuItems: MenuItem[] = structuredClone(SEED_MENU_ITEMS);
  private locks: Map<string, SlotLock> = new Map();
  private bookings: Booking[] = [];
  private mutexQueue: Promise<unknown> = Promise.resolve();

  constructor() {
    this.seedInitialBookings();
  }

  private seedInitialBookings() {
    const today = getTodayDateString();
    const initialSamples: Array<Omit<Booking, 'notification'>> = [
      {
        bookingId: 'PNG-PUN-8492',
        restaurantId: 'peshwai-pangat',
        restaurantName: 'Peshwai Pangat',
        restaurantCity: 'Pune',
        restaurantLocality: 'Sadashiv Peth',
        restaurantAddress: '412, Tilak Road, Near SP College, Sadashiv Peth, Pune 411030',
        mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Sadashiv+Peth+Pune+411030',
        date: today,
        session: 'Lunch',
        time: '01:30 PM',
        guests: 4,
        tablesAllocated: 1,
        seatingPreference: 'Traditional Baithak Seating',
        guestName: 'Aditi Chitale',
        guestPhone: '+919822045112',
        specialRequests: 'Celebrating grandmother’s 75th birthday, low seating preferred.',
        notifyWhatsAppSms: true,
        status: 'Confirmed',
        createdAt: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
      },
      {
        bookingId: 'PNG-KOL-3104',
        restaurantId: 'tambda-pandhra',
        restaurantName: 'Tambda Pandhra',
        restaurantCity: 'Kolhapur',
        restaurantLocality: 'Tarabai Park',
        restaurantAddress: 'Plot 18, Nagala Park Road, Tarabai Park, Kolhapur 416003',
        mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Tarabai+Park+Kolhapur+416003',
        date: today,
        session: 'Dinner',
        time: '08:00 PM',
        guests: 6,
        tablesAllocated: 1,
        seatingPreference: 'Family Booth',
        guestName: 'Omkar Patil',
        guestPhone: '+919765011223',
        specialRequests: 'Extra Pandhra Rassa bowl for kids.',
        notifyWhatsAppSms: true,
        status: 'Confirmed',
        createdAt: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
      },
      {
        bookingId: 'PNG-MUM-5218',
        restaurantId: 'sindhudurg-kinara',
        restaurantName: 'Sindhudurg Kinara',
        restaurantCity: 'Mumbai',
        restaurantLocality: 'Dadar West',
        restaurantAddress: '24, Ranade Road, Near Shivaji Park, Dadar West, Mumbai 400028',
        mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Dadar+West+Shivaji+Park+Mumbai+400028',
        date: today,
        session: 'Lunch',
        time: '12:45 PM',
        guests: 8,
        tablesAllocated: 2,
        seatingPreference: 'Indoor AC',
        guestName: 'Meera Tendulkar',
        guestPhone: '+919820199884',
        specialRequests: '2 Surmai Thalis, 1 Veg Kajuchi Usal.',
        notifyWhatsAppSms: true,
        status: 'Seated',
        createdAt: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
      },
    ];

    // Pre-fill a few realistic reservations on peak slots so users see "Only X Tables Left"
    const peakFillers: Array<{
      restaurantId: string;
      session: MealSession;
      time: string;
      tables: number;
      guestName: string;
      seating: SeatingPreference;
    }> = [
      {
        restaurantId: 'peshwai-pangat',
        session: 'Lunch',
        time: '01:30 PM',
        tables: 3,
        guestName: 'Kulkarni Family',
        seating: 'Traditional Baithak Seating',
      },
      {
        restaurantId: 'peshwai-pangat',
        session: 'Dinner',
        time: '08:00 PM',
        tables: 5,
        guestName: 'Joshi Group',
        seating: 'Indoor AC',
      },
      {
        restaurantId: 'tambda-pandhra',
        session: 'Dinner',
        time: '08:00 PM',
        tables: 4,
        guestName: 'Mane Group',
        seating: 'Family Booth',
      },
      {
        restaurantId: 'sindhudurg-kinara',
        session: 'Lunch',
        time: '01:30 PM',
        tables: 5,
        guestName: 'Sawant Family',
        seating: 'Indoor AC',
      },
    ];

    for (const sample of initialSamples) {
      this.bookings.push({
        ...sample,
        notification: {
          provider: 'gupshup-sms',
          event: 'booking.confirmed',
          bookingId: sample.bookingId,
          recipientPhone: sample.guestPhone,
          formattedWhatsAppMessage: buildWhatsAppMessage(sample),
          scheduledReminderAt: `${sample.date} (2h prior)`,
          dispatchedLive: false,
          dispatchedAt: sample.createdAt,
          webhookBody: {
            to: sample.guestPhone,
            channel: 'whatsapp',
            templateName: 'pangat_table_confirmation_v1',
            variables: {
              guest_name: sample.guestName,
              booking_id: sample.bookingId,
              restaurant_name: sample.restaurantName,
              date: sample.date,
              time: sample.time,
              guests: sample.guests,
              seating: sample.seatingPreference,
            },
            mapsPinUrl: sample.mapsUrl,
          },
        },
      });
    }

    peakFillers.forEach((filler, index) => {
      const rest = this.restaurants.find((r) => r.id === filler.restaurantId);
      if (!rest) return;
      this.bookings.push({
        bookingId: `PNG-${CITY_CODES[rest.city]}-${9100 + index}`,
        restaurantId: rest.id,
        restaurantName: rest.name,
        restaurantCity: rest.city,
        restaurantLocality: rest.locality,
        restaurantAddress: rest.address,
        mapsUrl: rest.mapsUrl,
        date: today,
        session: filler.session,
        time: filler.time,
        guests: filler.tables * 4,
        tablesAllocated: filler.tables,
        seatingPreference: filler.seating,
        guestName: filler.guestName,
        guestPhone: '+91980000010' + index,
        specialRequests: '',
        notifyWhatsAppSms: true,
        status: 'Confirmed',
        createdAt: new Date(Date.now() - 3600 * 1000).toISOString(),
      });
    });
  }

  private withMutex<T>(fn: () => Promise<T> | T): Promise<T> {
    const next = this.mutexQueue.then(() => fn());
    this.mutexQueue = next.catch(() => undefined);
    return next;
  }

  private pruneExpiredLocks(now = Date.now()) {
    for (const [id, lock] of this.locks.entries()) {
      if (lock.locked_until <= now) {
        this.locks.delete(id);
      }
    }
  }

  listRestaurants(filters?: {
    city?: string;
    cuisine?: string;
    q?: string;
    pureVeg?: boolean;
  }): RestaurantWithMenu[] {
    const query = filters?.q?.trim().toLowerCase() ?? '';
    return this.restaurants
      .filter((rest) => {
        if (filters?.city && filters.city !== 'All' && rest.city !== filters.city) {
          return false;
        }
        if (
          filters?.cuisine &&
          filters.cuisine !== 'All' &&
          !rest.regionalCuisines.includes(filters.cuisine as Restaurant['regionalCuisines'][number])
        ) {
          return false;
        }
        if (filters?.pureVeg && !rest.pureVeg) {
          return false;
        }
        if (query) {
          const restMenu = this.menuItems.filter((m) => m.restaurantId === rest.id);
          const matchesRest =
            rest.name.toLowerCase().includes(query) ||
            rest.city.toLowerCase().includes(query) ||
            rest.locality.toLowerCase().includes(query) ||
            rest.specialtyTag.toLowerCase().includes(query) ||
            rest.regionalCuisines.some((c) => c.toLowerCase().includes(query));
          const matchesDish = restMenu.some(
            (m) =>
              m.name.toLowerCase().includes(query) ||
              m.description.toLowerCase().includes(query) ||
              (m.thali_components?.some((tc) => tc.toLowerCase().includes(query)) ?? false)
          );
          if (!matchesRest && !matchesDish) return false;
        }
        return true;
      })
      .map((rest) => ({
        ...rest,
        menu: this.menuItems.filter((m) => m.restaurantId === rest.id),
      }));
  }

  getRestaurantById(id: string): RestaurantWithMenu | null {
    const rest = this.restaurants.find((r) => r.id === id);
    if (!rest) return null;
    return {
      ...rest,
      menu: this.menuItems.filter((m) => m.restaurantId === rest.id),
    };
  }

  addReview(restaurantId: string, review: Omit<Review, 'id' | 'date'>): RestaurantWithMenu | null {
    const rest = this.restaurants.find((r) => r.id === restaurantId);
    if (!rest) return null;
    const newReview: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      date: new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
    };
    rest.reviews.unshift(newReview);
    const totalScore = rest.rating * rest.reviewCount + review.rating;
    rest.reviewCount += 1;
    rest.rating = Number((totalScore / rest.reviewCount).toFixed(1));
    return this.getRestaurantById(restaurantId);
  }

  getSlotAvailability(
    restaurantId: string,
    date: string,
    session: MealSession
  ): TimeSlotAvailability[] | null {
    const rest = this.restaurants.find((r) => r.id === restaurantId);
    if (!rest) return null;

    this.pruneExpiredLocks();
    const times = SESSION_TIME_SLOTS[session] ?? [];

    return times.map((time) => {
      const bookedTables = this.bookings
        .filter(
          (b) =>
            b.restaurantId === restaurantId &&
            b.date === date &&
            b.session === session &&
            b.time === time &&
            b.status !== 'Cancelled'
        )
        .reduce((sum, b) => sum + b.tablesAllocated, 0);

      const lockedTables = Array.from(this.locks.values())
        .filter(
          (l) =>
            l.restaurantId === restaurantId &&
            l.date === date &&
            l.session === session &&
            l.time === time
        )
        .reduce((sum, l) => sum + l.tablesRequired, 0);

      const availableTables = Math.max(0, rest.totalTablesPerSlot - bookedTables - lockedTables);
      const status: TimeSlotAvailability['status'] =
        availableTables === 0 ? 'Sold Out' : availableTables <= 2 ? 'Limited' : 'Available';

      return {
        time,
        session,
        totalTables: rest.totalTablesPerSlot,
        bookedTables,
        lockedTables,
        availableTables,
        status,
      };
    });
  }

  async acquireSlotLock(input: {
    restaurantId: string;
    date: string;
    session: MealSession;
    time: string;
    guests: number;
    seatingPreference: SeatingPreference;
  }): Promise<{ lock?: SlotLock; error?: string; statusCode?: number }> {
    return this.withMutex(() => {
      const now = Date.now();
      this.pruneExpiredLocks(now);

      const rest = this.restaurants.find((r) => r.id === input.restaurantId);
      if (!rest) {
        return { error: 'Restaurant not found.', statusCode: 404 };
      }

      const validTimes = SESSION_TIME_SLOTS[input.session];
      if (!validTimes || !validTimes.includes(input.time)) {
        return { error: 'Invalid session or time slot.', statusCode: 400 };
      }

      if (!rest.seatingOptions.includes(input.seatingPreference)) {
        return { error: 'Selected seating preference is not offered at this restaurant.', statusCode: 400 };
      }

      const tablesRequired = Math.max(1, Math.ceil(input.guests / 6));
      const slots = this.getSlotAvailability(input.restaurantId, input.date, input.session);
      const targetSlot = slots?.find((s) => s.time === input.time);

      if (!targetSlot || targetSlot.availableTables < tablesRequired) {
        return {
          error:
            targetSlot?.availableTables === 0
              ? 'This time slot just sold out. Please select another slot.'
              : `Only ${targetSlot?.availableTables ?? 0} table(s) left for this slot, which cannot accommodate ${input.guests} guests.`,
          statusCode: 409,
        };
      }

      const lockId = `LCK-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
      const lock: SlotLock = {
        lockId,
        restaurantId: rest.id,
        restaurantName: rest.name,
        date: input.date,
        session: input.session,
        time: input.time,
        guests: input.guests,
        tablesRequired,
        seatingPreference: input.seatingPreference,
        createdAt: now,
        locked_until: now + LOCK_TTL_MS,
      };

      this.locks.set(lockId, lock);
      return { lock };
    });
  }

  async releaseSlotLock(lockId: string): Promise<boolean> {
    return this.withMutex(() => {
      return this.locks.delete(lockId);
    });
  }

  async confirmBooking(input: {
    lockId: string;
    guestName: string;
    guestPhone: string;
    specialRequests: string;
    notifyWhatsAppSms: boolean;
  }): Promise<{ booking?: Booking; error?: string; statusCode?: number }> {
    return this.withMutex(async () => {
      const now = Date.now();
      const lock = this.locks.get(input.lockId);
      if (!lock) {
        return {
          error: 'Table hold not found or already released. Please select your time slot again.',
          statusCode: 410,
        };
      }
      if (lock.locked_until <= now) {
        this.locks.delete(input.lockId);
        return {
          error: 'Your 5-minute table hold expired. The table has been released back to the pool.',
          statusCode: 410,
        };
      }

      const rest = this.restaurants.find((r) => r.id === lock.restaurantId);
      if (!rest) {
        this.locks.delete(input.lockId);
        return { error: 'Restaurant not found.', statusCode: 404 };
      }

      // Remove lock atomically as we convert to confirmed reservation
      this.locks.delete(input.lockId);

      const cityCode = CITY_CODES[rest.city] ?? 'MAH';
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      const bookingId = `PNG-${cityCode}-${randomNum}`;

      const baseBooking: Omit<Booking, 'notification'> = {
        bookingId,
        restaurantId: rest.id,
        restaurantName: rest.name,
        restaurantCity: rest.city,
        restaurantLocality: rest.locality,
        restaurantAddress: rest.address,
        mapsUrl: rest.mapsUrl,
        date: lock.date,
        session: lock.session,
        time: lock.time,
        guests: lock.guests,
        tablesAllocated: lock.tablesRequired,
        seatingPreference: lock.seatingPreference,
        guestName: input.guestName.trim(),
        guestPhone: input.guestPhone.trim(),
        specialRequests: input.specialRequests.trim(),
        notifyWhatsAppSms: input.notifyWhatsAppSms,
        status: 'Confirmed',
        createdAt: new Date(now).toISOString(),
      };

      const notification = input.notifyWhatsAppSms
        ? await dispatchWhatsAppSmsNotification(baseBooking, 'booking.confirmed')
        : undefined;

      const confirmed: Booking = {
        ...baseBooking,
        notification,
      };

      this.bookings.unshift(confirmed);
      return { booking: confirmed };
    });
  }

  listBookings(restaurantId?: string): Booking[] {
    if (restaurantId && restaurantId !== 'All') {
      return this.bookings.filter((b) => b.restaurantId === restaurantId);
    }
    return this.bookings;
  }

  async modifyBooking(
    bookingId: string,
    updates: {
      guests?: number;
      time?: string;
      session?: MealSession;
      date?: string;
      seatingPreference?: SeatingPreference;
    }
  ): Promise<{ booking?: Booking; error?: string; statusCode?: number }> {
    return this.withMutex(() => {
      const existing = this.bookings.find((b) => b.bookingId === bookingId);
      if (!existing) return { error: 'Booking not found.', statusCode: 404 };
      if (existing.status === 'Cancelled' || existing.status === 'Completed') {
        return { error: 'Cannot modify a cancelled or completed booking.', statusCode: 400 };
      }

      const rest = this.restaurants.find((r) => r.id === existing.restaurantId);
      if (!rest) return { error: 'Restaurant not found.', statusCode: 404 };

      const nextDate = updates.date ?? existing.date;
      const nextSession = updates.session ?? existing.session;
      const nextTime = updates.time ?? existing.time;
      const nextGuests = updates.guests ?? existing.guests;
      const nextSeating = updates.seatingPreference ?? existing.seatingPreference;
      const nextTables = Math.max(1, Math.ceil(nextGuests / 6));

      const validTimes = SESSION_TIME_SLOTS[nextSession];
      if (!validTimes || !validTimes.includes(nextTime)) {
        return { error: 'Invalid session or time slot.', statusCode: 400 };
      }

      this.pruneExpiredLocks();

      const otherBooked = this.bookings
        .filter(
          (b) =>
            b.bookingId !== bookingId &&
            b.restaurantId === rest.id &&
            b.date === nextDate &&
            b.session === nextSession &&
            b.time === nextTime &&
            b.status !== 'Cancelled'
        )
        .reduce((sum, b) => sum + b.tablesAllocated, 0);

      const locked = Array.from(this.locks.values())
        .filter(
          (l) =>
            l.restaurantId === rest.id &&
            l.date === nextDate &&
            l.session === nextSession &&
            l.time === nextTime
        )
        .reduce((sum, l) => sum + l.tablesRequired, 0);

      const remaining = rest.totalTablesPerSlot - otherBooked - locked;
      if (remaining < nextTables) {
        return {
          error: 'Insufficient tables available for the updated time or guest count.',
          statusCode: 409,
        };
      }

      existing.date = nextDate;
      existing.session = nextSession;
      existing.time = nextTime;
      existing.guests = nextGuests;
      existing.tablesAllocated = nextTables;
      existing.seatingPreference = nextSeating;

      return { booking: existing };
    });
  }

  async cancelBooking(bookingId: string): Promise<{ booking?: Booking; error?: string; statusCode?: number }> {
    return this.withMutex(() => {
      const existing = this.bookings.find((b) => b.bookingId === bookingId);
      if (!existing) return { error: 'Booking not found.', statusCode: 404 };
      existing.status = 'Cancelled';
      return { booking: existing };
    });
  }

  getActiveLocks(restaurantId?: string): SlotLock[] {
    this.pruneExpiredLocks();
    const all = Array.from(this.locks.values());
    if (restaurantId && restaurantId !== 'All') {
      return all.filter((l) => l.restaurantId === restaurantId);
    }
    return all;
  }

  updateBookingStatus(bookingId: string, status: BookingStatus): Booking | null {
    const existing = this.bookings.find((b) => b.bookingId === bookingId);
    if (!existing) return null;
    existing.status = status;
    return existing;
  }

  getMenuItems(restaurantId?: string): MenuItem[] {
    if (restaurantId && restaurantId !== 'All') {
      return this.menuItems.filter((m) => m.restaurantId === restaurantId);
    }
    return this.menuItems;
  }

  updateMenuItem(
    itemId: string,
    patch: Partial<Pick<MenuItem, 'in_stock' | 'price' | 'spice_level' | 'is_chefs_special' | 'description' | 'name'>>
  ): MenuItem | null {
    const item = this.menuItems.find((m) => m.id === itemId);
    if (!item) return null;
    if (typeof patch.in_stock === 'boolean') item.in_stock = patch.in_stock;
    if (typeof patch.price === 'number' && patch.price > 0) item.price = patch.price;
    if (patch.spice_level && [1, 2, 3, 4].includes(patch.spice_level)) item.spice_level = patch.spice_level;
    if (typeof patch.is_chefs_special === 'boolean') item.is_chefs_special = patch.is_chefs_special;
    if (typeof patch.description === 'string' && patch.description.trim()) item.description = patch.description.trim();
    if (typeof patch.name === 'string' && patch.name.trim()) item.name = patch.name.trim();
    return item;
  }

  addMenuItem(input: Omit<MenuItem, 'id'>): MenuItem {
    const newItem: MenuItem = {
      ...input,
      id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    };
    this.menuItems.unshift(newItem);
    return newItem;
  }
}

export const pangatStore = new PangatStore();
