import type { Booking, NotificationWebhookPayload } from '../src/types';

function isSafeWebhookUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return false;
    }
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '0.0.0.0' ||
      host === '::1' ||
      host === '169.254.169.254' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function buildWhatsAppMessage(booking: Omit<Booking, 'notification'>): string {
  return [
    `🙏 *Namaskar ${booking.guestName}! Your Pangat Table is Confirmed*`,
    ``,
    `*Booking ID:* ${booking.bookingId}`,
    `*Restaurant:* ${booking.restaurantName} (${booking.restaurantLocality}, ${booking.restaurantCity})`,
    `*Date & Time:* ${booking.date} · ${booking.time} (${booking.session})`,
    `*Guests:* ${booking.guests} ${booking.guests === 1 ? 'Guest' : 'Guests'}`,
    `*Seating:* ${booking.seatingPreference}`,
    booking.specialRequests ? `*Note:* ${booking.specialRequests}` : '',
    ``,
    `📍 *Google Maps Pin:* ${booking.mapsUrl}`,
    ``,
    `_We will send a gentle reminder 2 hours before your pangat begins._`,
  ]
    .filter((line, idx, arr) => !(line === '' && arr[idx - 1] === ''))
    .join('\n');
}

function computeReminderTime(dateStr: string, timeStr: string): string {
  try {
    const match = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i.exec(timeStr.trim());
    if (!match) return `${dateStr} (2h prior)`;
    let hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    const meridiem = match[3].toUpperCase();
    if (meridiem === 'PM' && hours !== 12) hours += 12;
    if (meridiem === 'AM' && hours === 12) hours = 0;

    const dt = new Date(`${dateStr}T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00+05:30`);
    if (Number.isNaN(dt.getTime())) return `${dateStr} (2h prior)`;
    dt.setHours(dt.getHours() - 2);
    return dt.toISOString();
  } catch {
    return `${dateStr} (2h prior)`;
  }
}

export async function dispatchWhatsAppSmsNotification(
  booking: Omit<Booking, 'notification'>,
  event: 'booking.confirmed' | 'booking.reminder_2h' = 'booking.confirmed'
): Promise<NotificationWebhookPayload> {
  const formattedWhatsAppMessage = buildWhatsAppMessage(booking);
  const scheduledReminderAt = computeReminderTime(booking.date, booking.time);
  const normalizedPhone = booking.guestPhone.startsWith('+')
    ? booking.guestPhone
    : `+91${booking.guestPhone.replace(/\D/g, '').slice(-10)}`;

  const hasTwilio = Boolean(
    process.env.TWILIO_ACCOUNT_SID &&
      process.env.TWILIO_AUTH_TOKEN &&
      process.env.TWILIO_WHATSAPP_FROM
  );
  const hasInterakt = Boolean(process.env.INTERAKT_API_KEY);
  const provider: NotificationWebhookPayload['provider'] = hasInterakt
    ? 'interakt-whatsapp'
    : hasTwilio
      ? 'twilio-whatsapp'
      : 'gupshup-sms';

  const payload: NotificationWebhookPayload = {
    provider,
    event,
    bookingId: booking.bookingId,
    recipientPhone: normalizedPhone,
    formattedWhatsAppMessage,
    scheduledReminderAt,
    dispatchedLive: false,
    dispatchedAt: new Date().toISOString(),
    webhookBody: {
      to: normalizedPhone,
      channel: 'whatsapp',
      templateName: 'pangat_table_confirmation_v1',
      variables: {
        guest_name: booking.guestName,
        booking_id: booking.bookingId,
        restaurant_name: booking.restaurantName,
        date: booking.date,
        time: booking.time,
        guests: booking.guests,
        seating: booking.seatingPreference,
      },
      mapsPinUrl: booking.mapsUrl,
    },
  };

  if (hasInterakt) {
    try {
      const response = await fetch('https://api.interakt.ai/v1/public/message/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Basic ${process.env.INTERAKT_API_KEY}`,
        },
        body: JSON.stringify({
          fullPhoneNumber: normalizedPhone,
          type: 'Template',
          template: {
            name: payload.webhookBody.templateName,
            languageCode: 'en',
            bodyValues: [
              booking.guestName,
              booking.bookingId,
              booking.restaurantName,
              `${booking.date} ${booking.time}`,
              String(booking.guests),
              booking.seatingPreference,
            ],
          },
        }),
      });
      payload.dispatchedLive = response.ok;
    } catch {
      payload.dispatchedLive = false;
    }
  } else if (hasTwilio) {
    try {
      const sid = process.env.TWILIO_ACCOUNT_SID as string;
      const token = process.env.TWILIO_AUTH_TOKEN as string;
      const from = process.env.TWILIO_WHATSAPP_FROM as string;
      const params = new URLSearchParams({
        From: from.startsWith('whatsapp:') ? from : `whatsapp:${from}`,
        To: `whatsapp:${normalizedPhone}`,
        Body: formattedWhatsAppMessage,
      });
      const response = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`,
        {
          method: 'POST',
          headers: {
            Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString(),
        }
      );
      payload.dispatchedLive = response.ok;
    } catch {
      payload.dispatchedLive = false;
    }
  } else if (process.env.WHATSAPP_WEBHOOK_URL && isSafeWebhookUrl(process.env.WHATSAPP_WEBHOOK_URL)) {
    try {
      const response = await fetch(process.env.WHATSAPP_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      payload.dispatchedLive = response.ok;
    } catch {
      payload.dispatchedLive = false;
    }
  }

  return payload;
}
