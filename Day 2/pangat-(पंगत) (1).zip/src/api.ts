import type {
  Booking,
  BookingStatus,
  MealSession,
  MenuCategory,
  MenuItem,
  NotificationWebhookPayload,
  RegionalCuisine,
  RestaurantWithMenu,
  SeatingPreference,
  SlotLock,
  SpiceLevel,
  TimeSlotAvailability,
} from './types';

async function handleJson<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export async function fetchRestaurants(params?: {
  city?: string;
  cuisine?: string;
  q?: string;
  pureVeg?: boolean;
}): Promise<RestaurantWithMenu[]> {
  const search = new URLSearchParams();
  if (params?.city && params.city !== 'All') search.set('city', params.city);
  if (params?.cuisine && params.cuisine !== 'All') search.set('cuisine', params.cuisine);
  if (params?.q) search.set('q', params.q);
  if (params?.pureVeg) search.set('pureVeg', 'true');
  const qs = search.toString();
  const res = await fetch(`/api/restaurants${qs ? `?${qs}` : ''}`);
  const data = await handleJson<{ restaurants: RestaurantWithMenu[] }>(res);
  return data.restaurants;
}

export async function fetchRestaurantById(id: string): Promise<RestaurantWithMenu> {
  const res = await fetch(`/api/restaurants/${encodeURIComponent(id)}`);
  const data = await handleJson<{ restaurant: RestaurantWithMenu }>(res);
  return data.restaurant;
}

export async function submitReview(
  restaurantId: string,
  payload: { author: string; city: string; rating: number; comment: string; orderedDish: string }
): Promise<RestaurantWithMenu> {
  const res = await fetch(`/api/restaurants/${encodeURIComponent(restaurantId)}/reviews`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await handleJson<{ restaurant: RestaurantWithMenu }>(res);
  return data.restaurant;
}

export async function fetchSlots(
  restaurantId: string,
  date: string,
  session: MealSession
): Promise<TimeSlotAvailability[]> {
  const search = new URLSearchParams({ restaurantId, date, session });
  const res = await fetch(`/api/slots?${search.toString()}`);
  const data = await handleJson<{ slots: TimeSlotAvailability[] }>(res);
  return data.slots;
}

export async function acquireLock(payload: {
  restaurantId: string;
  date: string;
  session: MealSession;
  time: string;
  guests: number;
  seatingPreference: SeatingPreference;
}): Promise<SlotLock> {
  const res = await fetch('/api/bookings/lock', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await handleJson<{ lock: SlotLock }>(res);
  return data.lock;
}

export async function releaseLock(lockId: string): Promise<void> {
  await fetch('/api/bookings/release', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ lockId }),
  });
}

export async function confirmBooking(payload: {
  lockId: string;
  guestName: string;
  guestPhone: string;
  specialRequests: string;
  notifyWhatsAppSms: boolean;
}): Promise<Booking> {
  const res = await fetch('/api/bookings/confirm', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await handleJson<{ booking: Booking }>(res);
  return data.booking;
}

export async function triggerReminderWebhook(
  bookingId: string,
  event: 'booking.confirmed' | 'booking.reminder_2h'
): Promise<NotificationWebhookPayload> {
  const res = await fetch('/api/notifications/whatsapp-sms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bookingId, event }),
  });
  const data = await handleJson<{ notification: NotificationWebhookPayload }>(res);
  return data.notification;
}

export async function fetchBookings(restaurantId?: string): Promise<Booking[]> {
  const qs = restaurantId && restaurantId !== 'All' ? `?restaurantId=${encodeURIComponent(restaurantId)}` : '';
  const res = await fetch(`/api/bookings${qs}`);
  const data = await handleJson<{ bookings: Booking[] }>(res);
  return data.bookings;
}

export async function modifyBooking(
  bookingId: string,
  updates: {
    guests?: number;
    date?: string;
    session?: MealSession;
    time?: string;
    seatingPreference?: SeatingPreference;
  }
): Promise<Booking> {
  const res = await fetch(`/api/bookings/${encodeURIComponent(bookingId)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  const data = await handleJson<{ booking: Booking }>(res);
  return data.booking;
}

export async function cancelBooking(bookingId: string): Promise<Booking> {
  const res = await fetch(`/api/bookings/${encodeURIComponent(bookingId)}/cancel`, {
    method: 'POST',
  });
  const data = await handleJson<{ booking: Booking }>(res);
  return data.booking;
}

export async function fetchPartnerOverview(restaurantId?: string): Promise<{
  bookings: Booking[];
  activeLocks: SlotLock[];
  menuItems: MenuItem[];
}> {
  const qs = restaurantId && restaurantId !== 'All' ? `?restaurantId=${encodeURIComponent(restaurantId)}` : '';
  const res = await fetch(`/api/partner/overview${qs}`);
  return handleJson(res);
}

export async function updatePartnerBookingStatus(
  bookingId: string,
  status: BookingStatus
): Promise<Booking> {
  const res = await fetch(`/api/partner/bookings/${encodeURIComponent(bookingId)}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  const data = await handleJson<{ booking: Booking }>(res);
  return data.booking;
}

export async function updatePartnerMenuItem(
  itemId: string,
  patch: Partial<Pick<MenuItem, 'in_stock' | 'price' | 'spice_level' | 'is_chefs_special' | 'description' | 'name'>>
): Promise<MenuItem> {
  const res = await fetch(`/api/partner/menu/${encodeURIComponent(itemId)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  const data = await handleJson<{ item: MenuItem }>(res);
  return data.item;
}

export async function addPartnerMenuItem(payload: {
  restaurantId: string;
  name: string;
  marathiName?: string;
  category: MenuCategory;
  description: string;
  price: number;
  dietary: 'Pure Veg' | 'Non-Veg';
  jain_friendly: boolean;
  is_thali: boolean;
  thali_type?: 'Unlimited' | 'Limited';
  thali_components?: string[];
  regional_style: RegionalCuisine;
  spice_level: SpiceLevel;
  is_chefs_special: boolean;
}): Promise<MenuItem> {
  const res = await fetch('/api/partner/menu', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await handleJson<{ item: MenuItem }>(res);
  return data.item;
}
