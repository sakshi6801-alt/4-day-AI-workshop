import { ArrowRight, Download, Film, MapPin, Play, Search, Star, Utensils } from 'lucide-react';
import { useRef, useState } from 'react';
import type { CityHub, RegionalCuisine, RestaurantWithMenu } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

const CITY_HUBS: Array<'All' | CityHub> = [
  'All',
  'Mumbai',
  'Pune',
  'Nagpur',
  'Nashik',
  'Kolhapur',
  'Chhatrapati Sambhajinagar',
  'Satara',
];

const CUISINE_CARDS: Array<{
  title: RegionalCuisine;
  subtitle: string;
  dishes: string;
  image: string;
}> = [
  {
    title: 'Malvani & Konkani',
    subtitle: 'Coastal Spice & Coconut',
    dishes: 'Surmai Fry · Kombdi Vade · Solkadhi',
    image: '/src/assets/images/rest_sindhudurg_kinara_1795244737788.jpg',
  },
  {
    title: 'Kolhapuri',
    subtitle: 'Royal Dual Rassa Heritage',
    dishes: 'Tambda-Pandhra Rassa · Misal · Sukka Mutton',
    image: '/src/assets/images/rest_tambda_pandhra_1795244738597.jpg',
  },
  {
    title: 'Varhadi & Nagpuri',
    subtitle: '28-Spice Saoji Intensity',
    dishes: 'Saoji Mutton · Patodi Rassa · Tarri Poha',
    image: '/src/assets/images/rest_saoji_chulha_1795244737498.jpg',
  },
  {
    title: 'Puneri & Deshastha',
    subtitle: 'Goda Masala & Wada Classics',
    dishes: 'Puran Poli · Ukadiche Modak · Pithla Bhakri',
    image: '/src/assets/images/rest_peshwai_pangat_1795244739430.jpg',
  },
  {
    title: 'Khandeshi & Marathwada',
    subtitle: 'Wood-Ember & Kala Masala',
    dishes: 'Vangyache Bharit · Shev Bhaji · Gavran Chicken',
    image: '/src/assets/images/rest_khandeshi_angan_1795244737042.jpg',
  },
];

const FILM_CHAPTERS = [
  { label: '01 · Grand Pangat', time: 0 },
  { label: '02 · Puneri Wada', time: 2.8 },
  { label: '03 · Kolhapuri Rassa', time: 5.5 },
  { label: '04 · Malvani Coast', time: 8.2 },
  { label: '05 · Nagpuri Saoji', time: 11.0 },
  { label: '06 · Khandeshi Bharit', time: 13.7 },
  { label: '07 · Baithak Hall', time: 16.4 },
];

interface DiscoveryHomeProps {
  restaurants: RestaurantWithMenu[];
  loading: boolean;
  selectedCity: string;
  selectedCuisine: string;
  searchQuery: string;
  pureVegOnly: boolean;
  onCityChange: (city: string) => void;
  onCuisineChange: (cuisine: string) => void;
  onSearchChange: (q: string) => void;
  onPureVegChange: (v: boolean) => void;
  onOpenRestaurant: (restaurant: RestaurantWithMenu, focusBooking?: boolean) => void;
  mobilePreviewActive?: boolean;
  onToggleMobilePreview?: () => void;
}

export function DiscoveryHome({
  restaurants,
  loading,
  selectedCity,
  selectedCuisine,
  searchQuery,
  pureVegOnly,
  onCityChange,
  onCuisineChange,
  onSearchChange,
  onPureVegChange,
  onOpenRestaurant,
  mobilePreviewActive = false,
  onToggleMobilePreview,
}: DiscoveryHomeProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [activeChapter, setActiveChapter] = useState(0);
  const [videoError, setVideoError] = useState(false);

  const handleJumpChapter = (index: number, seconds: number) => {
    setActiveChapter(index);
    if (videoRef.current) {
      videoRef.current.currentTime = seconds;
      videoRef.current.play().catch(() => undefined);
    }
  };

  return (
    <div className="space-y-14 pb-20">
      {/* Section 1: Hero Split + 4-Column Hospitality Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <div className="space-y-3">
              <p className="text-xs font-semibold tracking-wider uppercase text-[#E65100]">
                Maharashtra’s Curated Dining Table
              </p>
              <h1 className="font-serif text-4xl sm:text-5xl font-bold text-[#1F2937] leading-[1.12] text-balance">
                Every Seat at Maharashtra’s Table
              </h1>
              <p className="text-base sm:text-lg text-[#1F2937]/75 max-w-xl leading-relaxed">
                Discover heritage wada kitchens, coastal Konkan thalis, and fiery Kolhapuri & Saoji
                houses—complete with spice ratings, Thali breakdowns, and live 5-minute table holds.
              </p>
            </div>

            {/* Quick Search Bar */}
            <div className="bg-white rounded-xl border border-[#1F2937]/12 shadow-xs p-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="relative flex-1 flex items-center">
                <Search className="h-4 w-4 text-[#1F2937]/45 absolute left-3 pointer-events-none" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Search city, restaurant, cuisine, or dish (e.g., Puran Poli, Surmai)..."
                  aria-label="Search restaurants or dishes"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-transparent text-[#1F2937] placeholder:text-[#1F2937]/45 focus:outline-none"
                />
              </div>
              <div className="flex items-center gap-2 px-1 sm:px-0">
                <button
                  type="button"
                  onClick={() => onPureVegChange(!pureVegOnly)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 border ${
                    pureVegOnly
                      ? 'bg-emerald-700 border-emerald-700 text-white'
                      : 'bg-[#FAF7F2] border-[#1F2937]/12 text-[#1F2937]/80 hover:border-[#1F2937]/30'
                  }`}
                >
                  Pure Veg Only
                </button>
                <a
                  href="#featured-restaurants"
                  className="px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] transition-colors whitespace-nowrap shrink-0"
                >
                  Explore Tables
                </a>
              </div>
            </div>

            {/* City Selector Pills (Functional Filter Controls) */}
            <div className="space-y-2">
              <span className="text-xs font-medium text-[#1F2937]/60 block">
                Filter by City Hub
              </span>
              <div className="flex flex-wrap gap-1.5">
                {CITY_HUBS.map((city) => {
                  const active = selectedCity === city;
                  return (
                    <button
                      key={city}
                      type="button"
                      onClick={() => onCityChange(city)}
                      className={`px-3 py-1.5 min-h-[36px] rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-[#5C162E] text-white'
                          : 'bg-[#F3EFE7] text-[#1F2937]/80 hover:bg-[#1F2937]/10'
                      }`}
                    >
                      {city === 'All' ? 'All Cities' : city}
                    </button>
                  );
                })}
              </div>
            </div>

            {!mobilePreviewActive && (
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <PWAInstallButton
                  mobilePreviewActive={mobilePreviewActive}
                  onToggleMobilePreview={onToggleMobilePreview}
                />
                <span className="text-xs text-[#1F2937]/65">
                  Install on Android & iOS with offline menu caching
                </span>
              </div>
            )}
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-[#1F2937]/10 bg-[#F3EFE7]">
              <img
                src="/src/assets/images/hero_pangat_thali_1795244737419.jpg"
                alt="Grand Maharashtrian brass thali served on banana leaf with puran poli, ukadiche modak, and solkadhi"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent flex flex-col justify-end p-6">
                <p className="text-xs font-medium text-amber-200">
                  Peshwai to Konkan · 8 Heritage Houses
                </p>
                <p className="font-serif text-xl sm:text-2xl font-semibold text-white mt-1">
                  Brass Kansa Thalis, Baithak Seating & Live Slot Holds
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Highlights Strip Below Hero Split */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-8 border-t border-[#1F2937]/10">
          <div>
            <p className="text-sm font-semibold text-[#1F2937]">5 Regional Traditions</p>
            <p className="text-xs text-[#1F2937]/65 mt-0.5">
              Malvani, Kolhapuri, Saoji, Puneri & Khandeshi
            </p>
          </div>
          <div>
            <p className="text-sm font-semibold text-[#1F2937]">Thali & Spice Metadata</p>
            <p className="text-xs text-[#1F2937]/65 mt-0.5">
              Full component lists and 1–4 heat levels
            </p>
          </div>
          <div>
            <p className="text-sm font-semibold text-[#1F2937]">5-Minute Soft Lock</p>
            <p className="text-xs text-[#1F2937]/65 mt-0.5">
              Peak-hour atomic table reservation holds
            </p>
          </div>
          <div>
            <p className="text-sm font-semibold text-[#1F2937]">WhatsApp & Maps Ready</p>
            <p className="text-xs text-[#1F2937]/65 mt-0.5">
              Instant confirmation preview & group invites
            </p>
          </div>
        </div>
      </section>

      {/* Section 2: Regional Cuisine Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1F2937]">
              Browse by Regional Tradition
            </h2>
            <p className="text-sm text-[#1F2937]/70 mt-1">
              Explore Maharashtra’s distinct spice blends, grains, and festive thali customs.
            </p>
          </div>
          {selectedCuisine !== 'All' && (
            <button
              type="button"
              onClick={() => onCuisineChange('All')}
              className="text-xs font-semibold text-[#E65100] hover:text-[#C84B31]"
            >
              Show All Cuisines
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {CUISINE_CARDS.map((card) => {
            const isActive = selectedCuisine === card.title;
            return (
              <button
                key={card.title}
                type="button"
                onClick={() => onCuisineChange(isActive ? 'All' : card.title)}
                className={`group text-left rounded-xl overflow-hidden border transition-all bg-white ${
                  isActive
                    ? 'border-[#E65100] ring-2 ring-[#E65100]/25 -translate-y-0.5'
                    : 'border-[#1F2937]/10 hover:border-[#1F2937]/25 hover:-translate-y-0.5'
                }`}
              >
                <div className="aspect-[4/3] w-full bg-[#F3EFE7] overflow-hidden relative">
                  <img
                    src={card.image}
                    alt={card.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                  />
                </div>
                <div className="p-3.5 space-y-1">
                  <h3 className="font-serif text-base font-bold text-[#1F2937]">{card.title}</h3>
                  <p className="text-xs font-medium text-[#5C162E]">{card.subtitle}</p>
                  <p className="text-[11px] text-[#1F2937]/65 line-clamp-1">{card.dishes}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Section 3: Featured Restaurants Grid */}
      <section
        id="featured-restaurants"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6"
      >
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1F2937]">
              Curated Maharashtrian Kitchens
            </h2>
            <p className="text-sm text-[#1F2937]/70 mt-1 tabular-nums">
              Showing {restaurants.length}{' '}
              {restaurants.length === 1 ? 'restaurant' : 'restaurants'}
              {selectedCity !== 'All' ? ` in ${selectedCity}` : ' across Maharashtra'}
              {selectedCuisine !== 'All' ? ` · ${selectedCuisine}` : ''}
            </p>
          </div>
          {(selectedCity !== 'All' || selectedCuisine !== 'All' || searchQuery || pureVegOnly) && (
            <button
              type="button"
              onClick={() => {
                onCityChange('All');
                onCuisineChange('All');
                onSearchChange('');
                onPureVegChange(false);
              }}
              className="text-xs font-semibold text-[#E65100] hover:text-[#C84B31]"
            >
              Reset Filters
            </button>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-96 rounded-xl bg-[#F3EFE7] border border-[#1F2937]/10 animate-pulse"
              />
            ))}
          </div>
        ) : restaurants.length === 0 ? (
          <div className="rounded-xl bg-white border border-[#1F2937]/10 p-10 text-center space-y-3">
            <Utensils className="h-8 w-8 text-[#E65100] mx-auto opacity-75" />
            <h3 className="font-serif text-xl font-bold text-[#1F2937]">
              No matching Maharashtrian kitchens found
            </h3>
            <p className="text-sm text-[#1F2937]/65 max-w-md mx-auto">
              Try clearing your search query or switching to All Cities to browse all 8 featured
              restaurants.
            </p>
            <button
              type="button"
              onClick={() => {
                onCityChange('All');
                onCuisineChange('All');
                onSearchChange('');
                onPureVegChange(false);
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31]"
            >
              Show All 8 Restaurants
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {restaurants.map((rest) => (
              <article
                key={rest.id}
                className="bg-white rounded-xl border border-[#1F2937]/10 overflow-hidden flex flex-col hover:-translate-y-0.5 hover:shadow-md transition-all"
              >
                <button
                  type="button"
                  onClick={() => onOpenRestaurant(rest, false)}
                  className="aspect-[4/3] w-full bg-[#F3EFE7] overflow-hidden relative block text-left"
                >
                  <img
                    src={rest.coverImage}
                    alt={`${rest.name} — ${rest.specialtyTag}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-serif text-xl font-bold text-[#1F2937] leading-snug">
                          {rest.name}
                        </h3>
                        <p className="text-xs text-[#1F2937]/60 mt-0.5">{rest.marathiName}</p>
                      </div>
                      <span className="inline-flex items-center gap-1 text-sm font-semibold text-[#5C162E] tabular-nums shrink-0">
                        <Star className="h-4 w-4 fill-[#F59E0B] text-[#F59E0B]" />
                        {rest.rating}
                      </span>
                    </div>

                    {/* Clean unboxed metadata with middot separators */}
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#1F2937]/70">
                      <span className="inline-flex items-center gap-1 font-medium text-[#1F2937]">
                        <MapPin className="h-3 w-3 text-[#E65100]" />
                        {rest.city} · {rest.locality}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">₹{rest.costForTwo} for two</span>
                      <span aria-hidden="true">·</span>
                      <span className={rest.pureVeg ? 'text-emerald-700 font-medium' : ''}>
                        {rest.pureVeg ? 'Pure Veg' : 'Veg & Non-Veg'}
                      </span>
                    </div>

                    <p className="text-sm text-[#1F2937]/80 leading-relaxed pt-1">
                      {rest.specialtyTag}
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 pt-2 border-t border-[#1F2937]/8">
                    <button
                      type="button"
                      onClick={() => onOpenRestaurant(rest, false)}
                      className="flex-1 py-2 px-3 rounded-lg border border-[#1F2937]/15 text-xs font-semibold text-[#1F2937] hover:bg-[#F3EFE7] transition-colors whitespace-nowrap"
                    >
                      View Menu
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenRestaurant(rest, true)}
                      className="flex-1 py-2 px-3 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] transition-colors inline-flex items-center justify-center gap-1 whitespace-nowrap"
                    >
                      Book a Table
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Section 4: Pangat Culinary Film Showcase */}
      <section
        id="culinary-film"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4"
      >
        <div className="bg-[#5C162E] text-white rounded-xl overflow-hidden border border-[#1F2937]/10">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-200">
                  <Film className="h-4 w-4" />
                  Pangat Culinary Film
                </div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold leading-snug text-balance">
                  From Coastal Malvan to Nagpur’s Hearth
                </h2>
                <p className="text-sm text-white/80 leading-relaxed">
                  Watch the Pangat regional showcase reel highlighting all seven kitchens—from
                  steamed Ukadiche Modak in Pune to wooden Baithak halls in Thane.
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-medium text-amber-200/90 block">
                  Jump to Regional Chapter
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {FILM_CHAPTERS.map((ch, idx) => (
                    <button
                      key={ch.label}
                      type="button"
                      onClick={() => handleJumpChapter(idx, ch.time)}
                      className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                        activeChapter === idx
                          ? 'bg-[#E65100] text-white'
                          : 'bg-white/10 text-white/85 hover:bg-white/20'
                      }`}
                    >
                      {ch.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (videoRef.current) {
                      if (videoRef.current.paused) {
                        videoRef.current.play().catch(() => undefined);
                      } else {
                        videoRef.current.pause();
                      }
                    }
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold bg-[#F59E0B] text-[#1F2937] hover:bg-amber-400 transition-colors"
                >
                  <Play className="h-3.5 w-3.5 fill-current" />
                  Play / Pause Film
                </button>
                <a
                  href="/pangat-showcase.mp4"
                  download="pangat-maharashtra-showcase.mp4"
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold border border-white/25 text-white hover:bg-white/10 transition-colors"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download MP4
                </a>
              </div>
            </div>

            <div className="lg:col-span-7 bg-black flex items-center justify-center">
              {!videoError ? (
                <video
                  ref={videoRef}
                  src="/pangat-showcase.mp4"
                  poster="/src/assets/images/hero_pangat_thali_1795244737419.jpg"
                  controls
                  playsInline
                  preload="metadata"
                  onError={() => setVideoError(true)}
                  className="w-full h-full max-h-[460px] object-cover"
                />
              ) : (
                <div className="p-8 text-center text-white/80 space-y-2">
                  <img
                    src="/src/assets/images/hero_pangat_thali_1795244737419.jpg"
                    alt="Pangat Maharashtrian Thali"
                    className="w-full max-h-64 object-cover rounded-lg mb-3"
                  />
                  <p className="text-sm font-medium">Pangat Culinary Showcase</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
