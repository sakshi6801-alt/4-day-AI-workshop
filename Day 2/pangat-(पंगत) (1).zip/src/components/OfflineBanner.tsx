import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export function OfflineBanner() {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="bg-[#5C162E] text-amber-100 px-4 py-2 text-xs font-medium flex items-center justify-center gap-2 border-b border-amber-200/20"
    >
      <WifiOff className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />
      <span>Offline Mode — Viewing cached Maharashtrian menus & reservations.</span>
    </div>
  );
}
