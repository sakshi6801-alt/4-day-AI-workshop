import { CheckCircle2, Code2, ExternalLink, MapPin, MessageSquare, Send, Share2, X } from 'lucide-react';
import { useState } from 'react';
import { triggerReminderWebhook } from '../api';
import { formatBookingForDoc } from '../services/googleDocs';
import type { Booking, NotificationWebhookPayload } from '../types';
import { GoogleDocExportControl } from './GoogleDocExportControl';

interface BookingConfirmationModalProps {
  booking: Booking;
  onClose: () => void;
  onViewBookings: () => void;
}

export function BookingConfirmationModal({
  booking,
  onClose,
  onViewBookings,
}: BookingConfirmationModalProps) {
  const [showWebhookJson, setShowWebhookJson] = useState(false);
  const [reminderPayload, setReminderPayload] = useState<NotificationWebhookPayload | null>(null);
  const [sendingReminder, setSendingReminder] = useState(false);

  const activeNotif = reminderPayload ?? booking.notification;
  const whatsappMessageText =
    activeNotif?.formattedWhatsAppMessage ??
    `Namaskar! Join us at ${booking.restaurantName} (${booking.restaurantLocality}, ${booking.restaurantCity}) on ${booking.date} at ${booking.time}. Booking ID: ${booking.bookingId}. Maps: ${booking.mapsUrl}`;

  const shareInviteUrl = `https://wa.me/?text=${encodeURIComponent(
    `Join our Pangat table at ${booking.restaurantName} (${booking.restaurantLocality}, ${booking.restaurantCity})!\n📅 ${booking.date} · ${booking.time}\n🪑 ${booking.seatingPreference} (${booking.guests} guests)\n🔖 Booking ID: ${booking.bookingId}\n📍 ${booking.mapsUrl}`
  )}`;

  const handleSimulateReminder = async () => {
    setSendingReminder(true);
    try {
      const payload = await triggerReminderWebhook(booking.bookingId, 'booking.reminder_2h');
      setReminderPayload(payload);
      setShowWebhookJson(true);
    } finally {
      setSendingReminder(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1F2937]/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-confirmed-heading"
    >
      <div className="bg-[#FAF7F2] w-full max-w-2xl rounded-xl border border-[#1F2937]/15 shadow-xl overflow-hidden my-6">
        <div className="bg-[#5C162E] text-white px-6 py-5 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="h-6 w-6 text-[#F59E0B] shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-mono tracking-wider text-amber-200 uppercase">
                Reservation Confirmed
              </p>
              <h2 id="booking-confirmed-heading" className="font-serif text-2xl font-bold mt-0.5">
                {booking.restaurantName}
              </h2>
              <p className="text-sm text-white/80 mt-0.5">
                {booking.restaurantLocality}, {booking.restaurantCity}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close confirmation"
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Core Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-5 border-b border-[#1F2937]/10">
            <div>
              <span className="text-xs text-[#1F2937]/60 block">Booking ID</span>
              <span className="font-mono text-sm font-semibold text-[#E65100] tabular-nums">
                {booking.bookingId}
              </span>
            </div>
            <div>
              <span className="text-xs text-[#1F2937]/60 block">Date & Time</span>
              <span className="text-sm font-semibold text-[#1F2937] tabular-nums">
                {booking.date} · {booking.time}
              </span>
            </div>
            <div>
              <span className="text-xs text-[#1F2937]/60 block">Party Size</span>
              <span className="text-sm font-semibold text-[#1F2937] tabular-nums">
                {booking.guests} {booking.guests === 1 ? 'Guest' : 'Guests'}
              </span>
            </div>
            <div>
              <span className="text-xs text-[#1F2937]/60 block">Seating</span>
              <span className="text-sm font-semibold text-[#1F2937]">
                {booking.seatingPreference}
              </span>
            </div>
          </div>

          {/* WhatsApp Message Preview Card */}
          <div className="bg-white rounded-lg border border-[#1F2937]/10 p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-emerald-700" />
                <span className="text-sm font-semibold text-[#1F2937]">
                  WhatsApp & SMS Confirmation Preview
                </span>
              </div>
              <span className="text-xs font-mono text-[#1F2937]/60">
                To: {booking.guestPhone}
              </span>
            </div>

            <div className="bg-[#EFEAE2] rounded-lg p-4 text-sm text-[#1F2937] whitespace-pre-line font-sans leading-relaxed border border-[#1F2937]/5">
              {whatsappMessageText}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <a
                href={booking.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5C162E] hover:text-[#E65100] transition-colors"
              >
                <MapPin className="h-3.5 w-3.5" />
                Open Restaurant Pin on Google Maps
                <ExternalLink className="h-3 w-3" />
              </a>

              <div className="flex flex-wrap items-center gap-2">
                <GoogleDocExportControl
                  buttonLabel="Save Pass to Google Docs"
                  docTitle={`Pangat Pass ${booking.bookingId} — ${booking.restaurantName}`}
                  getDocContent={() => formatBookingForDoc(booking)}
                />
                <a
                  href={shareInviteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-700 text-white hover:bg-emerald-800 transition-colors whitespace-nowrap"
                >
                  <Share2 className="h-3.5 w-3.5" />
                  Share Invite on WhatsApp
                </a>
              </div>
            </div>
          </div>

          {/* Webhook Architecture Inspector */}
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setShowWebhookJson((v) => !v)}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1F2937]/75 hover:text-[#1F2937] transition-colors"
              >
                <Code2 className="h-3.5 w-3.5" />
                {showWebhookJson ? 'Hide' : 'Inspect'} Twilio / Interakt / Gupshup Webhook Payload
              </button>

              <button
                type="button"
                onClick={handleSimulateReminder}
                disabled={sendingReminder}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#E65100] hover:text-[#C84B31] disabled:opacity-50"
              >
                <Send className="h-3.5 w-3.5" />
                {sendingReminder ? 'Dispatching...' : 'Test 2-Hour Reminder Webhook'}
              </button>
            </div>

            {showWebhookJson && activeNotif && (
              <pre className="bg-[#1F2937] text-amber-100 rounded-lg p-3.5 text-xs font-mono overflow-x-auto leading-relaxed">
                {JSON.stringify(activeNotif, null, 2)}
              </pre>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3 pt-2 border-t border-[#1F2937]/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-sm font-medium text-[#1F2937] hover:bg-[#1F2937]/5 transition-colors"
            >
              Back to Menu
            </button>
            <button
              type="button"
              onClick={onViewBookings}
              className="px-5 py-2.5 rounded-lg text-sm font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] transition-colors"
            >
              Manage in My Bookings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
