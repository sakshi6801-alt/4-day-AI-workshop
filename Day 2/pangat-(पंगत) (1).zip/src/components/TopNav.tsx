import { PWAInstallButton } from './PWAInstallButton';

export type ActiveRoute = 'discover' | 'restaurant' | 'bookings' | 'partner';

interface TopNavProps {
  activeRoute: ActiveRoute;
  onNavigate: (route: ActiveRoute) => void;
  onJumpToFilm: () => void;
  onQuickBook: () => void;
  mobilePreviewActive?: boolean;
  onToggleMobilePreview?: () => void;
}

export function TopNav({
  activeRoute,
  onNavigate,
  onJumpToFilm,
  onQuickBook,
  mobilePreviewActive = false,
  onToggleMobilePreview,
}: TopNavProps) {
  const linkClass = (active: boolean) =>
    `whitespace-nowrap shrink-0 text-sm font-medium transition-colors py-1 border-b-2 ${
      active
        ? 'text-[#E65100] border-[#E65100]'
        : 'text-[#1F2937]/75 border-transparent hover:text-[#1F2937] hover:border-[#1F2937]/25'
    }`;

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-sm border-b border-[#1F2937]/10">
      <div
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${
          mobilePreviewActive ? 'h-14' : 'h-14 md:h-16'
        } flex items-center justify-between gap-8`}
      >
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('discover')}
          className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#5C162E] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E65100]"
        >
          Pangat <span className="text-[#E65100] font-normal">पंगत</span>
        </button>

        {/* Zone 2: 4 concise single-line text nav links (Desktop) */}
        {!mobilePreviewActive && (
          <nav className="hidden md:flex items-center gap-7" aria-label="Main navigation">
            <button
              type="button"
              onClick={() => onNavigate('discover')}
              className={linkClass(activeRoute === 'discover' || activeRoute === 'restaurant')}
            >
              Discover
            </button>
            <button type="button" onClick={onJumpToFilm} className={linkClass(false)}>
              Feast Film
            </button>
            <button
              type="button"
              onClick={() => onNavigate('bookings')}
              className={linkClass(activeRoute === 'bookings')}
            >
              My Bookings
            </button>
            <button
              type="button"
              onClick={() => onNavigate('partner')}
              className={linkClass(activeRoute === 'partner')}
            >
              Partner Desk
            </button>
          </nav>
        )}

        {/* Zone 3: 1 primary action on Desktop, Install/Book on Mobile */}
        <div className="flex items-center gap-2 shrink-0">
          {!mobilePreviewActive && (
            <button
              type="button"
              onClick={onQuickBook}
              className="hidden md:inline-flex items-center justify-center px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E65100]"
            >
              Book a Table
            </button>
          )}
          <div className={mobilePreviewActive ? 'block' : 'md:hidden'}>
            <PWAInstallButton
              compact
              mobilePreviewActive={mobilePreviewActive}
              onToggleMobilePreview={onToggleMobilePreview}
            />
          </div>
        </div>
      </div>
    </header>
  );
}
