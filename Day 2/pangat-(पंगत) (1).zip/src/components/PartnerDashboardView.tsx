import { Lock, Plus, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import {
  addPartnerMenuItem,
  fetchPartnerOverview,
  updatePartnerBookingStatus,
  updatePartnerMenuItem,
} from '../api';
import type {
  Booking,
  BookingStatus,
  MenuCategory,
  MenuItem,
  RegionalCuisine,
  RestaurantWithMenu,
  SlotLock,
  SpiceLevel,
} from '../types';
import { SpiceIndicator } from './SpiceIndicator';
import { GoogleDocsWorkspace } from './GoogleDocsWorkspace';

const MENU_CATEGORIES: MenuCategory[] = [
  'Special Thalis',
  'Starters & Farsan',
  'Main Course',
  'Breads (Bhakri/Poli)',
  'Desserts',
  'Beverages (Solkadhi/Piyush/Taak)',
];

const REGIONAL_CUISINES: RegionalCuisine[] = [
  'Puneri & Deshastha',
  'Kolhapuri',
  'Malvani & Konkani',
  'Varhadi & Nagpuri',
  'Khandeshi & Marathwada',
];

interface PartnerDashboardViewProps {
  restaurants: RestaurantWithMenu[];
  onDataChanged: () => void;
}

export function PartnerDashboardView({ restaurants, onDataChanged }: PartnerDashboardViewProps) {
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'reservations' | 'menu' | 'docs'>('reservations');
  const [statusFilter, setStatusFilter] = useState<'All' | BookingStatus>('All');

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeLocks, setActiveLocks] = useState<SlotLock[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [nowMs, setNowMs] = useState(Date.now());

  // Add Menu Item Modal/Form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newRestId, setNewRestId] = useState(restaurants[0]?.id ?? 'peshwai-pangat');
  const [newName, setNewName] = useState('');
  const [newMarathi, setNewMarathi] = useState('');
  const [newCategory, setNewCategory] = useState<MenuCategory>('Special Thalis');
  const [newPrice, setNewPrice] = useState('380');
  const [newDietary, setNewDietary] = useState<'Pure Veg' | 'Non-Veg'>('Pure Veg');
  const [newJain, setNewJain] = useState(false);
  const [newIsThali, setNewIsThali] = useState(true);
  const [newThaliType, setNewThaliType] = useState<'Unlimited' | 'Limited'>('Unlimited');
  const [newThaliComponents, setNewThaliComponents] = useState(
    '2 Jowar Bhakris, Chef Special Curry, Indrayani Rice, Solkadhi'
  );
  const [newCuisine, setNewCuisine] = useState<RegionalCuisine>('Puneri & Deshastha');
  const [newSpice, setNewSpice] = useState<SpiceLevel>(2);
  const [newSpecial, setNewSpecial] = useState(true);
  const [newDesc, setNewDesc] = useState('');
  const [formMsg, setFormMsg] = useState<string | null>(null);

  const loadOverview = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchPartnerOverview(selectedRestaurantId);
      setBookings(data.bookings);
      setActiveLocks(data.activeLocks);
      setMenuItems(data.menuItems);
    } finally {
      setLoading(false);
    }
  }, [selectedRestaurantId]);

  useEffect(() => {
    loadOverview();
  }, [loadOverview]);

  useEffect(() => {
    const t = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const handleStatusChange = async (bookingId: string, status: BookingStatus) => {
    await updatePartnerBookingStatus(bookingId, status);
    await loadOverview();
  };

  const handleToggleStock = async (item: MenuItem) => {
    await updatePartnerMenuItem(item.id, { in_stock: !item.in_stock });
    await loadOverview();
    onDataChanged();
  };

  const handleAddMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormMsg(null);
    try {
      await addPartnerMenuItem({
        restaurantId: newRestId,
        name: newName,
        marathiName: newMarathi || undefined,
        category: newCategory,
        description: newDesc,
        price: Number(newPrice),
        dietary: newDietary,
        jain_friendly: newJain,
        is_thali: newIsThali,
        thali_type: newIsThali ? newThaliType : undefined,
        thali_components: newIsThali
          ? newThaliComponents
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : undefined,
        regional_style: newCuisine,
        spice_level: newSpice,
        is_chefs_special: newSpecial,
      });
      setNewName('');
      setNewMarathi('');
      setNewDesc('');
      setShowAddForm(false);
      setFormMsg('New dish added and live on customer menus.');
      await loadOverview();
      onDataChanged();
    } catch (err) {
      setFormMsg(err instanceof Error ? err.message : 'Unable to add dish.');
    }
  };

  const filteredBookings =
    statusFilter === 'All' ? bookings : bookings.filter((b) => b.status === statusFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-[#E65100] uppercase tracking-wider">
            Restaurant Partner Desk
          </p>
          <h1 className="font-serif text-3xl font-bold text-[#1F2937] mt-1">
            Live Floor, Soft-Locks & Thali Menu Manager
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedRestaurantId}
            onChange={(e) => setSelectedRestaurantId(e.target.value)}
            aria-label="Filter by restaurant"
            className="rounded-lg border border-[#1F2937]/15 bg-white px-3 py-2 text-xs font-semibold text-[#1F2937]"
          >
            <option value="All">All 8 Partner Restaurants</option>
            {restaurants.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name} ({r.city})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={loadOverview}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#1F2937]/15 bg-white text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7]"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
        </div>
      </div>

      {/* Live Summary Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4">
          <span className="text-xs text-[#1F2937]/60 block">Total Bookings</span>
          <span className="text-2xl font-bold text-[#1F2937] tabular-nums mt-1 block">
            {bookings.length}
          </span>
        </div>
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4">
          <span className="text-xs text-[#1F2937]/60 block">Active Soft-Locks (5m TTL)</span>
          <span className="text-2xl font-bold text-[#E65100] tabular-nums mt-1 block">
            {activeLocks.length}
          </span>
        </div>
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4">
          <span className="text-xs text-[#1F2937]/60 block">Menu Items Live</span>
          <span className="text-2xl font-bold text-emerald-700 tabular-nums mt-1 block">
            {menuItems.filter((m) => m.in_stock).length} / {menuItems.length}
          </span>
        </div>
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4">
          <span className="text-xs text-[#1F2937]/60 block">Seated Parties</span>
          <span className="text-2xl font-bold text-[#5C162E] tabular-nums mt-1 block">
            {bookings.filter((b) => b.status === 'Seated').length}
          </span>
        </div>
      </div>

      {/* Active Checkout Soft-Locks Monitor */}
      {activeLocks.length > 0 && (
        <div className="bg-amber-50/70 rounded-xl border border-[#F59E0B]/40 p-4 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#5C162E]">
            <Lock className="h-4 w-4 text-[#E65100]" />
            Active Checkout Table Holds (Auto-releasing on expiry)
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {activeLocks.map((l) => {
              const remSec = Math.max(0, Math.floor((l.locked_until - nowMs) / 1000));
              const mm = String(Math.floor(remSec / 60)).padStart(2, '0');
              const ss = String(remSec % 60).padStart(2, '0');
              return (
                <div
                  key={l.lockId}
                  className="bg-white rounded-lg border border-[#1F2937]/10 px-3.5 py-2.5 flex items-center justify-between text-xs"
                >
                  <div>
                    <p className="font-semibold text-[#1F2937]">{l.restaurantName}</p>
                    <p className="text-[#1F2937]/70 tabular-nums">
                      {l.date} · {l.time} · {l.guests} guests ({l.seatingPreference})
                    </p>
                  </div>
                  <span className="font-mono font-semibold text-[#E65100] tabular-nums">
                    {mm}:{ss}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Workspace Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3 border-b border-[#1F2937]/10 pb-3">
        <div className="flex items-center gap-1 p-1 bg-[#F3EFE7] rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('reservations')}
            className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'reservations'
                ? 'bg-white text-[#5C162E] shadow-xs'
                : 'text-[#1F2937]/70 hover:text-[#1F2937]'
            }`}
          >
            Incoming Reservations
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('menu')}
            className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'menu'
                ? 'bg-white text-[#5C162E] shadow-xs'
                : 'text-[#1F2937]/70 hover:text-[#1F2937]'
            }`}
          >
            Menu & Thali Inventory
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('docs')}
            className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors ${
              activeTab === 'docs'
                ? 'bg-white text-[#5C162E] shadow-xs'
                : 'text-[#1F2937]/70 hover:text-[#1F2937]'
            }`}
          >
            Google Docs Studio
          </button>
        </div>

        {activeTab === 'menu' && (
          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            {showAddForm ? 'Close Form' : 'Add Dish or Daily Thali'}
          </button>
        )}
      </div>

      {formMsg && (
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-xs font-medium text-emerald-800">
          {formMsg}
        </div>
      )}

      {loading ? (
        <div className="h-64 rounded-xl bg-[#F3EFE7] animate-pulse" />
      ) : activeTab === 'reservations' ? (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-1.5">
            {(['All', 'Confirmed', 'Seated', 'Completed', 'Cancelled'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  statusFilter === st
                    ? 'bg-[#5C162E] text-white'
                    : 'bg-white border border-[#1F2937]/12 text-[#1F2937]/80 hover:bg-[#F3EFE7]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-[#1F2937]/10 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[#1F2937]/10 bg-[#FAF7F2] text-[#1F2937]/70">
                  <th className="py-3 px-4 font-semibold">Booking ID</th>
                  <th className="py-3 px-4 font-semibold">Restaurant</th>
                  <th className="py-3 px-4 font-semibold">Guest</th>
                  <th className="py-3 px-4 font-semibold">Date & Slot</th>
                  <th className="py-3 px-4 font-semibold">Party & Seating</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2937]/8">
                {filteredBookings.map((b) => (
                  <tr key={b.bookingId} className="hover:bg-[#FAF7F2]/60">
                    <td className="py-3 px-4 font-mono font-semibold text-[#E65100] tabular-nums whitespace-nowrap">
                      {b.bookingId}
                    </td>
                    <td className="py-3 px-4 font-medium text-[#1F2937] whitespace-nowrap">
                      {b.restaurantName}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#1F2937]">{b.guestName}</div>
                      <div className="font-mono text-[11px] text-[#1F2937]/60">{b.guestPhone}</div>
                    </td>
                    <td className="py-3 px-4 tabular-nums whitespace-nowrap">
                      <div>{b.date}</div>
                      <div className="text-[#1F2937]/65">
                        {b.time} · {b.session}
                      </div>
                    </td>
                    <td className="py-3 px-4 tabular-nums">
                      <div>{b.guests} Guests</div>
                      <div className="text-[#1F2937]/65">{b.seatingPreference}</div>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={b.status}
                        onChange={(e) =>
                          handleStatusChange(b.bookingId, e.target.value as BookingStatus)
                        }
                        aria-label={`Update status for ${b.bookingId}`}
                        className="rounded-md border border-[#1F2937]/15 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#1F2937]"
                      >
                        <option value="Confirmed">Confirmed</option>
                        <option value="Seated">Seated</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === 'docs' ? (
        <GoogleDocsWorkspace
          restaurants={restaurants}
          bookings={bookings}
          initialRestaurantId={selectedRestaurantId === 'All' ? undefined : selectedRestaurantId}
        />
      ) : (
        <div className="space-y-6">
          {showAddForm && (
            <form
              onSubmit={handleAddMenuItem}
              className="bg-white rounded-xl border border-[#1F2937]/12 p-5 space-y-4"
            >
              <h3 className="font-serif text-lg font-bold text-[#5C162E]">
                Add New Dish or Daily Special Thali
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Restaurant
                  </label>
                  <select
                    value={newRestId}
                    onChange={(e) => setNewRestId(e.target.value)}
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  >
                    {restaurants.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name} ({r.city})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Dish Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g., Gudi Padwa Shrikhand Thali"
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Marathi Name (Optional)
                  </label>
                  <input
                    type="text"
                    value={newMarathi}
                    onChange={(e) => setNewMarathi(e.target.value)}
                    placeholder="e.g., गुढीपाडवा विशेष थाळी"
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as MenuCategory)}
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  >
                    {MENU_CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Regional Style
                  </label>
                  <select
                    value={newCuisine}
                    onChange={(e) => setNewCuisine(e.target.value as RegionalCuisine)}
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  >
                    {REGIONAL_CUISINES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Price (₹) *
                  </label>
                  <input
                    type="number"
                    min={10}
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs tabular-nums"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                    Spice Level (1–4)
                  </label>
                  <select
                    value={newSpice}
                    onChange={(e) => setNewSpice(Number(e.target.value) as SpiceLevel)}
                    className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                  >
                    <option value={1}>1 - Mild</option>
                    <option value={2}>2 - Medium</option>
                    <option value={3}>3 - Spicy</option>
                    <option value={4}>4 - Kolhapuri / Saoji Fiery</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-5 text-xs">
                <label className="inline-flex items-center gap-2">
                  <input
                    type="radio"
                    name="dietary"
                    checked={newDietary === 'Pure Veg'}
                    onChange={() => setNewDietary('Pure Veg')}
                  />
                  Pure Veg
                </label>
                <label className="inline-flex items-center gap-2">
                  <input
                    type="radio"
                    name="dietary"
                    checked={newDietary === 'Non-Veg'}
                    onChange={() => setNewDietary('Non-Veg')}
                  />
                  Non-Veg
                </label>
                <label className="inline-flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newJain}
                    onChange={(e) => setNewJain(e.target.checked)}
                  />
                  Jain-Friendly
                </label>
                <label className="inline-flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newIsThali}
                    onChange={(e) => setNewIsThali(e.target.checked)}
                  />
                  Is Special Thali
                </label>
                <label className="inline-flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newSpecial}
                    onChange={(e) => setNewSpecial(e.target.checked)}
                  />
                  Chef’s Special
                </label>
              </div>

              {newIsThali && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                      Thali Type
                    </label>
                    <select
                      value={newThaliType}
                      onChange={(e) => setNewThaliType(e.target.value as 'Unlimited' | 'Limited')}
                      className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                    >
                      <option value="Unlimited">Unlimited</option>
                      <option value="Limited">Limited</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                      Thali Components (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={newThaliComponents}
                      onChange={(e) => setNewThaliComponents(e.target.value)}
                      className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-medium text-[#1F2937]/75 block mb-1">
                  Description *
                </label>
                <textarea
                  rows={2}
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Describe ingredients, regional style, and preparation..."
                  className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31]"
              >
                Publish to Live Menu
              </button>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {menuItems.map((item) => {
              const restName =
                restaurants.find((r) => r.id === item.restaurantId)?.name ?? item.restaurantId;
              return (
                <div
                  key={item.id}
                  className="bg-white rounded-xl border border-[#1F2937]/10 p-4 flex items-center justify-between gap-4"
                >
                  <div className="space-y-1 min-w-0">
                    <p className="text-[11px] font-medium text-[#5C162E] truncate">
                      {restName} · {item.category}
                    </p>
                    <h4 className="font-serif text-base font-bold text-[#1F2937] truncate">
                      {item.name}
                    </h4>
                    <div className="flex items-center gap-3 text-xs">
                      <span className="font-semibold tabular-nums">₹{item.price}</span>
                      <SpiceIndicator level={item.spice_level} compact />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleStock(item)}
                    className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                      item.in_stock
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                        : 'bg-red-50 text-red-700 border border-red-200 hover:bg-red-100'
                    }`}
                  >
                    {item.in_stock ? 'In Stock' : 'Sold Out'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
