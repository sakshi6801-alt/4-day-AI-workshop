import { ExternalLink, FileText } from 'lucide-react';
import { useState } from 'react';
import { getAccessToken, googleSignIn } from '../firebaseAuth';
import { createGoogleDocWithText, type ParsedGoogleDoc } from '../services/googleDocs';
import { GoogleSignInButton } from './GoogleSignInButton';

interface GoogleDocExportControlProps {
  buttonLabel: string;
  docTitle: string;
  getDocContent: () => string;
}

export function GoogleDocExportControl({
  buttonLabel,
  docTitle,
  getDocContent,
}: GoogleDocExportControlProps) {
  const [showConfirm, setShowConfirm] = useState(false);
  const [needsSignIn, setNeedsSignIn] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [saving, setSaving] = useState(false);
  const [createdDoc, setCreatedDoc] = useState<ParsedGoogleDoc | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleStartExport = () => {
    setErrorMsg(null);
    const token = getAccessToken();
    if (!token) {
      setNeedsSignIn(true);
      return;
    }
    setShowConfirm(true);
  };

  const handleSignInAndConfirm = async () => {
    setSigningIn(true);
    setErrorMsg(null);
    try {
      await googleSignIn();
      setNeedsSignIn(false);
      setShowConfirm(true);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      setSigningIn(false);
    }
  };

  const handleCreateDoc = async () => {
    const token = getAccessToken();
    if (!token) {
      setShowConfirm(false);
      setNeedsSignIn(true);
      return;
    }
    setSaving(true);
    setErrorMsg(null);
    try {
      const doc = await createGoogleDocWithText(token, docTitle, getDocContent());
      setCreatedDoc(doc);
      setShowConfirm(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to save Google Doc.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="inline-flex flex-col items-start gap-2">
      {createdDoc ? (
        <a
          href={createdDoc.webViewLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-[#5C162E] text-white hover:bg-[#471023] transition-colors whitespace-nowrap"
        >
          <FileText className="h-3.5 w-3.5" />
          Open Saved Google Doc
          <ExternalLink className="h-3 w-3" />
        </a>
      ) : (
        <button
          type="button"
          onClick={handleStartExport}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#5C162E]/25 bg-white text-xs font-semibold text-[#5C162E] hover:bg-[#F3EFE7] transition-colors whitespace-nowrap"
        >
          <FileText className="h-3.5 w-3.5 text-[#E65100]" />
          {buttonLabel}
        </button>
      )}

      {errorMsg && <p className="text-xs text-red-700">{errorMsg}</p>}

      {needsSignIn && (
        <div
          className="fixed inset-0 z-50 bg-[#1F2937]/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#FAF7F2] w-full max-w-md rounded-xl border border-[#1F2937]/15 shadow-xl p-6 space-y-4">
            <h3 className="font-serif text-xl font-bold text-[#5C162E]">
              Connect Google Docs
            </h3>
            <p className="text-sm text-[#1F2937]/80 leading-relaxed">
              Sign in with Google to create and save "{docTitle}" directly to your Google Drive.
            </p>
            {errorMsg && (
              <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-800">
                {errorMsg}
              </div>
            )}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <GoogleSignInButton onClick={handleSignInAndConfirm} loading={signingIn} />
              <button
                type="button"
                onClick={() => setNeedsSignIn(false)}
                className="px-4 py-2 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7]"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showConfirm && (
        <div
          className="fixed inset-0 z-50 bg-[#1F2937]/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#FAF7F2] w-full max-w-md rounded-xl border border-[#1F2937]/15 shadow-xl p-6 space-y-4">
            <h3 className="font-serif text-xl font-bold text-[#5C162E]">
              Save to Google Docs?
            </h3>
            <p className="text-sm text-[#1F2937]/80 leading-relaxed">
              Confirm creating a new Google Doc titled <strong>"{docTitle}"</strong> in your Google
              Drive?
            </p>
            {errorMsg && (
              <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-800">
                {errorMsg}
              </div>
            )}
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={saving}
                onClick={() => setShowConfirm(false)}
                className="px-4 py-2 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleCreateDoc}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] disabled:opacity-50"
              >
                {saving ? 'Saving Doc...' : 'Confirm & Create Doc'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
