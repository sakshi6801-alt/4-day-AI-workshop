import { Calendar, Check, Clock, Lock, Minus, Plus, ShieldCheck, Users } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { acquireLock, confirmBooking, fetchSlots, releaseLock } from '../api';
import type {
  Booking,
  MealSession,
  RestaurantWithMenu,
  SeatingPreference,
  SlotLock,
  TimeSlotAvailability,
} from '../types';

const SESSIONS: MealSession[] = ['Breakfast / Nashta', 'Lunch', 'Evening Snacks', 'Dinner'];

function getUpcomingDates(days = 14): Array<{ value: string; label: string; sub: string }> {
  const result: Array<{ value: string; label: string; sub: string }> = [];
  const base = new Date();
  for (let i = 0; i < days; i++) {
    const d = new Date(base);
    d.setDate(base.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const value = `${y}-${m}-${day}`;
    const label =
      i === 0
        ? 'Today'
        : i === 1
          ? 'Tomorrow'
          : d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
    const sub = d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    result.push({ value, label, sub });
  }
  return result;
}

interface BookingWidgetProps {
  restaurant: RestaurantWithMenu;
  onBookingConfirmed: (booking: Booking) => void;
}

export function BookingWidget({ restaurant, onBookingConfirmed }: BookingWidgetProps) {
  const dateOptions = useMemo(() => getUpcomingDates(14), []);
  const [date, setDate] = useState(dateOptions[0].value);
  const [session, setSession] = useState<MealSession>('Lunch');
  const [slots, setSlots] = useState<TimeSlotAvailability[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [guests, setGuests] = useState<number>(4);
  const [seating, setSeating] = useState<SeatingPreference>(restaurant.seatingOptions[0]);

  const [activeLock, setActiveLock] = useState<SlotLock | null>(null);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(0);
  const [lockLoading, setLockLoading] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [notifyWhatsAppSms, setNotifyWhatsAppSms] = useState(true);

  const tablesRequired = Math.max(1, Math.ceil(guests / 6));

  const loadSlots = useCallback(async () => {
    setSlotsLoading(true);
    try {
      const data = await fetchSlots(restaurant.id, date, session);
      setSlots(data);
      setSelectedTime((prev) => {
        const stillValid = data.find((s) => s.time === prev && s.availableTables >= tablesRequired);
        if (stillValid) return prev;
        const firstOpen = data.find((s) => s.availableTables >= tablesRequired);
        return firstOpen?.time ?? '';
      });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to fetch table slots.');
    } finally {
      setSlotsLoading(false);
    }
  }, [restaurant.id, date, session, tablesRequired]);

  useEffect(() => {
    setSeating(restaurant.seatingOptions[0]);
  }, [restaurant]);

  useEffect(() => {
    loadSlots();
  }, [loadSlots]);

  // Live 5-minute TTL countdown while soft-lock is active
  useEffect(() => {
    if (!activeLock) {
      setRemainingSeconds(0);
      return;
    }

    const updateTimer = () => {
      const diff = Math.max(0, Math.floor((activeLock.locked_until - Date.now()) / 1000));
      setRemainingSeconds(diff);
      if (diff === 0) {
        releaseLock(activeLock.lockId).catch(() => undefined);
        setActiveLock(null);
        setErrorMsg('Your 5-minute table hold expired and the table was released back to the pool.');
        loadSlots();
      }
    };

    updateTimer();
    const timer = window.setInterval(updateTimer, 1000);
    return () => window.clearInterval(timer);
  }, [activeLock, loadSlots]);

  const handleLockSlot = async () => {
    if (!selectedTime) {
      setErrorMsg('Please select an available time slot.');
      return;
    }
    setErrorMsg(null);
    setLockLoading(true);
    try {
      const lock = await acquireLock({
        restaurantId: restaurant.id,
        date,
        session,
        time: selectedTime,
        guests,
        seatingPreference: seating,
      });
      setActiveLock(lock);
      await loadSlots();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Could not hold table.');
      await loadSlots();
    } finally {
      setLockLoading(false);
    }
  };

  const handleReleaseLock = async () => {
    if (!activeLock) return;
    const id = activeLock.lockId;
    setActiveLock(null);
    await releaseLock(id).catch(() => undefined);
    await loadSlots();
  };

  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLock) return;
    const digits = guestPhone.replace(/\D/g, '');
    if (guestName.trim().length < 2) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (digits.length < 10) {
      setErrorMsg('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    setErrorMsg(null);
    setConfirmLoading(true);
    try {
      const booking = await confirmBooking({
        lockId: activeLock.lockId,
        guestName: guestName.trim(),
        guestPhone: digits.slice(-10),
        specialRequests,
        notifyWhatsAppSms,
      });
      setActiveLock(null);
      setGuestName('');
      setGuestPhone('');
      setSpecialRequests('');
      await loadSlots();
      onBookingConfirmed(booking);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Confirmation failed.');
      setActiveLock(null);
      await loadSlots();
    } finally {
      setConfirmLoading(false);
    }
  };

  const mins = String(Math.floor(remainingSeconds / 60)).padStart(2, '0');
  const secs = String(remainingSeconds % 60).padStart(2, '0');

  return (
    <div className="bg-white rounded-xl border border-[#1F2937]/12 shadow-sm overflow-hidden">
      <div className="px-5 py-4 bg-[#F3EFE7] border-b border-[#1F2937]/10">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-serif text-lg font-bold text-[#5C162E]">Reserve Your Pangat</h3>
          <span className="text-xs font-medium text-[#1F2937]/70 tabular-nums">
            ₹{restaurant.costForTwo} for two
          </span>
        </div>
        <p className="text-xs text-[#1F2937]/65 mt-0.5">
          Real-time table inventory with 5-minute checkout lock
        </p>
      </div>

      <div className="p-5 space-y-5">
        {errorMsg && (
          <div
            role="alert"
            className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs text-red-800 font-medium"
          >
            {errorMsg}
          </div>
        )}

        {!activeLock ? (
          <>
            {/* Step 1: Date & Meal Session */}
            <div className="space-y-3">
              <label className="flex items-center gap-1.5 text-xs font-semibold text-[#1F2937]/80">
                <Calendar className="h-3.5 w-3.5 text-[#E65100]" />
                1. Select Date & Meal Session
              </label>
              <select
                value={date}
                onChange={(e) => setDate(e.target.value)}
                aria-label="Reservation date"
                className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2.5 text-sm font-medium text-[#1F2937] focus:outline-2 focus:outline-[#E65100]"
              >
                {dateOptions.map((d) => (
                  <option key={d.value} value={d.value}>
                    {d.label} ({d.sub})
                  </option>
                ))}
              </select>

              <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#F3EFE7] rounded-lg">
                {SESSIONS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSession(s)}
                    className={`px-2.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate ${
                      session === s
                        ? 'bg-white text-[#5C162E] shadow-xs font-semibold'
                        : 'text-[#1F2937]/70 hover:text-[#1F2937]'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Live Time Slots */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-semibold text-[#1F2937]/80">
                  <Clock className="h-3.5 w-3.5 text-[#E65100]" />
                  2. Select Time Slot
                </span>
                {slotsLoading && (
                  <span className="text-[11px] text-[#1F2937]/50">Checking tables...</span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                {slots.map((slot) => {
                  const insufficient = slot.availableTables < tablesRequired;
                  const isSelected = selectedTime === slot.time && !insufficient;
                  return (
                    <button
                      key={slot.time}
                      type="button"
                      disabled={insufficient}
                      onClick={() => setSelectedTime(slot.time)}
                      className={`text-left px-3 py-2.5 rounded-lg border transition-all ${
                        insufficient
                          ? 'bg-neutral-100 border-neutral-200 text-neutral-400 cursor-not-allowed'
                          : isSelected
                            ? 'bg-[#E65100] border-[#E65100] text-white shadow-xs'
                            : 'bg-[#FAF7F2] border-[#1F2937]/12 text-[#1F2937] hover:border-[#E65100]/50'
                      }`}
                    >
                      <div className="text-sm font-semibold tabular-nums">{slot.time}</div>
                      <div
                        className={`text-[11px] mt-0.5 tabular-nums ${
                          insufficient
                            ? 'text-neutral-400'
                            : isSelected
                              ? 'text-amber-100'
                              : slot.status === 'Limited'
                                ? 'text-[#C84B31] font-medium'
                                : 'text-emerald-700'
                        }`}
                      >
                        {slot.availableTables === 0
                          ? 'Sold Out'
                          : slot.availableTables <= 2
                            ? `Only ${slot.availableTables} ${slot.availableTables === 1 ? 'table' : 'tables'} left`
                            : `${slot.availableTables} tables open`}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Guests & Seating Preference */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-semibold text-[#1F2937]/80">
                  <Users className="h-3.5 w-3.5 text-[#E65100]" />
                  3. Guests & Seating
                </span>
                <span className="text-[11px] text-[#1F2937]/60 tabular-nums">
                  {tablesRequired} {tablesRequired === 1 ? 'table' : 'tables'} needed
                </span>
              </div>

              <div className="flex items-center justify-between rounded-lg border border-[#1F2937]/12 bg-[#FAF7F2] px-3 py-2">
                <span className="text-sm font-medium text-[#1F2937]">Party Size</span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setGuests((g) => Math.max(1, g - 1))}
                    aria-label="Decrease guests"
                    className="h-8 w-8 rounded-md border border-[#1F2937]/15 bg-white flex items-center justify-center hover:bg-[#F3EFE7] text-[#1F2937]"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-8 text-center text-sm font-semibold tabular-nums">
                    {guests >= 12 ? '12+' : guests}
                  </span>
                  <button
                    type="button"
                    onClick={() => setGuests((g) => Math.min(14, g + 1))}
                    aria-label="Increase guests"
                    className="h-8 w-8 rounded-md border border-[#1F2937]/15 bg-white flex items-center justify-center hover:bg-[#F3EFE7] text-[#1F2937]"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs text-[#1F2937]/65 block">Seating Preference</span>
                <div className="grid grid-cols-1 gap-1.5">
                  {restaurant.seatingOptions.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setSeating(opt)}
                      className={`px-3 py-2 rounded-lg border text-left text-xs font-medium flex items-center justify-between transition-colors ${
                        seating === opt
                          ? 'border-[#5C162E] bg-[#5C162E]/5 text-[#5C162E] font-semibold'
                          : 'border-[#1F2937]/10 bg-white text-[#1F2937]/80 hover:border-[#1F2937]/25'
                      }`}
                    >
                      <span>{opt}</span>
                      {seating === opt && <Check className="h-3.5 w-3.5 text-[#5C162E]" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              type="button"
              disabled={!selectedTime || lockLoading}
              onClick={handleLockSlot}
              className="w-full py-3 px-4 rounded-lg text-sm font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] disabled:bg-neutral-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              <Lock className="h-4 w-4" />
              {lockLoading ? 'Holding Table...' : 'Hold Table & Continue'}
            </button>
          </>
        ) : (
          /* Step 4: Soft-Lock Checkout with Live Countdown Timer */
          <form onSubmit={handleConfirmBooking} className="space-y-4">
            <div className="rounded-lg bg-amber-50 border border-[#F59E0B]/40 p-3.5 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5C162E]">
                  <ShieldCheck className="h-4 w-4 text-[#E65100]" />
                  Table reserved for{' '}
                  <span className="font-mono text-[#E65100] tabular-nums">
                    {mins}:{secs}
                  </span>{' '}
                  while you complete booking
                </span>
              </div>
              <p className="text-xs text-[#1F2937]/75">
                {activeLock.date} · {activeLock.time} · {activeLock.guests} guests ·{' '}
                {activeLock.seatingPreference}
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-[#1F2937]/80 block mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="e.g., Siddharth Deshmukh"
                  className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2.5 text-sm text-[#1F2937] focus:outline-2 focus:outline-[#E65100]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#1F2937]/80 block mb-1">
                  Mobile Number (+91) *
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-[#1F2937]/15 bg-[#F3EFE7] text-xs font-mono font-medium text-[#1F2937]/75">
                    +91
                  </span>
                  <input
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="98220 45112"
                    className="w-full rounded-r-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2.5 text-sm font-mono text-[#1F2937] focus:outline-2 focus:outline-[#E65100]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#1F2937]/80 block mb-1">
                  Special Requests (Optional)
                </label>
                <textarea
                  rows={2}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="High chair, birthday celebration, Jain preparation..."
                  className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm text-[#1F2937] focus:outline-2 focus:outline-[#E65100]"
                />
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={notifyWhatsAppSms}
                  onChange={(e) => setNotifyWhatsAppSms(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#E65100] rounded"
                />
                <span className="text-xs text-[#1F2937]/80 leading-relaxed">
                  Send confirmation & Google Maps location via WhatsApp & SMS
                </span>
              </label>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleReleaseLock}
                className="px-3.5 py-2.5 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7] transition-colors whitespace-nowrap"
              >
                Change Slot
              </button>
              <button
                type="submit"
                disabled={confirmLoading}
                className="flex-1 py-2.5 px-4 rounded-lg text-sm font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] disabled:opacity-50 transition-colors"
              >
                {confirmLoading ? 'Confirming...' : 'Confirm Reservation'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
