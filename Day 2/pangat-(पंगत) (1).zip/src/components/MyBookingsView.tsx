import { Calendar, Edit3, ExternalLink, MapPin, MessageSquare, Trash2, Users } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { cancelBooking, fetchBookings, modifyBooking } from '../api';
import type { Booking, MealSession, SeatingPreference } from '../types';

const SESSIONS: MealSession[] = ['Breakfast / Nashta', 'Lunch', 'Evening Snacks', 'Dinner'];
const SESSION_TIMES: Record<MealSession, string[]> = {
  'Breakfast / Nashta': ['08:30 AM', '09:30 AM', '10:30 AM'],
  Lunch: ['12:00 PM', '12:45 PM', '01:30 PM', '02:15 PM'],
  'Evening Snacks': ['04:30 PM', '05:30 PM', '06:15 PM'],
  Dinner: ['07:15 PM', '08:00 PM', '08:45 PM', '09:30 PM'],
};
const SEATING_OPTIONS: SeatingPreference[] = [
  'Indoor AC',
  'Outdoor Patio',
  'Family Booth',
  'Traditional Baithak Seating',
];

interface MyBookingsViewProps {
  onBrowseRestaurants: () => void;
  onInspectWhatsApp: (booking: Booking) => void;
}

export function MyBookingsView({ onBrowseRestaurants, onInspectWhatsApp }: MyBookingsViewProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editGuests, setEditGuests] = useState(4);
  const [editSession, setEditSession] = useState<MealSession>('Lunch');
  const [editTime, setEditTime] = useState('01:30 PM');
  const [editSeating, setEditSeating] = useState<SeatingPreference>('Indoor AC');
  const [actionError, setActionError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const loadBookings = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchBookings();
      setBookings(data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  const startEditing = (b: Booking) => {
    setEditingId(b.bookingId);
    setEditGuests(b.guests);
    setEditSession(b.session);
    setEditTime(b.time);
    setEditSeating(b.seatingPreference);
    setActionError(null);
  };

  const handleSaveEdit = async (bookingId: string) => {
    setBusyId(bookingId);
    setActionError(null);
    try {
      await modifyBooking(bookingId, {
        guests: editGuests,
        session: editSession,
        time: editTime,
        seatingPreference: editSeating,
      });
      setEditingId(null);
      await loadBookings();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to modify booking.');
    } finally {
      setBusyId(null);
    }
  };

  const handleCancel = async (bookingId: string) => {
    setBusyId(bookingId);
    setActionError(null);
    try {
      await cancelBooking(bookingId);
      await loadBookings();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to cancel booking.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#1F2937]">My Table Reservations</h1>
          <p className="text-sm text-[#1F2937]/70 mt-1">
            Modify party size or time slot, inspect WhatsApp confirmation cards, or cancel to
            immediately release tables.
          </p>
        </div>
        <button
          type="button"
          onClick={onBrowseRestaurants}
          className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] transition-colors"
        >
          Book Another Table
        </button>
      </div>

      {actionError && (
        <div
          role="alert"
          className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-800"
        >
          {actionError}
        </div>
      )}

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((n) => (
            <div key={n} className="h-36 rounded-xl bg-[#F3EFE7] animate-pulse" />
          ))}
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-10 text-center space-y-3">
          <Calendar className="h-8 w-8 text-[#E65100] mx-auto opacity-75" />
          <h2 className="font-serif text-xl font-bold text-[#1F2937]">No reservations yet</h2>
          <p className="text-sm text-[#1F2937]/65">
            Explore our 8 authentic Maharashtrian kitchens and reserve your table.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((b) => {
            const isEditing = editingId === b.bookingId;
            const isCancelled = b.status === 'Cancelled';

            return (
              <article
                key={b.bookingId}
                className={`bg-white rounded-xl border border-[#1F2937]/10 p-5 sm:p-6 space-y-4 ${
                  isCancelled ? 'opacity-65' : ''
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono font-semibold text-[#E65100] tabular-nums">
                        {b.bookingId}
                      </span>
                      <span aria-hidden="true" className="text-[#1F2937]/30">
                        ·
                      </span>
                      <span
                        className={`font-semibold ${
                          b.status === 'Confirmed'
                            ? 'text-emerald-700'
                            : b.status === 'Seated'
                              ? 'text-[#5C162E]'
                              : b.status === 'Cancelled'
                                ? 'text-red-700'
                                : 'text-[#1F2937]/70'
                        }`}
                      >
                        {b.status}
                      </span>
                    </div>
                    <h2 className="font-serif text-xl font-bold text-[#1F2937]">
                      {b.restaurantName}
                    </h2>
                    <p className="text-xs text-[#1F2937]/70 flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-[#E65100]" />
                      {b.restaurantLocality}, {b.restaurantCity}
                    </p>
                  </div>

                  <div className="text-left sm:text-right text-sm space-y-0.5">
                    <p className="font-semibold text-[#1F2937] tabular-nums">
                      {b.date} · {b.time}
                    </p>
                    <p className="text-xs text-[#1F2937]/70 tabular-nums">
                      {b.guests} Guests · {b.seatingPreference}
                    </p>
                  </div>
                </div>

                {b.specialRequests && (
                  <p className="text-xs text-[#1F2937]/75 bg-[#FAF7F2] rounded-lg px-3 py-2 border border-[#1F2937]/8">
                    Special Request: {b.specialRequests}
                  </p>
                )}

                {isEditing && (
                  <div className="bg-[#FAF7F2] rounded-lg p-4 border border-[#1F2937]/10 space-y-3">
                    <p className="text-xs font-semibold text-[#5C162E]">Modify Reservation</p>
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                      <div>
                        <label className="text-[11px] text-[#1F2937]/65 block mb-1">Guests</label>
                        <select
                          value={editGuests}
                          onChange={(e) => setEditGuests(Number(e.target.value))}
                          className="w-full rounded-md border border-[#1F2937]/15 bg-white px-2.5 py-2 text-xs"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((g) => (
                            <option key={g} value={g}>
                              {g} Guests
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-[#1F2937]/65 block mb-1">Session</label>
                        <select
                          value={editSession}
                          onChange={(e) => {
                            const nextSess = e.target.value as MealSession;
                            setEditSession(nextSess);
                            setEditTime(SESSION_TIMES[nextSess][0]);
                          }}
                          className="w-full rounded-md border border-[#1F2937]/15 bg-white px-2.5 py-2 text-xs"
                        >
                          {SESSIONS.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-[#1F2937]/65 block mb-1">Time</label>
                        <select
                          value={editTime}
                          onChange={(e) => setEditTime(e.target.value)}
                          className="w-full rounded-md border border-[#1F2937]/15 bg-white px-2.5 py-2 text-xs"
                        >
                          {SESSION_TIMES[editSession].map((t) => (
                            <option key={t} value={t}>
                              {t}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-[#1F2937]/65 block mb-1">Seating</label>
                        <select
                          value={editSeating}
                          onChange={(e) => setEditSeating(e.target.value as SeatingPreference)}
                          className="w-full rounded-md border border-[#1F2937]/15 bg-white px-2.5 py-2 text-xs"
                        >
                          {SEATING_OPTIONS.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="px-3 py-1.5 rounded-md text-xs font-medium text-[#1F2937] hover:bg-[#1F2937]/5"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={busyId === b.bookingId}
                        onClick={() => handleSaveEdit(b.bookingId)}
                        className="px-3.5 py-1.5 rounded-md text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] disabled:opacity-50"
                      >
                        {busyId === b.bookingId ? 'Saving...' : 'Save Changes'}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#1F2937]/8">
                  <div className="flex flex-wrap items-center gap-3 text-xs">
                    <a
                      href={b.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-medium text-[#5C162E] hover:text-[#E65100]"
                    >
                      <MapPin className="h-3.5 w-3.5" />
                      Google Maps Pin
                      <ExternalLink className="h-3 w-3" />
                    </a>
                    <button
                      type="button"
                      onClick={() => onInspectWhatsApp(b)}
                      className="inline-flex items-center gap-1 font-medium text-emerald-700 hover:text-emerald-900"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      WhatsApp Pass
                    </button>
                  </div>

                  {!isCancelled && b.status !== 'Completed' && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => startEditing(b)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#FAF7F2]"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                        Modify
                      </button>
                      <button
                        type="button"
                        disabled={busyId === b.bookingId}
                        onClick={() => handleCancel(b.bookingId)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-200 text-xs font-medium text-red-700 hover:bg-red-50 disabled:opacity-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Cancel & Release Table
                      </button>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
