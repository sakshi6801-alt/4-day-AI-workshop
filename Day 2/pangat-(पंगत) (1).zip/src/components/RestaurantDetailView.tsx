import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  MapPin,
  Phone,
  Star,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { submitReview } from '../api';
import type {
  Booking,
  MenuCategory,
  MenuItem,
  RestaurantWithMenu,
  SpiceLevel,
} from '../types';
import { BookingWidget } from './BookingWidget';
import { GoogleDocExportControl } from './GoogleDocExportControl';
import { SpiceIndicator } from './SpiceIndicator';
import { formatRestaurantMenuForDoc } from '../services/googleDocs';

const CATEGORIES: Array<'All' | MenuCategory> = [
  'All',
  'Special Thalis',
  'Starters & Farsan',
  'Main Course',
  'Breads (Bhakri/Poli)',
  'Desserts',
  'Beverages (Solkadhi/Piyush/Taak)',
];

interface RestaurantDetailViewProps {
  restaurant: RestaurantWithMenu;
  autoOpenBookingDrawer?: boolean;
  onBack: () => void;
  onRestaurantUpdated: (updated: RestaurantWithMenu) => void;
  onBookingConfirmed: (booking: Booking) => void;
}

export function RestaurantDetailView({
  restaurant,
  autoOpenBookingDrawer = false,
  onBack,
  onRestaurantUpdated,
  onBookingConfirmed,
}: RestaurantDetailViewProps) {
  const [activePhoto, setActivePhoto] = useState(restaurant.coverImage);
  const [selectedCategory, setSelectedCategory] = useState<'All' | MenuCategory>('All');
  const [dietaryFilter, setDietaryFilter] = useState<'All' | 'Pure Veg' | 'Non-Veg' | 'Jain'>('All');
  const [thaliOnly, setThaliOnly] = useState(false);
  const [maxSpice, setMaxSpice] = useState<SpiceLevel>(4);
  const [expandedThalis, setExpandedThalis] = useState<Record<string, boolean>>({});
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(autoOpenBookingDrawer);

  // Review form state
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewCity, setReviewCity] = useState<string>(restaurant.city);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewDish, setReviewDish] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewFeedback, setReviewFeedback] = useState<string | null>(null);

  useEffect(() => {
    setActivePhoto(restaurant.coverImage);
  }, [restaurant.id, restaurant.coverImage]);

  useEffect(() => {
    // Default expand the first Special Thali so Thali components are immediately discoverable
    const firstThali = restaurant.menu.find((m) => m.is_thali);
    if (firstThali) {
      setExpandedThalis({ [firstThali.id]: true });
    }
  }, [restaurant.id, restaurant.menu]);

  const filteredMenu = useMemo(() => {
    return restaurant.menu.filter((item) => {
      if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
      if (dietaryFilter === 'Pure Veg' && item.dietary !== 'Pure Veg') return false;
      if (dietaryFilter === 'Non-Veg' && item.dietary !== 'Non-Veg') return false;
      if (dietaryFilter === 'Jain' && !item.jain_friendly) return false;
      if (thaliOnly && !item.is_thali) return false;
      if (item.spice_level > maxSpice) return false;
      return true;
    });
  }, [restaurant.menu, selectedCategory, dietaryFilter, thaliOnly, maxSpice]);

  const toggleThaliExpand = (id: string) => {
    setExpandedThalis((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewAuthor.trim() || !reviewComment.trim()) return;
    setReviewSubmitting(true);
    setReviewFeedback(null);
    try {
      const updated = await submitReview(restaurant.id, {
        author: reviewAuthor.trim(),
        city: reviewCity.trim() || restaurant.city,
        rating: reviewRating,
        orderedDish: reviewDish.trim() || 'Special Thali',
        comment: reviewComment.trim(),
      });
      onRestaurantUpdated(updated);
      setReviewAuthor('');
      setReviewDish('');
      setReviewComment('');
      setReviewFeedback('Thank you — your review has been added.');
    } catch (err) {
      setReviewFeedback(err instanceof Error ? err.message : 'Unable to post review.');
    } finally {
      setReviewSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-24 lg:pb-16 space-y-8">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-[#1F2937]/75 hover:text-[#E65100] transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to all Maharashtrian restaurants
      </button>

      {/* Main Split: Left Content (Gallery, Info, Menu, Reviews) + Right Sticky Booking Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 space-y-10">
          {/* Header & Photo Gallery */}
          <section className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-9 aspect-[16/10] rounded-xl overflow-hidden bg-[#F3EFE7] border border-[#1F2937]/10">
                <img
                  src={activePhoto}
                  alt={restaurant.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="sm:col-span-3 grid grid-cols-3 sm:grid-cols-1 gap-2.5">
                {restaurant.galleryImages.map((imgUrl, idx) => (
                  <button
                    key={imgUrl}
                    type="button"
                    onClick={() => setActivePhoto(imgUrl)}
                    className={`aspect-[4/3] rounded-lg overflow-hidden border transition-all ${
                      activePhoto === imgUrl
                        ? 'border-[#E65100] ring-2 ring-[#E65100]/30'
                        : 'border-[#1F2937]/10 opacity-80 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={imgUrl}
                      alt={`${restaurant.name} gallery ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-[#1F2937]/10 p-6 space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C162E] font-semibold">
                    <span>{restaurant.regionalCuisines.join(' · ')}</span>
                    <span aria-hidden="true">·</span>
                    <span>{restaurant.pureVeg ? 'Pure Vegetarian' : 'Veg & Non-Veg Kitchen'}</span>
                  </div>
                  <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#1F2937] mt-1">
                    {restaurant.name}{' '}
                    <span className="text-2xl font-normal text-[#E65100]">
                      ({restaurant.marathiName})
                    </span>
                  </h1>
                </div>

                <div className="text-right">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F3EFE7] text-[#5C162E] font-semibold text-sm tabular-nums">
                    <Star className="h-4 w-4 fill-[#F59E0B] text-[#F59E0B]" />
                    {restaurant.rating}
                    <span className="text-xs font-normal text-[#1F2937]/65">
                      ({restaurant.reviewCount} reviews)
                    </span>
                  </div>
                  <p className="text-xs text-[#1F2937]/65 mt-1 tabular-nums">
                    Approx. ₹{restaurant.costForTwo} for two
                  </p>
                </div>
              </div>

              <p className="text-sm sm:text-base text-[#1F2937]/80 leading-relaxed">
                {restaurant.description}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-[#1F2937]/10 text-xs text-[#1F2937]/80">
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-[#E65100] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#1F2937]">{restaurant.address}</p>
                    <a
                      href={restaurant.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#5C162E] font-semibold hover:text-[#E65100] mt-0.5"
                    >
                      View Pin on Google Maps
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-[#E65100] shrink-0" />
                    <span>{restaurant.hours}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-[#E65100] shrink-0" />
                    <span className="font-mono tabular-nums">{restaurant.phone}</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Interactive Digital Menu */}
          <section className="space-y-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#1F2937]">
                  Digital Menu & Thali Breakdown
                </h2>
                <p className="text-sm text-[#1F2937]/70 mt-0.5">
                  Filter by regional course, dietary preference, Thalis, or maximum spice heat.
                </p>
              </div>
              <GoogleDocExportControl
                buttonLabel="Save Menu to Google Docs"
                docTitle={`Pangat Menu — ${restaurant.name} (${restaurant.city})`}
                getDocContent={() => formatRestaurantMenuForDoc(restaurant)}
              />
            </div>

            {/* Category Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    selectedCategory === cat
                      ? 'bg-[#5C162E] text-white'
                      : 'bg-[#F3EFE7] text-[#1F2937]/80 hover:bg-[#1F2937]/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Dietary & Spice Filters */}
            <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-1.5">
                {(['All', 'Pure Veg', 'Non-Veg', 'Jain'] as const).map((diet) => (
                  <button
                    key={diet}
                    type="button"
                    onClick={() => setDietaryFilter(diet)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                      dietaryFilter === diet
                        ? 'bg-[#E65100] text-white'
                        : 'bg-[#FAF7F2] text-[#1F2937]/80 hover:bg-[#F3EFE7]'
                    }`}
                  >
                    {diet === 'Jain' ? 'Jain-Friendly' : diet}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setThaliOnly((v) => !v)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap border ${
                    thaliOnly
                      ? 'bg-[#5C162E] border-[#5C162E] text-white'
                      : 'bg-white border-[#1F2937]/15 text-[#1F2937]/80 hover:bg-[#FAF7F2]'
                  }`}
                >
                  Thalis Only
                </button>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="font-medium text-[#1F2937]/75">Max Heat:</span>
                <div className="flex items-center gap-1 bg-[#FAF7F2] p-1 rounded-lg border border-[#1F2937]/10">
                  {([1, 2, 3, 4] as SpiceLevel[]).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setMaxSpice(lvl)}
                      className={`px-2.5 py-1 rounded text-xs font-semibold tabular-nums transition-colors ${
                        maxSpice === lvl
                          ? 'bg-[#E65100] text-white'
                          : 'text-[#1F2937]/70 hover:text-[#1F2937]'
                      }`}
                    >
                      {lvl === 4 ? '4 (Fiery)' : lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Menu Items List */}
            {filteredMenu.length === 0 ? (
              <div className="bg-white rounded-xl border border-[#1F2937]/10 p-8 text-center space-y-2">
                <p className="font-serif text-lg font-semibold text-[#1F2937]">
                  No dishes match these filters
                </p>
                <p className="text-xs text-[#1F2937]/65">
                  Try increasing the max spice level or switching back to All categories.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('All');
                    setDietaryFilter('All');
                    setThaliOnly(false);
                    setMaxSpice(4);
                  }}
                  className="mt-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-[#E65100] border border-[#E65100]/30 hover:bg-[#E65100]/5"
                >
                  Reset Menu Filters
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredMenu.map((item: MenuItem) => {
                  const isExpanded = Boolean(expandedThalis[item.id]);
                  return (
                    <div
                      key={item.id}
                      className={`bg-white rounded-xl border border-[#1F2937]/10 p-5 transition-opacity ${
                        item.in_stock ? '' : 'opacity-60'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1.5 flex-1">
                          {/* Clean unboxed inline metadata line */}
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs">
                            <span
                              className={`font-semibold ${
                                item.dietary === 'Pure Veg' ? 'text-emerald-700' : 'text-[#C84B31]'
                              }`}
                            >
                              {item.dietary}
                            </span>
                            {item.jain_friendly && (
                              <>
                                <span aria-hidden="true" className="text-[#1F2937]/30">
                                  ·
                                </span>
                                <span className="text-emerald-700 font-medium">Jain Option</span>
                              </>
                            )}
                            {item.is_thali && (
                              <>
                                <span aria-hidden="true" className="text-[#1F2937]/30">
                                  ·
                                </span>
                                <span className="font-semibold text-[#5C162E]">
                                  {item.thali_type} Thali
                                </span>
                              </>
                            )}
                            {item.is_chefs_special && (
                              <>
                                <span aria-hidden="true" className="text-[#1F2937]/30">
                                  ·
                                </span>
                                <span className="font-semibold text-[#E65100]">Chef’s Special</span>
                              </>
                            )}
                            {!item.in_stock && (
                              <>
                                <span aria-hidden="true" className="text-[#1F2937]/30">
                                  ·
                                </span>
                                <span className="font-semibold text-red-700">Sold Out Today</span>
                              </>
                            )}
                          </div>

                          <h3 className="font-serif text-lg font-bold text-[#1F2937]">
                            {item.name}
                            {item.marathiName && (
                              <span className="text-sm font-normal text-[#1F2937]/60 ml-2">
                                {item.marathiName}
                              </span>
                            )}
                          </h3>

                          <p className="text-sm text-[#1F2937]/75 leading-relaxed">
                            {item.description}
                          </p>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-1">
                            <SpiceIndicator level={item.spice_level} />
                            <span className="text-xs text-[#1F2937]/55">
                              {item.regional_style} · {item.category}
                            </span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-base font-bold text-[#1F2937] tabular-nums">
                            ₹{item.price}
                          </span>
                        </div>
                      </div>

                      {/* Expandable Thali Components Breakdown */}
                      {item.is_thali && item.thali_components && item.thali_components.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-[#1F2937]/8">
                          <button
                            type="button"
                            onClick={() => toggleThaliExpand(item.id)}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5C162E] hover:text-[#E65100] transition-colors"
                          >
                            {isExpanded ? (
                              <>
                                <ChevronUp className="h-3.5 w-3.5" />
                                Hide {item.thali_components.length} Thali Items Included
                              </>
                            ) : (
                              <>
                                <ChevronDown className="h-3.5 w-3.5" />
                                View {item.thali_components.length} Thali Items Included
                              </>
                            )}
                          </button>

                          {isExpanded && (
                            <ul className="mt-2.5 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs text-[#1F2937]/80 bg-[#FAF7F2] rounded-lg p-3.5 border border-[#1F2937]/8">
                              {item.thali_components.map((comp) => (
                                <li key={comp} className="flex items-start gap-2">
                                  <span className="text-[#E65100] font-bold" aria-hidden="true">
                                    •
                                  </span>
                                  <span>{comp}</span>
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Guest Reviews & Write Review */}
          <section className="space-y-5 pt-4 border-t border-[#1F2937]/10">
            <h2 className="font-serif text-2xl font-bold text-[#1F2937]">Diner Stories & Reviews</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {restaurant.reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-[#1F2937]">{rev.author}</p>
                      <p className="text-xs text-[#1F2937]/60">
                        {rev.city} · {rev.date}
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#5C162E] tabular-nums">
                      <Star className="h-3.5 w-3.5 fill-[#F59E0B] text-[#F59E0B]" />
                      {rev.rating}
                    </span>
                  </div>
                  <p className="text-sm text-[#1F2937]/80 leading-relaxed">{rev.comment}</p>
                  <p className="text-xs font-medium text-[#E65100]">Ordered: {rev.orderedDish}</p>
                </div>
              ))}
            </div>

            <form
              onSubmit={handleReviewSubmit}
              className="bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-4"
            >
              <h3 className="font-serif text-lg font-bold text-[#1F2937]">Share Your Experience</h3>
              {reviewFeedback && (
                <p className="text-xs font-medium text-emerald-700">{reviewFeedback}</p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  value={reviewAuthor}
                  onChange={(e) => setReviewAuthor(e.target.value)}
                  placeholder="Your Name"
                  className="rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm focus:outline-2 focus:outline-[#E65100]"
                />
                <input
                  type="text"
                  value={reviewCity}
                  onChange={(e) => setReviewCity(e.target.value)}
                  placeholder="Your City"
                  className="rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm focus:outline-2 focus:outline-[#E65100]"
                />
                <select
                  value={reviewRating}
                  onChange={(e) => setReviewRating(Number(e.target.value))}
                  aria-label="Rating"
                  className="rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm focus:outline-2 focus:outline-[#E65100]"
                >
                  <option value={5}>5 Stars — Exceptional</option>
                  <option value={4}>4 Stars — Very Good</option>
                  <option value={3}>3 Stars — Good</option>
                  <option value={2}>2 Stars — Average</option>
                </select>
              </div>
              <input
                type="text"
                value={reviewDish}
                onChange={(e) => setReviewDish(e.target.value)}
                placeholder="Which Thali or dish did you order?"
                className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm focus:outline-2 focus:outline-[#E65100]"
              />
              <textarea
                rows={2}
                required
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="Tell fellow diners about the rassa, bhakri, or baithak hospitality..."
                className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-sm focus:outline-2 focus:outline-[#E65100]"
              />
              <button
                type="submit"
                disabled={reviewSubmitting}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#5C162E] hover:bg-[#471023] disabled:opacity-50 transition-colors"
              >
                {reviewSubmitting ? 'Posting...' : 'Post Review'}
              </button>
            </form>
          </section>
        </div>

        {/* Sticky Sidebar Booking Widget on Desktop */}
        <aside className="hidden lg:block lg:col-span-4 lg:sticky lg:top-24">
          <BookingWidget restaurant={restaurant} onBookingConfirmed={onBookingConfirmed} />
        </aside>
      </div>

      {/* Mobile Bottom Sticky Booking Trigger (keeps height well under 15% of viewport) */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-[#FAF7F2]/95 backdrop-blur-sm border-t border-[#1F2937]/12 px-4 py-2.5 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-[#1F2937] truncate">{restaurant.name}</p>
          <p className="text-[11px] text-[#1F2937]/65 tabular-nums">
            ₹{restaurant.costForTwo} for two · Live slots
          </p>
        </div>
        <button
          type="button"
          onClick={() => setMobileDrawerOpen(true)}
          className="px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] whitespace-nowrap shrink-0"
        >
          Book a Table
        </button>
      </div>

      {/* Mobile Booking Drawer */}
      {mobileDrawerOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-[#1F2937]/60 flex items-end"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#FAF7F2] w-full max-h-[90vh] rounded-t-2xl overflow-y-auto p-4 space-y-3">
            <div className="flex items-center justify-between pb-1">
              <span className="font-serif text-lg font-bold text-[#5C162E]">
                Reserve at {restaurant.name}
              </span>
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                aria-label="Close booking drawer"
                className="p-2 rounded-lg text-[#1F2937] hover:bg-[#1F2937]/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <BookingWidget
              restaurant={restaurant}
              onBookingConfirmed={(b) => {
                setMobileDrawerOpen(false);
                onBookingConfirmed(b);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
