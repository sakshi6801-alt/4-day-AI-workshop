import {
  ExternalLink,
  FilePlus2,
  FileText,
  LogOut,
  RefreshCw,
  Search,
  Trash2,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import { getAccessToken, getCurrentUser, googleSignIn, initAuth, logout } from '../firebaseAuth';
import {
  appendTextToGoogleDoc,
  createGoogleDocWithText,
  type DriveDocSummary,
  formatBookingForDoc,
  formatRestaurantMenuForDoc,
  listGoogleDocs,
  type ParsedGoogleDoc,
  readGoogleDoc,
  trashGoogleDoc,
} from '../services/googleDocs';
import type { Booking, RestaurantWithMenu } from '../types';
import { GoogleSignInButton } from './GoogleSignInButton';

interface GoogleDocsWorkspaceProps {
  restaurants: RestaurantWithMenu[];
  bookings: Booking[];
  initialRestaurantId?: string;
}

type PendingAction =
  | { type: 'create'; title: string; content: string }
  | { type: 'append'; documentId: string; title: string; content: string }
  | { type: 'trash'; documentId: string; title: string };

export function GoogleDocsWorkspace({
  restaurants,
  bookings,
  initialRestaurantId,
}: GoogleDocsWorkspaceProps) {
  const [needsAuth, setNeedsAuth] = useState(!getAccessToken());
  const [user, setUser] = useState<User | null>(getCurrentUser());
  const [signingIn, setSigningIn] = useState(false);

  const [docs, setDocs] = useState<DriveDocSummary[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<ParsedGoogleDoc | null>(null);
  const [loadingDocContent, setLoadingDocContent] = useState(false);

  const [customTitle, setCustomTitle] = useState('');
  const [customNotes, setCustomNotes] = useState('');
  const [selectedRestId, setSelectedRestId] = useState(
    initialRestaurantId || restaurants[0]?.id || ''
  );
  const [selectedBookingId, setSelectedBookingId] = useState(bookings[0]?.bookingId || '');

  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);
  const [mutating, setMutating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchDocsList = useCallback(async (query = '') => {
    const token = getAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    setLoadingDocs(true);
    setErrorMsg(null);
    try {
      const files = await listGoogleDocs(token, query);
      setDocs(files);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to fetch Google Docs.');
    } finally {
      setLoadingDocs(false);
    }
  }, []);

  useEffect(() => {
    const unsub = initAuth(
      (authedUser) => {
        setUser(authedUser);
        setNeedsAuth(false);
        fetchDocsList();
      },
      () => {
        setUser(null);
        setNeedsAuth(true);
      }
    );
    return () => unsub();
  }, [fetchDocsList]);

  useEffect(() => {
    if (getAccessToken()) {
      setNeedsAuth(false);
      fetchDocsList();
    }
  }, [fetchDocsList]);

  const handleLogin = async () => {
    setSigningIn(true);
    setErrorMsg(null);
    try {
      const result = await googleSignIn();
      setUser(result.user);
      setNeedsAuth(false);
      await fetchDocsList();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      setSigningIn(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    setUser(null);
    setNeedsAuth(true);
    setDocs([]);
    setSelectedDoc(null);
  };

  const handleSelectDoc = async (docId: string) => {
    const token = getAccessToken();
    if (!token) {
      setNeedsAuth(true);
      return;
    }
    setLoadingDocContent(true);
    setErrorMsg(null);
    try {
      const parsed = await readGoogleDoc(token, docId);
      setSelectedDoc(parsed);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to read Google Doc.');
    } finally {
      setLoadingDocContent(false);
    }
  };

  const executePendingAction = async () => {
    if (!pendingAction) return;
    const token = getAccessToken();
    if (!token) {
      setNeedsAuth(true);
      setPendingAction(null);
      return;
    }

    setMutating(true);
    setErrorMsg(null);
    setStatusMessage(null);
    try {
      if (pendingAction.type === 'create') {
        const created = await createGoogleDocWithText(
          token,
          pendingAction.title,
          pendingAction.content
        );
        setSelectedDoc(created);
        setCustomTitle('');
        setCustomNotes('');
        setStatusMessage(`Created "${created.title}" in your Google Docs.`);
        await fetchDocsList(searchQuery);
      } else if (pendingAction.type === 'append') {
        const updated = await appendTextToGoogleDoc(
          token,
          pendingAction.documentId,
          pendingAction.content
        );
        setSelectedDoc(updated);
        setCustomNotes('');
        setStatusMessage(`Updated "${updated.title}" with your Pangat details.`);
      } else if (pendingAction.type === 'trash') {
        await trashGoogleDoc(token, pendingAction.documentId);
        if (selectedDoc?.documentId === pendingAction.documentId) {
          setSelectedDoc(null);
        }
        setStatusMessage(`Moved "${pendingAction.title}" to Google Drive Trash.`);
        await fetchDocsList(searchQuery);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google Docs operation failed.');
    } finally {
      setMutating(false);
      setPendingAction(null);
    }
  };

  const selectedRestaurant = restaurants.find((r) => r.id === selectedRestId);
  const selectedBooking = bookings.find((b) => b.bookingId === selectedBookingId);

  if (needsAuth) {
    return (
      <div className="bg-white rounded-xl border border-[#1F2937]/12 p-6 sm:p-8 space-y-5">
        <div className="flex items-start gap-3">
          <FileText className="h-6 w-6 text-[#E65100] shrink-0 mt-0.5" />
          <div className="space-y-1.5">
            <h2 className="font-serif text-2xl font-bold text-[#1F2937]">
              Google Docs Menu & Itinerary Studio
            </h2>
            <p className="text-sm text-[#1F2937]/75 max-w-2xl leading-relaxed">
              Sign in with Google to browse and read your Google Docs, save formatted Pangat Thali
              menus and reservation passes directly to Google Docs, or append dining notes to
              existing documents.
            </p>
          </div>
        </div>

        {errorMsg && (
          <div className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs text-red-800">
            {errorMsg}
          </div>
        )}

        <GoogleSignInButton onClick={handleLogin} loading={signingIn} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Connected Account Header */}
      <div className="bg-white rounded-xl border border-[#1F2937]/12 p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <FileText className="h-5 w-5 text-[#E65100]" />
          <div>
            <h2 className="font-serif text-xl font-bold text-[#1F2937]">
              Google Docs & Drive Workspace
            </h2>
            <p className="text-xs text-[#1F2937]/65">
              Connected as {user?.displayName || user?.email || 'Google Account'}
              {user?.email ? ` (${user.email})` : ''}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7]"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign Out
        </button>
      </div>

      {statusMessage && (
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs font-medium text-emerald-800">
          {statusMessage}
        </div>
      )}

      {errorMsg && (
        <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-xs font-medium text-red-800">
          {errorMsg}
        </div>
      )}

      {/* Quick Generators: Export Restaurant Menu or Booking to Google Docs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-3">
          <h3 className="font-serif text-lg font-bold text-[#5C162E]">
            Export Restaurant Thali Menu to Google Docs
          </h3>
          <p className="text-xs text-[#1F2937]/70">
            Generate a shareable Google Doc with complete Thali breakdowns, spice heat levels, and
            prices.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <select
              value={selectedRestId}
              onChange={(e) => setSelectedRestId(e.target.value)}
              aria-label="Select restaurant to export"
              className="flex-1 rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs font-medium"
            >
              {restaurants.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.city})
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={!selectedRestaurant}
              onClick={() => {
                if (!selectedRestaurant) return;
                setPendingAction({
                  type: 'create',
                  title: `Pangat Menu — ${selectedRestaurant.name} (${selectedRestaurant.city})`,
                  content: formatRestaurantMenuForDoc(selectedRestaurant),
                });
              }}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] whitespace-nowrap"
            >
              <FilePlus2 className="h-3.5 w-3.5" />
              Create Menu Doc
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-3">
          <h3 className="font-serif text-lg font-bold text-[#5C162E]">
            Save Reservation Pass to Google Docs
          </h3>
          <p className="text-xs text-[#1F2937]/70">
            Save a confirmed table booking pass with seating details and Google Maps pin to Docs.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <select
              value={selectedBookingId}
              onChange={(e) => setSelectedBookingId(e.target.value)}
              aria-label="Select booking to export"
              className="flex-1 rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs font-medium"
            >
              {bookings.length === 0 ? (
                <option value="">No bookings yet</option>
              ) : (
                bookings.map((b) => (
                  <option key={b.bookingId} value={b.bookingId}>
                    {b.bookingId} · {b.restaurantName} ({b.date})
                  </option>
                ))
              )}
            </select>
            <button
              type="button"
              disabled={!selectedBooking}
              onClick={() => {
                if (!selectedBooking) return;
                setPendingAction({
                  type: 'create',
                  title: `Pangat Pass ${selectedBooking.bookingId} — ${selectedBooking.restaurantName}`,
                  content: formatBookingForDoc(selectedBooking),
                });
              }}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#5C162E] hover:bg-[#471023] disabled:opacity-50 whitespace-nowrap"
            >
              <FilePlus2 className="h-3.5 w-3.5" />
              Save Booking Doc
            </button>
          </div>
        </div>
      </div>

      {/* Browse, Read, Append & Manage Existing Google Docs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-serif text-lg font-bold text-[#1F2937]">Your Google Docs</h3>
            <button
              type="button"
              onClick={() => fetchDocsList(searchQuery)}
              aria-label="Refresh Google Docs list"
              className="p-2 rounded-lg border border-[#1F2937]/12 hover:bg-[#F3EFE7]"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loadingDocs ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              fetchDocsList(searchQuery);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="h-3.5 w-3.5 text-[#1F2937]/45 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Google Docs by title..."
                className="w-full pl-8 pr-3 py-2 rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] text-xs"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-2 rounded-lg bg-[#F3EFE7] text-xs font-semibold text-[#1F2937] hover:bg-[#1F2937]/10"
            >
              Search
            </button>
          </form>

          {loadingDocs ? (
            <div className="space-y-2">
              {[1, 2, 3].map((n) => (
                <div key={n} className="h-14 rounded-lg bg-[#F3EFE7] animate-pulse" />
              ))}
            </div>
          ) : docs.length === 0 ? (
            <p className="text-xs text-[#1F2937]/65 py-6 text-center">
              No Google Docs found. Create a new Menu or Booking Doc above.
            </p>
          ) : (
            <div className="divide-y divide-[#1F2937]/8 max-h-96 overflow-y-auto">
              {docs.map((doc) => {
                const active = selectedDoc?.documentId === doc.id;
                return (
                  <div
                    key={doc.id}
                    className={`py-3 px-2 rounded-lg flex items-center justify-between gap-2 ${
                      active ? 'bg-[#F3EFE7]' : 'hover:bg-[#FAF7F2]'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleSelectDoc(doc.id)}
                      className="text-left min-w-0 flex-1"
                    >
                      <p className="text-xs font-semibold text-[#1F2937] truncate">{doc.name}</p>
                      {doc.modifiedTime && (
                        <p className="text-[11px] text-[#1F2937]/55 mt-0.5 tabular-nums">
                          Updated {new Date(doc.modifiedTime).toLocaleDateString('en-IN')}
                        </p>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPendingAction({
                          type: 'trash',
                          documentId: doc.id,
                          title: doc.name,
                        })
                      }
                      aria-label={`Move ${doc.name} to trash`}
                      className="p-1.5 rounded-md text-red-700 hover:bg-red-50 shrink-0"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Document Reader & Note Appender / New Custom Doc Creator */}
        <div className="lg:col-span-7 space-y-5">
          {selectedDoc ? (
            <div className="bg-white rounded-xl border border-[#1F2937]/10 p-5 space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-[#1F2937]/10">
                <div>
                  <h3 className="font-serif text-xl font-bold text-[#1F2937]">
                    {selectedDoc.title}
                  </h3>
                  <p className="text-[11px] font-mono text-[#1F2937]/55 mt-0.5">
                    ID: {selectedDoc.documentId}
                  </p>
                </div>
                <a
                  href={selectedDoc.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#5C162E]/25 text-xs font-semibold text-[#5C162E] hover:bg-[#F3EFE7]"
                >
                  Open in Google Docs
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>

              {loadingDocContent ? (
                <div className="h-48 rounded-lg bg-[#F3EFE7] animate-pulse" />
              ) : (
                <pre className="bg-[#FAF7F2] rounded-lg border border-[#1F2937]/8 p-4 text-xs text-[#1F2937] whitespace-pre-wrap font-sans leading-relaxed max-h-72 overflow-y-auto">
                  {selectedDoc.textContent.trim() || '(This document is currently empty)'}
                </pre>
              )}

              <div className="space-y-2 pt-2 border-t border-[#1F2937]/10">
                <label className="text-xs font-semibold text-[#1F2937]/80 block">
                  Append Notes or Event Checklist to "{selectedDoc.title}"
                </label>
                <textarea
                  rows={3}
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder="e.g., Confirm 12 Baithak seats, add 4 Ukadiche Modak platters..."
                  className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
                />
                <button
                  type="button"
                  disabled={!customNotes.trim()}
                  onClick={() =>
                    setPendingAction({
                      type: 'append',
                      documentId: selectedDoc.documentId,
                      title: selectedDoc.title,
                      content: customNotes.trim(),
                    })
                  }
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#E65100] hover:bg-[#C84B31] disabled:opacity-50"
                >
                  Append to Document
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-[#1F2937]/10 p-6 space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#1F2937]">
                Create a Custom Banquet or Dining Plan Doc
              </h3>
              <p className="text-xs text-[#1F2937]/70">
                Select any document on the left to read or append text, or start a new Google Doc
                below.
              </p>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="Document title (e.g., Diwali Family Pangat Feast Plan)"
                className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
              />
              <textarea
                rows={4}
                value={customNotes}
                onChange={(e) => setCustomNotes(e.target.value)}
                placeholder="Write guest list, regional Thali preferences, or catering notes..."
                className="w-full rounded-lg border border-[#1F2937]/15 bg-[#FAF7F2] px-3 py-2 text-xs"
              />
              <button
                type="button"
                disabled={!customTitle.trim()}
                onClick={() =>
                  setPendingAction({
                    type: 'create',
                    title: customTitle.trim(),
                    content: customNotes.trim(),
                  })
                }
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#5C162E] hover:bg-[#471023] disabled:opacity-50"
              >
                Create New Google Doc
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mandatory Explicit User Confirmation Dialog before Writing/Modifying/Trashing Docs */}
      {pendingAction && (
        <div
          className="fixed inset-0 z-50 bg-[#1F2937]/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="gdocs-confirm-title"
        >
          <div className="bg-[#FAF7F2] w-full max-w-md rounded-xl border border-[#1F2937]/15 shadow-xl p-6 space-y-4">
            <h3 id="gdocs-confirm-title" className="font-serif text-xl font-bold text-[#5C162E]">
              {pendingAction.type === 'trash'
                ? 'Move Google Doc to Trash?'
                : pendingAction.type === 'append'
                  ? 'Update Google Doc?'
                  : 'Create New Google Doc?'}
            </h3>

            <p className="text-sm text-[#1F2937]/80 leading-relaxed">
              {pendingAction.type === 'trash'
                ? `Are you sure you want to move "${pendingAction.title}" to your Google Drive Trash?`
                : pendingAction.type === 'append'
                  ? `Confirm appending your new text to "${pendingAction.title}" in Google Docs?`
                  : `Confirm creating a new Google Doc titled "${pendingAction.title}" in your Google Drive?`}
            </p>

            {pendingAction.type !== 'trash' && pendingAction.content && (
              <div className="bg-white rounded-lg border border-[#1F2937]/10 p-3 text-xs text-[#1F2937]/75 max-h-32 overflow-y-auto whitespace-pre-line">
                {pendingAction.content.slice(0, 320)}
                {pendingAction.content.length > 320 ? '...' : ''}
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={mutating}
                onClick={() => setPendingAction(null)}
                className="px-4 py-2 rounded-lg border border-[#1F2937]/15 text-xs font-medium text-[#1F2937] hover:bg-[#F3EFE7]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={mutating}
                onClick={executePendingAction}
                className={`px-4 py-2 rounded-lg text-xs font-semibold text-white transition-colors disabled:opacity-50 ${
                  pendingAction.type === 'trash'
                    ? 'bg-red-700 hover:bg-red-800'
                    : 'bg-[#E65100] hover:bg-[#C84B31]'
                }`}
              >
                {mutating
                  ? 'Processing...'
                  : pendingAction.type === 'trash'
                    ? 'Confirm Move to Trash'
                    : 'Confirm & Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
