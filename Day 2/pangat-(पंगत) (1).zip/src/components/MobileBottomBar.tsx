import { CalendarCheck2, Compass, Film, Store } from 'lucide-react';
import type { ActiveRoute } from './TopNav';

interface MobileBottomBarProps {
  activeRoute: ActiveRoute;
  onNavigate: (route: ActiveRoute) => void;
  onJumpToFilm: () => void;
  forceShow?: boolean;
  stickyMode?: boolean;
}

export function MobileBottomBar({
  activeRoute,
  onNavigate,
  onJumpToFilm,
  forceShow = false,
  stickyMode = false,
}: MobileBottomBarProps) {
  const containerVisibility = forceShow ? 'block' : 'md:hidden';
  const positionClass = stickyMode ? 'sticky bottom-0 left-0 right-0' : 'fixed bottom-0 left-0 right-0';

  const tabClass = (active: boolean) =>
    `flex flex-col items-center justify-center min-h-[44px] py-1.5 transition-colors ${
      active ? 'text-[#E65100] font-semibold' : 'text-[#1F2937]/65 hover:text-[#1F2937]'
    }`;

  return (
    <nav
      aria-label="Mobile bottom navigation"
      className={`${containerVisibility} ${positionClass} z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-[#1F2937]/12 pb-[env(safe-area-inset-bottom)]`}
    >
      <div className="grid grid-cols-4 items-center h-14">
        <button
          type="button"
          onClick={() => onNavigate('discover')}
          className={tabClass(activeRoute === 'discover' || activeRoute === 'restaurant')}
        >
          <Compass className="h-5 w-5" />
          <span className="text-[11px] leading-tight mt-0.5 whitespace-nowrap">Discover</span>
        </button>

        <button type="button" onClick={onJumpToFilm} className={tabClass(false)}>
          <Film className="h-5 w-5" />
          <span className="text-[11px] leading-tight mt-0.5 whitespace-nowrap">Feast Film</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('bookings')}
          className={tabClass(activeRoute === 'bookings')}
        >
          <CalendarCheck2 className="h-5 w-5" />
          <span className="text-[11px] leading-tight mt-0.5 whitespace-nowrap">Bookings</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('partner')}
          className={tabClass(activeRoute === 'partner')}
        >
          <Store className="h-5 w-5" />
          <span className="text-[11px] leading-tight mt-0.5 whitespace-nowrap">Partner</span>
        </button>
      </div>
    </nav>
  );
}
