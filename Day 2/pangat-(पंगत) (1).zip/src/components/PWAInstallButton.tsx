import { Check, Copy, Download, Share, Smartphone, X } from 'lucide-react';
import { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  mobilePreviewActive?: boolean;
  onToggleMobilePreview?: () => void;
}

export function PWAInstallButton({
  compact = false,
  mobilePreviewActive = false,
  onToggleMobilePreview,
}: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleAction = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuideModal(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      // clipboard blocked in sandbox
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className={
          compact
            ? 'inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] rounded-lg border border-[#5C162E]/20 bg-white text-xs font-semibold text-[#5C162E] hover:bg-[#F3EFE7] transition-colors whitespace-nowrap shrink-0'
            : 'inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] rounded-lg border border-[#5C162E]/25 bg-white text-xs sm:text-sm font-semibold text-[#5C162E] hover:bg-[#F3EFE7] transition-colors whitespace-nowrap shrink-0'
        }
      >
        {isInstallable ? (
          <Download className="h-4 w-4 text-[#E65100]" />
        ) : (
          <Smartphone className="h-4 w-4 text-[#E65100]" />
        )}
        <span>{isInstallable ? 'Install App' : isIOS ? 'Install on iOS' : 'Get Mobile App'}</span>
      </button>

      {showGuideModal && (
        <div
          className="fixed inset-0 z-50 bg-[#1F2937]/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-title"
        >
          <div className="bg-[#FAF7F2] w-full max-w-md rounded-2xl border border-[#1F2937]/15 shadow-xl overflow-hidden">
            <div className="bg-[#5C162E] text-white px-5 py-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src="/pwa-192x192.png"
                  alt="Pangat App Icon"
                  className="h-10 w-10 rounded-xl border border-white/20"
                />
                <div>
                  <h3 id="pwa-install-title" className="font-serif text-lg font-bold">
                    Pangat Mobile App
                  </h3>
                  <p className="text-xs text-amber-200">Installable Android & iOS PWA</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="Close install instructions"
                className="p-2 rounded-lg text-white/80 hover:text-white hover:bg-white/10 min-h-[40px] min-w-[40px] flex items-center justify-center"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-sm text-[#1F2937]">
              {isIOS ? (
                <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4 space-y-2">
                  <p className="font-semibold text-[#5C162E]">Install on iPhone / iPad (Safari)</p>
                  <ol className="list-decimal list-inside space-y-1.5 text-xs text-[#1F2937]/80 leading-relaxed">
                    <li>
                      Tap the <Share className="inline h-3.5 w-3.5 mx-0.5 text-[#E65100]" />{' '}
                      <strong>Share</strong> icon in Safari’s bottom toolbar.
                    </li>
                    <li>
                      Scroll down and tap <strong>Add to Home Screen</strong>.
                    </li>
                    <li>
                      Tap <strong>Add</strong> to launch Pangat full-screen like a native app.
                    </li>
                  </ol>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4 space-y-1.5">
                    <p className="font-semibold text-[#5C162E] text-xs uppercase tracking-wider">
                      Android (Chrome / Edge)
                    </p>
                    <p className="text-xs text-[#1F2937]/80 leading-relaxed">
                      Open this app URL directly in Chrome on your phone (outside embedded preview)
                      and tap <strong>Install App</strong> or <strong>Menu → Add to Home screen</strong>.
                    </p>
                  </div>

                  <div className="bg-white rounded-xl border border-[#1F2937]/10 p-4 space-y-1.5">
                    <p className="font-semibold text-[#5C162E] text-xs uppercase tracking-wider">
                      iPhone / iPad (Safari)
                    </p>
                    <p className="text-xs text-[#1F2937]/80 leading-relaxed">
                      Open in Safari, tap the <strong>Share</strong> icon, and choose{' '}
                      <strong>Add to Home Screen</strong>.
                    </p>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 min-h-[44px] rounded-xl border border-[#1F2937]/15 bg-white text-xs font-semibold text-[#1F2937] hover:bg-[#F3EFE7] transition-colors"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="h-4 w-4 text-emerald-700" />
                      Link Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4 text-[#E65100]" />
                      Copy App Link
                    </>
                  )}
                </button>

                {onToggleMobilePreview &&
                  typeof window !== 'undefined' &&
                  !window.location.search.includes('mobile_app=1') && (
                    <button
                      type="button"
                      onClick={() => {
                        onToggleMobilePreview();
                        setShowGuideModal(false);
                      }}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 min-h-[44px] rounded-xl bg-[#E65100] text-xs font-semibold text-white hover:bg-[#C84B31] transition-colors"
                    >
                      <Smartphone className="h-4 w-4" />
                      {mobilePreviewActive ? 'Exit Phone Frame' : 'Preview Phone App'}
                    </button>
                  )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
