import { Flame } from 'lucide-react';
import type { SpiceLevel } from '../types';

const SPICE_LABELS: Record<SpiceLevel, string> = {
  1: 'Mild',
  2: 'Medium',
  3: 'Spicy',
  4: 'Kolhapuri / Saoji Fiery',
};

const SPICE_COLORS: Record<SpiceLevel, string> = {
  1: 'text-amber-700',
  2: 'text-[#C84B31]',
  3: 'text-[#E65100]',
  4: 'text-[#5C162E]',
};

export function SpiceIndicator({ level, compact = false }: { level: SpiceLevel; compact?: boolean }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 text-xs font-medium ${SPICE_COLORS[level]}`}
      title={`Spice Level ${level}/4: ${SPICE_LABELS[level]}`}
    >
      <span className="inline-flex items-center" aria-hidden="true">
        {[1, 2, 3, 4].map((idx) => (
          <Flame
            key={idx}
            className={`h-3.5 w-3.5 ${
              idx <= level ? 'fill-current opacity-100' : 'opacity-20'
            }`}
          />
        ))}
      </span>
      {!compact && <span className="whitespace-nowrap">{SPICE_LABELS[level]}</span>}
    </span>
  );
}
