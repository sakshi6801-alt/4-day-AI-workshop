export type CityHub =
  | 'Mumbai'
  | 'Pune'
  | 'Nagpur'
  | 'Nashik'
  | 'Kolhapur'
  | 'Chhatrapati Sambhajinagar'
  | 'Satara';

export type RegionalCuisine =
  | 'Malvani & Konkani'
  | 'Kolhapuri'
  | 'Varhadi & Nagpuri'
  | 'Puneri & Deshastha'
  | 'Khandeshi & Marathwada';

export type MenuCategory =
  | 'Starters & Farsan'
  | 'Special Thalis'
  | 'Main Course'
  | 'Breads (Bhakri/Poli)'
  | 'Desserts'
  | 'Beverages (Solkadhi/Piyush/Taak)';

export type DietaryType = 'Pure Veg' | 'Non-Veg';

export type SpiceLevel = 1 | 2 | 3 | 4;

export type MealSession =
  | 'Breakfast / Nashta'
  | 'Lunch'
  | 'Evening Snacks'
  | 'Dinner';

export type SeatingPreference =
  | 'Indoor AC'
  | 'Outdoor Patio'
  | 'Family Booth'
  | 'Traditional Baithak Seating';

export type BookingStatus = 'Confirmed' | 'Seated' | 'Completed' | 'Cancelled';

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  marathiName?: string;
  category: MenuCategory;
  description: string;
  price: number;
  dietary: DietaryType;
  jain_friendly: boolean;
  is_thali: boolean;
  thali_type?: 'Unlimited' | 'Limited';
  thali_components?: string[];
  regional_style: RegionalCuisine;
  spice_level: SpiceLevel;
  is_chefs_special: boolean;
  in_stock: boolean;
}

export interface Review {
  id: string;
  author: string;
  city: string;
  rating: number;
  date: string;
  comment: string;
  orderedDish: string;
}

export interface Restaurant {
  id: string;
  slug: string;
  name: string;
  marathiName: string;
  city: CityHub;
  locality: string;
  address: string;
  mapsUrl: string;
  phone: string;
  hours: string;
  rating: number;
  reviewCount: number;
  costForTwo: number;
  pureVeg: boolean;
  regionalCuisines: RegionalCuisine[];
  specialtyTag: string;
  description: string;
  coverImage: string;
  galleryImages: string[];
  seatingOptions: SeatingPreference[];
  totalTablesPerSlot: number;
  reviews: Review[];
}

export interface RestaurantWithMenu extends Restaurant {
  menu: MenuItem[];
}

export interface TimeSlotAvailability {
  time: string;
  session: MealSession;
  totalTables: number;
  bookedTables: number;
  lockedTables: number;
  availableTables: number;
  status: 'Available' | 'Limited' | 'Sold Out';
}

export interface SlotLock {
  lockId: string;
  restaurantId: string;
  restaurantName: string;
  date: string;
  session: MealSession;
  time: string;
  guests: number;
  tablesRequired: number;
  seatingPreference: SeatingPreference;
  createdAt: number;
  locked_until: number;
}

export interface NotificationWebhookPayload {
  provider: 'twilio-whatsapp' | 'interakt-whatsapp' | 'gupshup-sms';
  event: 'booking.confirmed' | 'booking.reminder_2h';
  bookingId: string;
  recipientPhone: string;
  formattedWhatsAppMessage: string;
  scheduledReminderAt: string;
  dispatchedLive: boolean;
  dispatchedAt: string;
  webhookBody: {
    to: string;
    channel: 'whatsapp' | 'sms';
    templateName: string;
    variables: Record<string, string | number>;
    mapsPinUrl: string;
  };
}

export interface Booking {
  bookingId: string;
  restaurantId: string;
  restaurantName: string;
  restaurantCity: CityHub;
  restaurantLocality: string;
  restaurantAddress: string;
  mapsUrl: string;
  date: string;
  session: MealSession;
  time: string;
  guests: number;
  tablesAllocated: number;
  seatingPreference: SeatingPreference;
  guestName: string;
  guestPhone: string;
  specialRequests: string;
  notifyWhatsAppSms: boolean;
  status: BookingStatus;
  createdAt: string;
  notification?: NotificationWebhookPayload;
}
