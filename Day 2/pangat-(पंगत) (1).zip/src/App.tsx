import { Smartphone, X } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { fetchRestaurantById, fetchRestaurants } from './api';
import { BookingConfirmationModal } from './components/BookingConfirmationModal';
import { DiscoveryHome } from './components/DiscoveryHome';
import { MobileBottomBar } from './components/MobileBottomBar';
import { MyBookingsView } from './components/MyBookingsView';
import { OfflineBanner } from './components/OfflineBanner';
import { PartnerDashboardView } from './components/PartnerDashboardView';
import { RestaurantDetailView } from './components/RestaurantDetailView';
import { type ActiveRoute, TopNav } from './components/TopNav';
import type { Booking, RestaurantWithMenu } from './types';

export default function App() {
  const [route, setRoute] = useState<ActiveRoute>('discover');
  const [restaurants, setRestaurants] = useState<RestaurantWithMenu[]>([]);
  const [allRestaurants, setAllRestaurants] = useState<RestaurantWithMenu[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mobilePreviewActive, setMobilePreviewActive] = useState(false);

  // Discovery filters
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [selectedCuisine, setSelectedCuisine] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [pureVegOnly, setPureVegOnly] = useState<boolean>(false);

  // Active Restaurant & Confirmation Modal
  const [activeRestaurant, setActiveRestaurant] = useState<RestaurantWithMenu | null>(null);
  const [autoOpenBookingDrawer, setAutoOpenBookingDrawer] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const loadAll = useCallback(async () => {
    try {
      const full = await fetchRestaurants();
      setAllRestaurants(full);
    } catch {
      // handled in filtered load
    }
  }, []);

  const loadFilteredRestaurants = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchRestaurants({
        city: selectedCity,
        cuisine: selectedCuisine,
        q: searchQuery,
        pureVeg: pureVegOnly,
      });
      setRestaurants(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load restaurants.');
    } finally {
      setLoading(false);
    }
  }, [selectedCity, selectedCuisine, searchQuery, pureVegOnly]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    loadFilteredRestaurants();
  }, [loadFilteredRestaurants]);

  const handleOpenRestaurant = async (rest: RestaurantWithMenu, focusBooking = false) => {
    setAutoOpenBookingDrawer(focusBooking);
    try {
      const fresh = await fetchRestaurantById(rest.id);
      setActiveRestaurant(fresh);
    } catch {
      setActiveRestaurant(rest);
    }
    setRoute('restaurant');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleJumpToFilm = () => {
    setRoute('discover');
    window.setTimeout(() => {
      const el = document.getElementById('culinary-film');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 80);
  };

  const handleQuickBook = () => {
    if (route === 'restaurant' && activeRestaurant) {
      setAutoOpenBookingDrawer(true);
      return;
    }
    const target = restaurants[0] ?? allRestaurants[0];
    if (target) {
      handleOpenRestaurant(target, true);
    } else {
      setRoute('discover');
    }
  };

  const handleDataChanged = async () => {
    await loadAll();
    await loadFilteredRestaurants();
    if (activeRestaurant) {
      const fresh = await fetchRestaurantById(activeRestaurant.id).catch(() => null);
      if (fresh) setActiveRestaurant(fresh);
    }
  };

  const appShell = (
    <div
      className={
        mobilePreviewActive
          ? 'h-full flex flex-col bg-[#FAF7F2] text-[#1F2937] overflow-y-auto relative'
          : 'min-h-screen flex flex-col bg-[#FAF7F2] text-[#1F2937] pb-16 md:pb-0'
      }
    >
      <OfflineBanner />

      <TopNav
        activeRoute={route}
        onNavigate={(next) => {
          setRoute(next);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onJumpToFilm={handleJumpToFilm}
        onQuickBook={handleQuickBook}
        mobilePreviewActive={mobilePreviewActive}
        onToggleMobilePreview={() => setMobilePreviewActive((v) => !v)}
      />

      <main className="flex-1">
        {error && route === 'discover' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-800">
              {error}
            </div>
          </div>
        )}

        {route === 'discover' && (
          <DiscoveryHome
            restaurants={restaurants}
            loading={loading}
            selectedCity={selectedCity}
            selectedCuisine={selectedCuisine}
            searchQuery={searchQuery}
            pureVegOnly={pureVegOnly}
            onCityChange={setSelectedCity}
            onCuisineChange={setSelectedCuisine}
            onSearchChange={setSearchQuery}
            onPureVegChange={setPureVegOnly}
            onOpenRestaurant={handleOpenRestaurant}
            mobilePreviewActive={mobilePreviewActive}
            onToggleMobilePreview={() => setMobilePreviewActive((v) => !v)}
          />
        )}

        {route === 'restaurant' && activeRestaurant && (
          <RestaurantDetailView
            restaurant={activeRestaurant}
            autoOpenBookingDrawer={autoOpenBookingDrawer}
            onBack={() => {
              setRoute('discover');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onRestaurantUpdated={(updated) => {
              setActiveRestaurant(updated);
              loadFilteredRestaurants();
            }}
            onBookingConfirmed={(booking) => setConfirmedBooking(booking)}
          />
        )}

        {route === 'bookings' && (
          <MyBookingsView
            onBrowseRestaurants={() => {
              setRoute('discover');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onInspectWhatsApp={(booking) => setConfirmedBooking(booking)}
          />
        )}

        {route === 'partner' && (
          <PartnerDashboardView
            restaurants={allRestaurants.length > 0 ? allRestaurants : restaurants}
            onDataChanged={handleDataChanged}
          />
        )}
      </main>

      <footer className="border-t border-[#1F2937]/10 bg-[#F3EFE7] py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#1F2937]/70">
          <div>
            <span className="font-serif text-base font-bold text-[#5C162E]">Pangat (पंगत)</span>
            <span className="ml-2">Every Seat at Maharashtra’s Table</span>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => setRoute('discover')}
              className="hover:text-[#E65100] transition-colors"
            >
              Discover Kitchens
            </button>
            <button
              type="button"
              onClick={handleJumpToFilm}
              className="hover:text-[#E65100] transition-colors"
            >
              Culinary Film
            </button>
            <button
              type="button"
              onClick={() => setRoute('bookings')}
              className="hover:text-[#E65100] transition-colors"
            >
              My Bookings
            </button>
            <button
              type="button"
              onClick={() => setRoute('partner')}
              className="hover:text-[#E65100] transition-colors"
            >
              Partner Desk
            </button>
          </div>
        </div>
      </footer>

      {route !== 'restaurant' && (
        <MobileBottomBar
          activeRoute={route}
          onNavigate={(next) => {
            setRoute(next);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onJumpToFilm={handleJumpToFilm}
          forceShow={mobilePreviewActive}
          stickyMode={mobilePreviewActive}
        />
      )}

      {confirmedBooking && (
        <BookingConfirmationModal
          booking={confirmedBooking}
          onClose={() => setConfirmedBooking(null)}
          onViewBookings={() => {
            setConfirmedBooking(null);
            setRoute('bookings');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}
    </div>
  );

  if (mobilePreviewActive) {
    return (
      <div className="min-h-screen bg-[#1F2937] py-6 px-4 flex flex-col items-center justify-center gap-4">
        <div className="flex items-center justify-between w-full max-w-[390px] text-white">
          <div className="flex items-center gap-2 text-xs font-medium">
            <Smartphone className="h-4 w-4 text-[#F59E0B]" />
            <span>Pangat Mobile App (390px Viewport)</span>
          </div>
          <button
            type="button"
            onClick={() => setMobilePreviewActive(false)}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold transition-colors"
          >
            <X className="h-3.5 w-3.5" />
            Desktop View
          </button>
        </div>
        <div className="w-full max-w-[390px] h-[800px] max-h-[85vh] rounded-[32px] border-[8px] border-neutral-800 shadow-2xl overflow-hidden bg-[#FAF7F2]">
          <iframe
            src="/?mobile_app=1"
            title="Pangat Mobile App Preview"
            className="w-full h-full border-0 bg-[#FAF7F2]"
          />
        </div>
      </div>
    );
  }

  return appShell;
}
