import type { Booking, RestaurantWithMenu } from '../types';

export interface DriveDocSummary {
  id: string;
  name: string;
  modifiedTime?: string;
  webViewLink?: string;
}

export interface ParsedGoogleDoc {
  documentId: string;
  title: string;
  textContent: string;
  endIndex: number;
  webViewLink: string;
}

function authHeaders(accessToken: string): HeadersInit {
  return {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };
}

async function parseGoogleResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg =
      (data as { error?: { message?: string } }).error?.message ||
      `Google API error (${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export async function listGoogleDocs(
  accessToken: string,
  searchQuery = ''
): Promise<DriveDocSummary[]> {
  const escaped = searchQuery.trim().replace(/'/g, "\\'");
  const baseFilter = "mimeType='application/vnd.google-apps.document' and trashed=false";
  const q = escaped ? `${baseFilter} and name contains '${escaped}'` : baseFilter;

  const params = new URLSearchParams({
    q,
    pageSize: '25',
    orderBy: 'modifiedTime desc',
    fields: 'files(id,name,modifiedTime,webViewLink)',
  });

  const res = await fetch(`https://www.googleapis.com/drive/v3/files?${params.toString()}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const data = await parseGoogleResponse<{ files?: DriveDocSummary[] }>(res);
  return data.files ?? [];
}

export async function readGoogleDoc(
  accessToken: string,
  documentId: string
): Promise<ParsedGoogleDoc> {
  const res = await fetch(
    `https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  const doc = await parseGoogleResponse<{
    documentId: string;
    title: string;
    body?: {
      content?: Array<{
        endIndex?: number;
        paragraph?: {
          elements?: Array<{ textRun?: { content?: string } }>;
        };
      }>;
    };
  }>(res);

  const chunks: string[] = [];
  let maxEndIndex = 1;

  for (const el of doc.body?.content ?? []) {
    if (typeof el.endIndex === 'number' && el.endIndex > maxEndIndex) {
      maxEndIndex = el.endIndex;
    }
    if (el.paragraph?.elements) {
      const line = el.paragraph.elements
        .map((pe) => pe.textRun?.content ?? '')
        .join('');
      chunks.push(line);
    }
  }

  return {
    documentId: doc.documentId,
    title: doc.title,
    textContent: chunks.join(''),
    endIndex: Math.max(1, maxEndIndex - 1),
    webViewLink: `https://docs.google.com/document/d/${doc.documentId}/edit`,
  };
}

export async function createGoogleDocWithText(
  accessToken: string,
  title: string,
  bodyText: string
): Promise<ParsedGoogleDoc> {
  const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers: authHeaders(accessToken),
    body: JSON.stringify({ title }),
  });

  const created = await parseGoogleResponse<{ documentId: string; title: string }>(createRes);

  if (bodyText.trim()) {
    const updateRes = await fetch(
      `https://docs.googleapis.com/v1/documents/${encodeURIComponent(created.documentId)}:batchUpdate`,
      {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: JSON.stringify({
          requests: [
            {
              insertText: {
                location: { index: 1 },
                text: bodyText,
              },
            },
          ],
        }),
      }
    );
    await parseGoogleResponse(updateRes);
  }

  return readGoogleDoc(accessToken, created.documentId);
}

export async function appendTextToGoogleDoc(
  accessToken: string,
  documentId: string,
  textToAppend: string
): Promise<ParsedGoogleDoc> {
  const current = await readGoogleDoc(accessToken, documentId);
  const insertAt = Math.max(1, current.endIndex);
  const prefix = current.textContent.endsWith('\n') || current.textContent.length === 0 ? '' : '\n\n';

  const res = await fetch(
    `https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}:batchUpdate`,
    {
      method: 'POST',
      headers: authHeaders(accessToken),
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              location: { index: insertAt },
              text: `${prefix}${textToAppend}`,
            },
          },
        ],
      }),
    }
  );
  await parseGoogleResponse(res);
  return readGoogleDoc(accessToken, documentId);
}

export async function trashGoogleDoc(accessToken: string, documentId: string): Promise<void> {
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(documentId)}`,
    {
      method: 'PATCH',
      headers: authHeaders(accessToken),
      body: JSON.stringify({ trashed: true }),
    }
  );
  await parseGoogleResponse(res);
}

export function formatBookingForDoc(booking: Booking): string {
  return [
    `PANGAT (पंगत) — RESERVATION CONFIRMATION`,
    `Every Seat at Maharashtra's Table`,
    `--------------------------------------------------`,
    `Booking ID: ${booking.bookingId}`,
    `Status: ${booking.status}`,
    `Restaurant: ${booking.restaurantName} (${booking.restaurantLocality}, ${booking.restaurantCity})`,
    `Address: ${booking.restaurantAddress}`,
    `Google Maps Pin: ${booking.mapsUrl}`,
    ``,
    `Date & Session: ${booking.date} · ${booking.session}`,
    `Time Slot: ${booking.time}`,
    `Party Size: ${booking.guests} Guests (${booking.tablesAllocated} table(s))`,
    `Seating Preference: ${booking.seatingPreference}`,
    ``,
    `Primary Guest: ${booking.guestName}`,
    `Mobile: ${booking.guestPhone}`,
    booking.specialRequests ? `Special Requests: ${booking.specialRequests}` : '',
    ``,
    `Generated via Pangat on ${new Date().toLocaleDateString('en-IN')}`,
  ]
    .filter((line, idx, arr) => !(line === '' && arr[idx - 1] === ''))
    .join('\n');
}

export function formatRestaurantMenuForDoc(restaurant: RestaurantWithMenu): string {
  const spiceLabels: Record<number, string> = {
    1: '1/4 Mild',
    2: '2/4 Medium',
    3: '3/4 Spicy',
    4: '4/4 Kolhapuri / Saoji Fiery',
  };

  const lines: string[] = [
    `${restaurant.name} (${restaurant.marathiName}) — Digital Menu & Thali Guide`,
    `${restaurant.city} · ${restaurant.locality}`,
    `Address: ${restaurant.address}`,
    `Hours: ${restaurant.hours} | Phone: ${restaurant.phone}`,
    `Average Cost for Two: ₹${restaurant.costForTwo} | Rating: ${restaurant.rating}/5`,
    `Google Maps: ${restaurant.mapsUrl}`,
    ``,
    `SPECIALTY: ${restaurant.specialtyTag}`,
    `${restaurant.description}`,
    ``,
    `CURATED MENU`,
    `--------------------------------------------------`,
  ];

  for (const item of restaurant.menu) {
    lines.push(
      `• ${item.name}${item.marathiName ? ` (${item.marathiName})` : ''} — ₹${item.price} [${item.dietary}${item.jain_friendly ? ', Jain-Friendly' : ''}]`
    );
    lines.push(
      `  Category: ${item.category} | Spice: ${spiceLabels[item.spice_level] ?? item.spice_level} | Status: ${item.in_stock ? 'In Stock' : 'Sold Out'}`
    );
    lines.push(`  ${item.description}`);
    if (item.is_thali && item.thali_components?.length) {
      lines.push(`  ${item.thali_type ?? 'Special'} Thali Includes: ${item.thali_components.join(', ')}`);
    }
    lines.push('');
  }

  return lines.join('\n');
}
