# ShelfGrid Ops — Android (Kotlin + Jetpack Compose)

Native Android business application for quick-commerce stock tracking, inbound purchase-order (PO) analysis, product recommendations, and FEFO inventory planning.

## Included 4 Screens
1. **Welcome / Login Screen**: App title, operational summary, operator name & facility selector, and **Continue** button.
2. **Business Dashboard**: 3 summary metric cards (Inbound Fill-Rate SLA, Active Stock Runway, PO-to-Shelf Latency), navigation buttons, and interactive PO stage queue.
3. **Log Inbound PO & Stock Plan**: Interactive form with SKU quick-fill presets, live planning metrics, validation, and local persistence via `SharedPreferences`.
4. **Reports & Recommendations (`Sample Data`)**: Filterable summary list and product/inventory recommendations clearly labeled as **Sample Data**.

## How to Build the APK in Android Studio
1. Extract the downloaded ZIP archive (`shelfgrid-ops-android-kotlin.zip`).
2. Open **Android Studio** -> **Open** -> select the extracted folder.
3. Wait for Gradle Sync to download dependencies (Android Gradle Plugin 8.7.3, Kotlin 2.1.0, Jetpack Compose BOM 2025.02.00).
4. Run on an emulator/device (**Run > Run 'app'**) or generate an APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
