package com.shelfgrid.ops.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.shelfgrid.ops.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeScreen(
    operatorName: String,
    facilityName: String,
    facilityOptions: List<String>,
    onOperatorNameChange: (String) -> Unit,
    onFacilityChange: (String) -> Unit,
    onContinue: () -> Unit
) {
    var facilityMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text = "Warehouse & Dark Store Operations",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "ShelfGrid Ops",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Quick-commerce stock tracking, inbound purchase-order (PO) fill-rate analysis, FEFO inventory planning, and Golden-Zone product recommendations.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            OutlinedTextField(
                value = operatorName,
                onValueChange = onOperatorNameChange,
                label = { Text("Operator Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            ExposedDropdownMenuBox(
                expanded = facilityMenuExpanded,
                onExpandedChange = { facilityMenuExpanded = !facilityMenuExpanded }
            ) {
                OutlinedTextField(
                    value = facilityName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Assigned Facility") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = facilityMenuExpanded) },
                    modifier = Modifier
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = facilityMenuExpanded,
                    onDismissRequest = { facilityMenuExpanded = false }
                ) {
                    facilityOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                onFacilityChange(option)
                                facilityMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier.padding(top = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onContinue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Continue")
            }
            Text(
                text = "Sample warehouse dataset preloaded locally",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
fun DashboardScreen(
    facilityName: String,
    records: List<StockOrderRecord>,
    onGoToEntry: () -> Unit,
    onGoToReports: () -> Unit,
    onAdvanceStage: (String) -> Unit
) {
    val totalOrdered = records.sumOf { it.orderedQty }
    val totalAccepted = records.sumOf { it.acceptedQty }
    val fillRate = if (totalOrdered > 0) (totalAccepted.toDouble() / totalOrdered) * 100.0 else 0.0
    val totalOnHand = records.sumOf { it.currentStock }
    val totalVelocity = records.sumOf { it.dailyVelocity }
    val avgRunway = if (totalVelocity > 0) totalOnHand.toDouble() / totalVelocity else 0.0
    val avgLatency = if (records.isNotEmpty()) records.sumOf { it.dockLatencyMinutes } / records.size else 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "$facilityName · Sample Data",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Business Dashboard",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            MetricSummaryCard(
                title = "Inbound Fill-Rate SLA",
                value = "${"%.1f".format(fillRate)}%",
                subtitle = "$totalAccepted / $totalOrdered units accepted · Target > 98.0%"
            )
        }
        item {
            MetricSummaryCard(
                title = "Active Stock Runway",
                value = "${"%.1f".format(avgRunway)} days",
                subtitle = "$totalOnHand units on hand across ${records.size} SKUs"
            )
        }
        item {
            MetricSummaryCard(
                title = "PO-to-Shelf Latency",
                value = "$avgLatency min",
                subtitle = "Target < 30 min dock-to-GRN turnaround"
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onGoToEntry,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("Add PO / Stock")
                }
                OutlinedButton(
                    onClick = onGoToReports,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("View Reports")
                }
            }
        }

        items(records.take(4), key = { it.id }) { item ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.productName, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${item.platform.label} · ${item.poNumber} · ${item.stage.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (item.stage != PipelineStage.ACCEPTED_GRN) {
                        TextButton(onClick = { onAdvanceStage(item.id) }) {
                            Text("Advance")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricSummaryCard(title: String, value: String, subtitle: String) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AddStockOrderScreen(
    onSaveRecord: (StockOrderRecord) -> Unit,
    onNavigateReports: () -> Unit
) {
    var productName by remember { mutableStateOf("Amul Taaza Toned Milk 1L") }
    var skuCode by remember { mutableStateOf("SKU-1095") }
    var orderedQty by remember { mutableStateOf("320") }
    var acceptedQty by remember { mutableStateOf("316") }
    var currentStock by remember { mutableStateOf("180") }
    var dailyVelocity by remember { mutableStateOf("210") }
    var unitCost by remember { mutableStateOf("56") }
    var selectedPlatform by remember { mutableStateOf(PlatformChannel.BLINKIT) }
    var selectedZone by remember { mutableStateOf(SlottingZone.COLD_STORAGE) }
    var validationMessage by remember { mutableStateOf<String?>(null) }
    var savedPo by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Log Inbound PO & Stock Plan",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = productName,
            onValueChange = { productName = it },
            label = { Text("Product / SKU Name") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = skuCode,
            onValueChange = { skuCode = it },
            label = { Text("SKU Code") },
            modifier = Modifier.fillMaxWidth()
        )

        Text("Platform Channel", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PlatformChannel.entries.take(3).forEach { channel ->
                FilterChip(
                    selected = selectedPlatform == channel,
                    onClick = { selectedPlatform = channel },
                    label = { Text(channel.label) }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = orderedQty,
                onValueChange = { orderedQty = it },
                label = { Text("Ordered Qty") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = acceptedQty,
                onValueChange = { acceptedQty = it },
                label = { Text("Accepted GRN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = currentStock,
                onValueChange = { currentStock = it },
                label = { Text("Current Stock") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = dailyVelocity,
                onValueChange = { dailyVelocity = it },
                label = { Text("Daily Velocity") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = unitCost,
            onValueChange = { unitCost = it },
            label = { Text("Unit Cost (INR)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Text("Slotting Zone", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SlottingZone.entries.forEach { zone ->
                FilterChip(
                    selected = selectedZone == zone,
                    onClick = { selectedZone = zone },
                    label = { Text(zone.label) }
                )
            }
        }

        validationMessage?.let { msg ->
            Text(text = msg, color = MaterialTheme.colorScheme.error)
        }

        savedPo?.let { po ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Saved $po to local sample data")
                    TextButton(onClick = onNavigateReports) {
                        Text("View Reports")
                    }
                }
            }
        }

        Button(
            onClick = {
                val ord = orderedQty.toIntOrNull() ?: 0
                val acc = acceptedQty.toIntOrNull() ?: 0
                val stk = currentStock.toIntOrNull() ?: 0
                val vel = dailyVelocity.toIntOrNull() ?: 0
                val cst = unitCost.toIntOrNull() ?: 0

                if (productName.isBlank() || ord <= 0 || vel <= 0 || acc > ord) {
                    validationMessage = "Enter valid product details and quantities (Accepted <= Ordered)."
                } else {
                    validationMessage = null
                    val po = "PO-NEW-${(1000..9999).random()}"
                    onSaveRecord(
                        StockOrderRecord(
                            id = "po-user-${System.currentTimeMillis()}",
                            poNumber = po,
                            skuCode = skuCode.uppercase(),
                            productName = productName.trim(),
                            category = "Dairy & Cold Chain",
                            platform = selectedPlatform,
                            stage = PipelineStage.DOCK_ARRIVAL,
                            orderedQty = ord,
                            acceptedQty = acc,
                            currentStock = stk,
                            dailyVelocity = vel,
                            unitCostInr = cst,
                            expiryDate = "2026-12-10",
                            dockLatencyMinutes = 22,
                            slottingZone = selectedZone,
                            isUserAdded = true
                        )
                    )
                    savedPo = po
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Save to Local Sample Data")
        }
    }
}

@Composable
fun ReportsScreen(
    records: List<StockOrderRecord>,
    onResetSampleData: () -> Unit
) {
    val recommendations = remember(records) {
        SampleInventoryRepository.buildRecommendations(records)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sample Data · Warehouse Results",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Reports & Recommendations",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                TextButton(onClick = onResetSampleData) {
                    Text("Reset")
                }
            }
        }

        item {
            Text(
                text = "Summary List (Sample Data)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        items(records, key = { it.id }) { item ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(item.productName, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${item.poNumber} · ${item.platform.label} · ${item.stage.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Fill-Rate: ${"%.1f".format(item.fillRatePercent)}% · Runway: ${"%.1f".format(item.runwayDays)}d · Exp: ${item.expiryDate}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Product & Inventory Recommendations (Sample Data)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        items(recommendations, key = { it.id }) { rec ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${rec.focusArea} · ${rec.priority}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(rec.title, fontWeight = FontWeight.SemiBold)
                    Text(rec.summary, style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = rec.impactMetric,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
