package com.shelfgrid.ops

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shelfgrid.ops.model.PipelineStage
import com.shelfgrid.ops.model.SampleInventoryRepository
import com.shelfgrid.ops.ui.*

sealed class AppRoute(val route: String, val label: String, val icon: ImageVector) {
    data object Welcome : AppRoute("welcome", "Welcome", Icons.Default.Home)
    data object Dashboard : AppRoute("dashboard", "Dashboard", Icons.Default.Dashboard)
    data object Entry : AppRoute("entry", "Add Stock", Icons.Default.AddBox)
    data object Reports : AppRoute("reports", "Reports", Icons.Default.Assessment)
}

private val ShelfGridColorScheme = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    secondary = Color(0xFF0F172A),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    onSurfaceVariant = Color(0xFF475569)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = ShelfGridColorScheme) {
                ShelfGridOpsApp()
            }
        }
    }
}

@Composable
fun ShelfGridOpsApp() {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppRoute.Welcome.route

    var operatorName by remember { mutableStateOf("Aarav Mehta") }
    var facilityName by remember { mutableStateOf(SampleInventoryRepository.facilityOptions.first()) }
    var records by remember { mutableStateOf(SampleInventoryRepository.loadRecords(context)) }

    LaunchedEffect(records) {
        SampleInventoryRepository.saveRecords(context, records)
    }

    val routes = listOf(
        AppRoute.Welcome,
        AppRoute.Dashboard,
        AppRoute.Entry,
        AppRoute.Reports
    )

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                routes.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppRoute.Welcome.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(180)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(180)
                )
            }
        ) {
            composable(AppRoute.Welcome.route) {
                WelcomeScreen(
                    operatorName = operatorName,
                    facilityName = facilityName,
                    facilityOptions = SampleInventoryRepository.facilityOptions,
                    onOperatorNameChange = { operatorName = it },
                    onFacilityChange = { facilityName = it },
                    onContinue = { navController.navigate(AppRoute.Dashboard.route) }
                )
            }
            composable(AppRoute.Dashboard.route) {
                DashboardScreen(
                    facilityName = facilityName,
                    records = records,
                    onGoToEntry = { navController.navigate(AppRoute.Entry.route) },
                    onGoToReports = { navController.navigate(AppRoute.Reports.route) },
                    onAdvanceStage = { id ->
                        records = records.map { item ->
                            if (item.id != id) item
                            else {
                                val nextIdx = (item.stage.ordinal + 1).coerceAtMost(PipelineStage.entries.lastIndex)
                                val nextStage = PipelineStage.entries[nextIdx]
                                val nextStock = if (nextStage == PipelineStage.ACCEPTED_GRN && item.stage != PipelineStage.ACCEPTED_GRN) {
                                    item.currentStock + item.acceptedQty
                                } else item.currentStock
                                item.copy(stage = nextStage, currentStock = nextStock)
                            }
                        }
                    }
                )
            }
            composable(AppRoute.Entry.route) {
                AddStockOrderScreen(
                    onSaveRecord = { newRecord -> records = listOf(newRecord) + records },
                    onNavigateReports = { navController.navigate(AppRoute.Reports.route) }
                )
            }
            composable(AppRoute.Reports.route) {
                ReportsScreen(
                    records = records,
                    onResetSampleData = { records = SampleInventoryRepository.initialRecords }
                )
            }
        }
    }
}
