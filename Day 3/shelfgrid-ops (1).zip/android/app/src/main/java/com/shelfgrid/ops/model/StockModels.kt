package com.shelfgrid.ops.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

enum class PlatformChannel(val label: String) {
    BLINKIT("Blinkit"),
    ZEPTO("Zepto"),
    SWIGGY_INSTAMART("Swiggy Instamart"),
    MOTHER_HUB("Mother Hub Reserve")
}

enum class PipelineStage(val label: String) {
    DISPATCHED("Dispatched"),
    DOCK_ARRIVAL("Dock Arrival"),
    FEFO_CHECK("FEFO Check"),
    ACCEPTED_GRN("Accepted GRN")
}

enum class SlottingZone(val label: String) {
    GOLDEN_ZONE("Golden Zone"),
    STANDARD_AISLE("Standard Aisle"),
    COLD_STORAGE("Cold Storage")
}

data class StockOrderRecord(
    val id: String,
    val poNumber: String,
    val skuCode: String,
    val productName: String,
    val category: String,
    val platform: PlatformChannel,
    val stage: PipelineStage,
    val orderedQty: Int,
    val acceptedQty: Int,
    val currentStock: Int,
    val dailyVelocity: Int,
    val unitCostInr: Int,
    val expiryDate: String,
    val dockLatencyMinutes: Int,
    val slottingZone: SlottingZone,
    val isUserAdded: Boolean = false
) {
    val fillRatePercent: Double
        get() = if (orderedQty <= 0) 0.0 else min(100.0, (acceptedQty.toDouble() / orderedQty) * 100.0)

    val runwayDays: Double
        get() = if (dailyVelocity <= 0) 0.0 else currentStock.toDouble() / dailyVelocity

    fun recommendedReorderUnits(targetDays: Int = 3): Int =
        max(0, (dailyVelocity * targetDays) - currentStock)
}

data class RecommendationItem(
    val id: String,
    val title: String,
    val focusArea: String,
    val priority: String,
    val summary: String,
    val impactMetric: String,
    val skuCode: String
)

object SampleInventoryRepository {
    private const val PREFS_NAME = "shelfgrid_ops_prefs"
    private const val KEY_RECORDS = "records_json_v1"

    val facilityOptions = listOf(
        "Mumbai Mother Hub · MH-04",
        "Andheri West Dark Store · DS-112",
        "Bengaluru Indiranagar · DS-084",
        "Gurugram Cyber Hub · DS-039"
    )

    val initialRecords: List<StockOrderRecord> = listOf(
        StockOrderRecord(
            id = "po-101",
            poNumber = "PO-BLK-8412",
            skuCode = "SKU-1042",
            productName = "Amul Gold Full Cream Milk 1L",
            category = "Dairy & Cold Chain",
            platform = PlatformChannel.BLINKIT,
            stage = PipelineStage.ACCEPTED_GRN,
            orderedQty = 480,
            acceptedQty = 476,
            currentStock = 390,
            dailyVelocity = 310,
            unitCostInr = 64,
            expiryDate = "2026-11-26",
            dockLatencyMinutes = 18,
            slottingZone = SlottingZone.COLD_STORAGE
        ),
        StockOrderRecord(
            id = "po-102",
            poNumber = "PO-ZEP-3910",
            skuCode = "SKU-2088",
            productName = "Lay's India's Magic Masala 50g",
            category = "Snacks & Beverages",
            platform = PlatformChannel.ZEPTO,
            stage = PipelineStage.ACCEPTED_GRN,
            orderedQty = 720,
            acceptedQty = 720,
            currentStock = 840,
            dailyVelocity = 340,
            unitCostInr = 18,
            expiryDate = "2027-03-14",
            dockLatencyMinutes = 21,
            slottingZone = SlottingZone.GOLDEN_ZONE
        ),
        StockOrderRecord(
            id = "po-103",
            poNumber = "PO-SWG-6194",
            skuCode = "SKU-3115",
            productName = "Tata Tea Gold Rich Blend 500g",
            category = "Staples & Pantry",
            platform = PlatformChannel.SWIGGY_INSTAMART,
            stage = PipelineStage.FEFO_CHECK,
            orderedQty = 260,
            acceptedQty = 248,
            currentStock = 145,
            dailyVelocity = 115,
            unitCostInr = 265,
            expiryDate = "2027-06-30",
            dockLatencyMinutes = 29,
            slottingZone = SlottingZone.STANDARD_AISLE
        ),
        StockOrderRecord(
            id = "po-104",
            poNumber = "PO-BLK-8439",
            skuCode = "SKU-4027",
            productName = "Epigamia Natural Greek Yogurt 85g",
            category = "Dairy & Cold Chain",
            platform = PlatformChannel.BLINKIT,
            stage = PipelineStage.DOCK_ARRIVAL,
            orderedQty = 360,
            acceptedQty = 356,
            currentStock = 110,
            dailyVelocity = 140,
            unitCostInr = 45,
            expiryDate = "2026-11-28",
            dockLatencyMinutes = 26,
            slottingZone = SlottingZone.COLD_STORAGE
        ),
        StockOrderRecord(
            id = "po-105",
            poNumber = "PO-MHB-1104",
            skuCode = "SKU-5091",
            productName = "Minimalist Niacinamide Serum 30ml",
            category = "Personal Care",
            platform = PlatformChannel.MOTHER_HUB,
            stage = PipelineStage.ACCEPTED_GRN,
            orderedQty = 180,
            acceptedQty = 180,
            currentStock = 310,
            dailyVelocity = 62,
            unitCostInr = 420,
            expiryDate = "2028-01-15",
            dockLatencyMinutes = 22,
            slottingZone = SlottingZone.STANDARD_AISLE
        ),
        StockOrderRecord(
            id = "po-106",
            poNumber = "PO-ZEP-3945",
            skuCode = "SKU-2190",
            productName = "Red Bull Energy Drink 250ml",
            category = "Snacks & Beverages",
            platform = PlatformChannel.ZEPTO,
            stage = PipelineStage.DISPATCHED,
            orderedQty = 400,
            acceptedQty = 384,
            currentStock = 195,
            dailyVelocity = 165,
            unitCostInr = 98,
            expiryDate = "2027-08-20",
            dockLatencyMinutes = 33,
            slottingZone = SlottingZone.STANDARD_AISLE
        )
    )

    fun loadRecords(context: Context): List<StockOrderRecord> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_RECORDS, null) ?: return initialRecords
        return try {
            val arr = JSONArray(raw)
            if (arr.length() == 0) return initialRecords
            List(arr.length()) { index ->
                val obj = arr.getJSONObject(index)
                StockOrderRecord(
                    id = obj.getString("id"),
                    poNumber = obj.getString("poNumber"),
                    skuCode = obj.getString("skuCode"),
                    productName = obj.getString("productName"),
                    category = obj.getString("category"),
                    platform = PlatformChannel.valueOf(obj.getString("platform")),
                    stage = PipelineStage.valueOf(obj.getString("stage")),
                    orderedQty = obj.getInt("orderedQty"),
                    acceptedQty = obj.getInt("acceptedQty"),
                    currentStock = obj.getInt("currentStock"),
                    dailyVelocity = obj.getInt("dailyVelocity"),
                    unitCostInr = obj.getInt("unitCostInr"),
                    expiryDate = obj.getString("expiryDate"),
                    dockLatencyMinutes = obj.getInt("dockLatencyMinutes"),
                    slottingZone = SlottingZone.valueOf(obj.getString("slottingZone")),
                    isUserAdded = obj.optBoolean("isUserAdded", false)
                )
            }
        } catch (_: Exception) {
            initialRecords
        }
    }

    fun saveRecords(context: Context, records: List<StockOrderRecord>) {
        val arr = JSONArray()
        records.forEach { rec ->
            val obj = JSONObject().apply {
                put("id", rec.id)
                put("poNumber", rec.poNumber)
                put("skuCode", rec.skuCode)
                put("productName", rec.productName)
                put("category", rec.category)
                put("platform", rec.platform.name)
                put("stage", rec.stage.name)
                put("orderedQty", rec.orderedQty)
                put("acceptedQty", rec.acceptedQty)
                put("currentStock", rec.currentStock)
                put("dailyVelocity", rec.dailyVelocity)
                put("unitCostInr", rec.unitCostInr)
                put("expiryDate", rec.expiryDate)
                put("dockLatencyMinutes", rec.dockLatencyMinutes)
                put("slottingZone", rec.slottingZone.name)
                put("isUserAdded", rec.isUserAdded)
            }
            arr.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RECORDS, arr.toString())
            .apply()
    }

    fun buildRecommendations(records: List<StockOrderRecord>): List<RecommendationItem> {
        val list = mutableListOf<RecommendationItem>()

        records.filter { it.runwayDays < 1.5 }
            .minByOrNull { it.runwayDays }
            ?.let { low ->
                val reorder = low.recommendedReorderUnits(3)
                val ringFence = ceil(low.dailyVelocity * 0.6).toInt()
                list += RecommendationItem(
                    id = "rec-runway-${low.id}",
                    title = "Replenish & Ring-Fence ${low.productName}",
                    focusArea = "Sample Data · Inventory Planning",
                    priority = "Action Needed",
                    summary = "Runway is ${"%.1f".format(low.runwayDays)} days. Raise a mother-hub PO for $reorder units and ring-fence $ringFence units for quick-commerce commitments.",
                    impactMetric = "$reorder units for 3.0-day runway",
                    skuCode = low.skuCode
                )
            }

        records.filter { it.slottingZone == SlottingZone.STANDARD_AISLE && it.dailyVelocity >= 100 }
            .maxByOrNull { it.dailyVelocity }
            ?.let { slot ->
                list += RecommendationItem(
                    id = "rec-slot-${slot.id}",
                    title = "Move ${slot.productName} to Golden-Zone Racks",
                    focusArea = "Sample Data · Golden-Zone Slotting",
                    priority = "Optimization",
                    summary = "High daily velocity (${slot.dailyVelocity} units/day) from Standard Aisle slows pickers. Re-slot adjacent to packing counters.",
                    impactMetric = "-18s avg pick path latency",
                    skuCode = slot.skuCode
                )
            }

        records.filter { it.fillRatePercent < 98.0 }
            .minByOrNull { it.fillRatePercent }
            ?.let { sla ->
                val shortQty = max(0, sla.orderedQty - sla.acceptedQty)
                list += RecommendationItem(
                    id = "rec-sla-${sla.id}",
                    title = "Audit Short-Delivery on ${sla.poNumber}",
                    focusArea = "Sample Data · Purchase Analysis",
                    priority = "Action Needed",
                    summary = "Fill-rate is ${"%.1f".format(sla.fillRatePercent)}% ($shortQty units short). Run 3-way PO/ASN/GRN check before debit-note window closes.",
                    impactMetric = "INR ${shortQty * sla.unitCostInr} exposure",
                    skuCode = sla.skuCode
                )
            }

        return list
    }
}
