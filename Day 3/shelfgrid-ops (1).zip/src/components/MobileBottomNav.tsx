import { BarChart3, ClipboardPlus, Home, LayoutDashboard } from 'lucide-react';
import { ScreenId } from '../types/inventory';

interface MobileBottomNavProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

const MOBILE_TABS: {
  id: ScreenId;
  label: string;
  Icon: typeof Home;
}[] = [
  { id: 'welcome', label: 'Welcome', Icon: Home },
  { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { id: 'entry', label: 'Add Stock', Icon: ClipboardPlus },
  { id: 'reports', label: 'Reports', Icon: BarChart3 },
];

export function MobileBottomNav({ activeScreen, onNavigate }: MobileBottomNavProps) {
  return (
    <nav
      aria-label="Mobile bottom navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 items-center px-1"
    >
      {MOBILE_TABS.map(({ id, label, Icon }) => {
        const isActive = activeScreen === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onNavigate(id)}
            aria-current={isActive ? 'page' : undefined}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 rounded-lg transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-teal-700 ${
              isActive ? 'text-teal-800' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Icon className="w-5 h-5" strokeWidth={isActive ? 2.25 : 1.75} />
            <span className="text-[11px] font-medium tracking-tight whitespace-nowrap">
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
