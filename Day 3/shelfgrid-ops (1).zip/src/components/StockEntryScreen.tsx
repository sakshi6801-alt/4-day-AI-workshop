import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { FormEvent, useEffect, useState } from 'react';
import {
  calculateFillRate,
  calculateRecommendedReorder,
  calculateRunwayDays,
  PIPELINE_STAGES,
  QUICK_SKU_PRESETS,
} from '../data/sampleInventory';
import {
  PipelineStage,
  PlatformChannel,
  PrefillEntry,
  ScreenId,
  SkuCategory,
  SlottingZone,
  StockOrderRecord,
} from '../types/inventory';

interface StockEntryScreenProps {
  prefill: PrefillEntry | null;
  onClearPrefill: () => void;
  onSaveRecord: (record: StockOrderRecord) => void;
  onNavigate: (screen: ScreenId) => void;
}

const PLATFORMS: PlatformChannel[] = [
  'Blinkit',
  'Zepto',
  'Swiggy Instamart',
  'Mother Hub Reserve',
];

const CATEGORIES: SkuCategory[] = [
  'Dairy & Cold Chain',
  'Snacks & Beverages',
  'Staples & Pantry',
  'Personal Care',
];

const ZONES: SlottingZone[] = ['Golden Zone', 'Standard Aisle', 'Cold Storage'];

export function StockEntryScreen({
  prefill,
  onClearPrefill,
  onSaveRecord,
  onNavigate,
}: StockEntryScreenProps) {
  const [productName, setProductName] = useState('Amul Taaza Toned Milk 1L');
  const [skuCode, setSkuCode] = useState('SKU-1095');
  const [category, setCategory] = useState<SkuCategory>('Dairy & Cold Chain');
  const [platform, setPlatform] = useState<PlatformChannel>('Blinkit');
  const [stage, setStage] = useState<PipelineStage>('Dock Arrival');
  const [slottingZone, setSlottingZone] = useState<SlottingZone>('Cold Storage');
  const [orderedQty, setOrderedQty] = useState('320');
  const [acceptedQty, setAcceptedQty] = useState('316');
  const [currentStock, setCurrentStock] = useState('180');
  const [dailyVelocity, setDailyVelocity] = useState('210');
  const [unitCost, setUnitCost] = useState('56');
  const [dockLatencyMinutes, setDockLatencyMinutes] = useState('22');
  const [expiryDate, setExpiryDate] = useState('2026-12-04');

  const [errorMsg, setErrorMsg] = useState('');
  const [savedOrderPo, setSavedOrderPo] = useState<string | null>(null);

  useEffect(() => {
    if (prefill) {
      setProductName(prefill.productName);
      setSkuCode(prefill.skuCode);
      setCategory(prefill.category);
      setPlatform(prefill.platform);
      setSlottingZone(prefill.slottingZone);
      setOrderedQty(String(prefill.orderedQty));
      setAcceptedQty(String(prefill.orderedQty));
      setDailyVelocity(String(prefill.dailyVelocity));
      setUnitCost(String(prefill.unitCost));
      setStage('Dispatched');
      setSavedOrderPo(null);
      onClearPrefill();
    }
  }, [prefill, onClearPrefill]);

  const applyPreset = (preset: PrefillEntry) => {
    setProductName(preset.productName);
    setSkuCode(preset.skuCode);
    setCategory(preset.category);
    setPlatform(preset.platform);
    setSlottingZone(preset.slottingZone);
    setOrderedQty(String(preset.orderedQty));
    setAcceptedQty(String(preset.orderedQty));
    setDailyVelocity(String(preset.dailyVelocity));
    setUnitCost(String(preset.unitCost));
    setSavedOrderPo(null);
    setErrorMsg('');
  };

  // Live Planning Preview Calculations
  const parsedOrdered = Math.max(0, Number(orderedQty) || 0);
  const parsedAccepted = Math.max(0, Number(acceptedQty) || 0);
  const parsedStock = Math.max(0, Number(currentStock) || 0);
  const parsedVelocity = Math.max(0, Number(dailyVelocity) || 0);
  const parsedCost = Math.max(0, Number(unitCost) || 0);
  const parsedLatency = Math.max(0, Number(dockLatencyMinutes) || 0);

  const previewFillRate = calculateFillRate(parsedOrdered, parsedAccepted);
  const projectedStockAfterGrn = parsedStock + parsedAccepted;
  const previewRunway = calculateRunwayDays(projectedStockAfterGrn, parsedVelocity);
  const recommendedReorder = calculateRecommendedReorder(parsedStock, parsedVelocity, 3);
  const suggestedRingFence = Math.ceil(parsedVelocity * 0.6);
  const poTotalValue = parsedAccepted * parsedCost;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!productName.trim() || !skuCode.trim()) {
      setErrorMsg('Please enter both a product name and SKU code.');
      return;
    }
    if (parsedOrdered <= 0) {
      setErrorMsg('Ordered quantity must be greater than zero.');
      return;
    }
    if (parsedAccepted > parsedOrdered) {
      setErrorMsg('Accepted GRN quantity cannot exceed ordered PO quantity.');
      return;
    }
    if (parsedVelocity <= 0) {
      setErrorMsg('Daily sell-through velocity must be greater than zero.');
      return;
    }

    const prefix =
      platform === 'Blinkit'
        ? 'BLK'
        : platform === 'Zepto'
          ? 'ZEP'
          : platform === 'Swiggy Instamart'
            ? 'SWG'
            : 'MHB';
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const poNumber = `PO-${prefix}-${randomNum}`;

    const newRecord: StockOrderRecord = {
      id: `po-user-${Date.now()}`,
      poNumber,
      skuCode: skuCode.trim().toUpperCase(),
      productName: productName.trim(),
      category,
      platform,
      stage,
      orderedQty: parsedOrdered,
      acceptedQty: parsedAccepted,
      currentStock:
        stage === 'Accepted GRN' ? parsedStock + parsedAccepted : parsedStock,
      dailyVelocity: parsedVelocity,
      unitCost: parsedCost,
      expiryDate: expiryDate || '2027-03-01',
      dockLatencyMinutes: parsedLatency || 20,
      slottingZone,
      ringFencedUnits: suggestedRingFence,
      createdAt: new Date().toISOString(),
      isUserAdded: true,
    };

    onSaveRecord(newRecord);
    setSavedOrderPo(poNumber);
  };

  return (
    <section
      aria-labelledby="entry-heading"
      className="max-w-6xl mx-auto px-4 sm:px-6 py-6 lg:py-10 space-y-6"
    >
      <div>
        <p className="text-xs font-medium text-slate-500">
          Inbound PO &amp; Inventory Planning · Saves to Local Sample Data
        </p>
        <h1
          id="entry-heading"
          className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
        >
          Log Inbound PO &amp; Stock Plan
        </h1>
      </div>

      {/* Saved Confirmation Banner */}
      {savedOrderPo && (
        <div
          role="status"
          className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-emerald-950">
                Saved {savedOrderPo} to local sample data
              </p>
              <p className="text-xs text-emerald-800 mt-0.5">
                Dashboard metrics, purchase analysis, and recommendations have been updated.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="min-h-[44px] px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>View in Reports</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Interactive Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 space-y-6"
        >
          {/* Quick SKU Presets */}
          <div>
            <p className="text-xs font-medium text-slate-500 mb-2">
              Quick-Fill SKU Presets
            </p>
            <div className="flex flex-wrap gap-2">
              {QUICK_SKU_PRESETS.map((preset) => (
                <button
                  key={preset.skuCode}
                  type="button"
                  onClick={() => applyPreset(preset)}
                  className="min-h-[38px] px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  {preset.productName.split(' ').slice(0, 3).join(' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div className="sm:col-span-2">
              <label
                htmlFor="product-name"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Product / SKU Name
              </label>
              <input
                id="product-name"
                type="text"
                required
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="sku-code"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                SKU Code
              </label>
              <input
                id="sku-code"
                type="text"
                required
                value={skuCode}
                onChange={(e) => setSkuCode(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="sku-category"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Category
              </label>
              <select
                id="sku-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as SkuCategory)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="platform-select"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Platform Channel
              </label>
              <select
                id="platform-select"
                value={platform}
                onChange={(e) => setPlatform(e.target.value as PlatformChannel)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              >
                {PLATFORMS.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="stage-select"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Inbound Pipeline Stage
              </label>
              <select
                id="stage-select"
                value={stage}
                onChange={(e) => setStage(e.target.value as PipelineStage)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              >
                {PIPELINE_STAGES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="ordered-qty"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                PO Ordered Qty (Units)
              </label>
              <input
                id="ordered-qty"
                type="number"
                min={1}
                required
                value={orderedQty}
                onChange={(e) => setOrderedQty(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="accepted-qty"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Verified / Accepted GRN Qty
              </label>
              <input
                id="accepted-qty"
                type="number"
                min={0}
                required
                value={acceptedQty}
                onChange={(e) => setAcceptedQty(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="current-stock"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Current Shelf Stock (Units)
              </label>
              <input
                id="current-stock"
                type="number"
                min={0}
                required
                value={currentStock}
                onChange={(e) => setCurrentStock(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="daily-velocity"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Daily Velocity (Units / Day)
              </label>
              <input
                id="daily-velocity"
                type="number"
                min={1}
                required
                value={dailyVelocity}
                onChange={(e) => setDailyVelocity(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="unit-cost"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Unit Cost (₹)
              </label>
              <input
                id="unit-cost"
                type="number"
                min={1}
                required
                value={unitCost}
                onChange={(e) => setUnitCost(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="slotting-zone"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Slotting Zone
              </label>
              <select
                id="slotting-zone"
                value={slottingZone}
                onChange={(e) => setSlottingZone(e.target.value as SlottingZone)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              >
                {ZONES.map((z) => (
                  <option key={z} value={z}>
                    {z}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="expiry-date"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                FEFO Batch Expiry Date
              </label>
              <input
                id="expiry-date"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="dock-latency"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Dock Processing Time (min)
              </label>
              <input
                id="dock-latency"
                type="number"
                min={1}
                value={dockLatencyMinutes}
                onChange={(e) => setDockLatencyMinutes(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>
          </div>

          {errorMsg && (
            <p role="alert" className="text-sm font-medium text-red-600">
              {errorMsg}
            </p>
          )}

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              className="flex-1 min-h-[48px] px-6 py-3 bg-teal-700 hover:bg-teal-800 active:scale-[0.99] text-white text-sm font-semibold rounded-xl transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              Save to Local Sample Data
            </button>
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="min-h-[48px] px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium rounded-xl transition-colors cursor-pointer"
            >
              Back to Dashboard
            </button>
          </div>
        </form>

        {/* Live Purchase Analysis & Inventory Planning Preview */}
        <aside className="lg:col-span-5 bg-slate-900 text-slate-100 rounded-2xl p-6 sm:p-7 space-y-6">
          <div>
            <h2 className="text-base font-semibold text-white">
              Live Purchase &amp; Planning Preview
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Updates automatically from form quantities before saving
            </p>
          </div>

          <div className="divide-y divide-slate-800">
            <div className="py-3.5 flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">Calculated Fill-Rate</span>
              <span
                className={`text-lg font-bold font-mono tabular-nums ${
                  previewFillRate >= 98 ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {previewFillRate.toFixed(1)}%
              </span>
            </div>

            <div className="py-3.5 flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">Accepted PO Value</span>
              <span className="text-lg font-bold font-mono tabular-nums text-white">
                ₹{poTotalValue.toLocaleString('en-IN')}
              </span>
            </div>

            <div className="py-3.5 flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">Post-GRN Stock Runway</span>
              <span
                className={`text-lg font-bold font-mono tabular-nums ${
                  previewRunway < 1.5 ? 'text-amber-400' : 'text-white'
                }`}
              >
                {previewRunway.toFixed(1)} days
              </span>
            </div>

            <div className="py-3.5 flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">3-Day Target Reorder</span>
              <span className="text-lg font-bold font-mono tabular-nums text-white">
                {recommendedReorder.toLocaleString('en-IN')} units
              </span>
            </div>

            <div className="py-3.5 flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">Ring-Fenced Safety Stock</span>
              <span className="text-lg font-bold font-mono tabular-nums text-teal-400">
                {suggestedRingFence.toLocaleString('en-IN')} units
              </span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
            {previewFillRate < 98 ? (
              <p>
                Fill-rate is below the 98.0% platform SLA threshold. Record dock scan
                photos to dispute short-delivery debit notes.
              </p>
            ) : (
              <p>
                PO meets the 98.0% inward supply reliability target. Ring-fencing{' '}
                {suggestedRingFence} units protects dark-store availability against
                cross-channel stockouts.
              </p>
            )}
          </div>
        </aside>
      </div>
    </section>
  );
}
