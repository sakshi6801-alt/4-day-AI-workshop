import { Smartphone, WifiOff, X } from 'lucide-react';
import { useState } from 'react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export function PWAInstallButton() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className="w-full min-h-[44px] px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
      >
        <Smartphone className="w-4 h-4 text-teal-400" />
        <span>
          {isInstallable
            ? 'Install Android Mobile App'
            : isIOS
              ? 'Install Mobile App (iOS)'
              : 'Install on Android Phone'}
        </span>
      </button>

      {showGuide && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="install-guide-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2
                  id="install-guide-title"
                  className="text-base font-bold text-slate-900"
                >
                  {isIOS
                    ? 'Install ShelfGrid Ops on iPhone / iPad'
                    : 'Install ShelfGrid Ops on Android'}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Runs full-screen with offline local data support
                </p>
              </div>
              <button
                type="button"
                aria-label="Close install instructions"
                onClick={() => setShowGuide(false)}
                className="min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <ol className="text-sm text-slate-700 space-y-2 list-decimal pl-5">
                <li>Open this page in Safari on your iPhone or iPad.</li>
                <li>Tap the Share icon in the Safari toolbar.</li>
                <li>Scroll down and tap Add to Home Screen.</li>
              </ol>
            ) : (
              <ol className="text-sm text-slate-700 space-y-2 list-decimal pl-5">
                <li>
                  Open the Shared App URL in <strong>Chrome</strong> on your
                  Android phone.
                </li>
                <li>
                  Tap the Chrome <strong>⋮</strong> menu in the top-right corner.
                </li>
                <li>
                  Tap <strong>Install app</strong> (or <strong>Add to Home screen</strong>)
                  to install ShelfGrid Ops onto your phone launcher.
                </li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full min-h-[44px] px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl transition-colors cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();

  if (isOnline) {
    return null;
  }

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-5 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-700 px-3.5 py-2 text-xs font-medium text-white shadow-md"
    >
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>Offline Mode — Local sample data remains available</span>
    </div>
  );
}
