import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  RotateCcw,
  Search,
  Trash2,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  calculateFillRate,
  calculateRunwayDays,
  computeDashboardMetrics,
  generateSampleRecommendations,
  PIPELINE_STAGES,
} from '../data/sampleInventory';
import {
  PipelineStage,
  PlatformChannel,
  PrefillEntry,
  StockOrderRecord,
} from '../types/inventory';

interface ReportsScreenProps {
  records: StockOrderRecord[];
  onAdvanceStage: (id: string) => void;
  onDeleteRecord: (id: string) => void;
  onResetSampleData: () => void;
  onApplyRecommendation: (prefill: PrefillEntry) => void;
}

const PLATFORM_FILTERS: ('All' | PlatformChannel)[] = [
  'All',
  'Blinkit',
  'Zepto',
  'Swiggy Instamart',
  'Mother Hub Reserve',
];

export function ReportsScreen({
  records,
  onAdvanceStage,
  onDeleteRecord,
  onResetSampleData,
  onApplyRecommendation,
}: ReportsScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState<'All' | PlatformChannel>('All');
  const [stageFilter, setStageFilter] = useState<'All' | PipelineStage>('All');

  const filteredRecords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return records.filter((item) => {
      const matchesQuery =
        !q ||
        item.productName.toLowerCase().includes(q) ||
        item.skuCode.toLowerCase().includes(q) ||
        item.poNumber.toLowerCase().includes(q);
      const matchesPlatform =
        platformFilter === 'All' || item.platform === platformFilter;
      const matchesStage = stageFilter === 'All' || item.stage === stageFilter;
      return matchesQuery && matchesPlatform && matchesStage;
    });
  }, [records, searchQuery, platformFilter, stageFilter]);

  const metrics = useMemo(() => computeDashboardMetrics(records), [records]);
  const recommendations = useMemo(
    () => generateSampleRecommendations(records),
    [records],
  );

  return (
    <section
      aria-labelledby="reports-heading"
      className="max-w-6xl mx-auto px-4 sm:px-6 py-6 lg:py-10 space-y-8"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-teal-800">
            Sample Data · Purchase Analysis &amp; Inventory Results
          </p>
          <h1
            id="reports-heading"
            className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
          >
            Reports &amp; Recommendations
          </h1>
        </div>

        <button
          type="button"
          onClick={onResetSampleData}
          className="min-h-[44px] px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Data</span>
        </button>
      </div>

      {/* Purchase Analysis Summary Strip */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 grid grid-cols-2 lg:grid-cols-4 gap-5">
        <div>
          <p className="text-xs text-slate-500">Accepted PO Spend (Sample Data)</p>
          <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900">
            ₹{metrics.totalSpend.toLocaleString('en-IN')}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Weighted Fill-Rate SLA</p>
          <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900">
            {metrics.overallFillRate.toFixed(1)}%
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Short-Delivered Units</p>
          <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900">
            {metrics.shortUnits.toLocaleString('en-IN')} units
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Low-Runway SKUs (&lt; 1.5d)</p>
          <p className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900">
            {metrics.lowRunwayCount} of {records.length}
          </p>
        </div>
      </div>

      {/* Summary List Section */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="p-5 sm:px-6 border-b border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Stock &amp; Purchase Order Summary List (Sample Data)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Showing {filteredRecords.length} of {records.length} local sample &amp; saved entries
              </p>
            </div>

            {/* Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                aria-label="Search SKU or PO number"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search SKU, product, PO..."
                className="w-full min-h-[40px] pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
              />
            </div>
          </div>

          {/* Interactive Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div
              role="group"
              aria-label="Filter by platform"
              className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-xl"
            >
              {PLATFORM_FILTERS.map((pf) => (
                <button
                  key={pf}
                  type="button"
                  onClick={() => setPlatformFilter(pf)}
                  className={`min-h-[34px] px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    platformFilter === pf
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {pf}
                </button>
              ))}
            </div>

            <select
              aria-label="Filter by pipeline stage"
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value as 'All' | PipelineStage)}
              className="min-h-[38px] px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700"
            >
              <option value="All">All Pipeline Stages</option>
              {PIPELINE_STAGES.map((stage) => (
                <option key={stage} value={stage}>
                  {stage}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Empty State */}
        {filteredRecords.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-medium text-slate-700">
              No stock or PO entries match your current filter.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setPlatformFilter('All');
                setStageFilter('All');
              }}
              className="mt-3 min-h-[40px] px-4 py-2 text-xs font-semibold text-teal-800 bg-teal-50 rounded-xl cursor-pointer"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <>
            {/* Desktop Summary Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                    <th className="py-3 px-6">Product &amp; PO</th>
                    <th className="py-3 px-4">Channel · Zone</th>
                    <th className="py-3 px-4">Stage &amp; FEFO</th>
                    <th className="py-3 px-4 text-right">Accepted / Ord</th>
                    <th className="py-3 px-4 text-right">Fill-Rate</th>
                    <th className="py-3 px-4 text-right">Runway</th>
                    <th className="py-3 px-6 text-right">Manage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredRecords.map((item) => {
                    const fillRate = calculateFillRate(item.orderedQty, item.acceptedQty);
                    const runway = calculateRunwayDays(
                      item.currentStock,
                      item.dailyVelocity,
                    );
                    const isFinal = item.stage === 'Accepted GRN';

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-6">
                          <p className="font-medium text-slate-900">
                            {item.productName}
                          </p>
                          <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                            {item.poNumber} · {item.skuCode}
                            {item.isUserAdded ? ' · User Saved' : ''}
                          </p>
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="text-slate-800">{item.platform}</p>
                          <p className="text-xs text-slate-500">{item.slottingZone}</p>
                        </td>
                        <td className="py-3.5 px-4">
                          <p
                            className={`text-xs font-medium ${
                              isFinal ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {item.stage}
                          </p>
                          <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                            Exp {item.expiryDate}
                          </p>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-800">
                          {item.acceptedQty} / {item.orderedQty}
                        </td>
                        <td
                          className={`py-3.5 px-4 text-right font-mono tabular-nums font-medium ${
                            fillRate < 98 ? 'text-amber-700' : 'text-slate-900'
                          }`}
                        >
                          {fillRate.toFixed(1)}%
                        </td>
                        <td
                          className={`py-3.5 px-4 text-right font-mono tabular-nums font-medium ${
                            runway < 1.5 ? 'text-red-600' : 'text-slate-900'
                          }`}
                        >
                          {runway.toFixed(1)}d
                        </td>
                        <td className="py-3.5 px-6 text-right">
                          <div className="inline-flex items-center gap-2">
                            {!isFinal && (
                              <button
                                type="button"
                                onClick={() => onAdvanceStage(item.id)}
                                className="min-h-[34px] px-2.5 py-1 text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-lg cursor-pointer whitespace-nowrap"
                              >
                                Advance
                              </button>
                            )}
                            {item.isUserAdded && (
                              <button
                                type="button"
                                aria-label={`Delete ${item.productName}`}
                                onClick={() => onDeleteRecord(item.id)}
                                className="min-h-[34px] min-w-[34px] flex items-center justify-center text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Summary Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {filteredRecords.map((item) => {
                const fillRate = calculateFillRate(item.orderedQty, item.acceptedQty);
                const runway = calculateRunwayDays(item.currentStock, item.dailyVelocity);
                const isFinal = item.stage === 'Accepted GRN';

                return (
                  <div key={item.id} className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold text-slate-900">
                          {item.productName}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {item.platform} · {item.poNumber}
                          {item.isUserAdded ? ' · User Saved' : ''}
                        </p>
                      </div>
                      <span
                        className={`text-xs font-mono font-semibold tabular-nums ${
                          runway < 1.5 ? 'text-red-600' : 'text-slate-900'
                        }`}
                      >
                        {runway.toFixed(1)}d runway
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 font-mono tabular-nums">
                      <span>
                        Qty {item.acceptedQty}/{item.orderedQty}
                      </span>
                      <span>Fill {fillRate.toFixed(1)}%</span>
                      <span>Exp {item.expiryDate}</span>
                      <span>{item.stage}</span>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-1">
                      {!isFinal && (
                        <button
                          type="button"
                          onClick={() => onAdvanceStage(item.id)}
                          className="min-h-[36px] px-3 py-1 text-xs font-semibold text-teal-800 bg-teal-50 rounded-lg"
                        >
                          Advance Stage
                        </button>
                      )}
                      {item.isUserAdded && (
                        <button
                          type="button"
                          onClick={() => onDeleteRecord(item.id)}
                          className="min-h-[36px] px-3 py-1 text-xs font-medium text-red-600 bg-red-50 rounded-lg"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Product & Inventory Recommendations (Explicitly Labeled Sample Data) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <p className="text-xs font-semibold text-teal-800">
              Sample Data · Automated Operational Guidance
            </p>
            <h2 className="text-xl font-bold tracking-tight text-slate-900 mt-0.5">
              Product &amp; Inventory Planning Recommendations (Sample Data)
            </h2>
          </div>
          <span className="text-xs text-slate-500">
            Generated from local sample data
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {recommendations.map((rec) => (
            <article
              key={rec.id}
              className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between gap-3 text-xs">
                  <span className="font-medium text-slate-500">
                    Sample Data · {rec.focusArea}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 font-semibold ${
                      rec.priority === 'Action Needed'
                        ? 'text-amber-700'
                        : 'text-emerald-700'
                    }`}
                  >
                    {rec.priority === 'Action Needed' ? (
                      <AlertTriangle className="w-3.5 h-3.5" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    )}
                    {rec.priority}
                  </span>
                </div>

                <h3 className="mt-2.5 text-base font-semibold text-slate-900">
                  {rec.title}
                </h3>

                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  {rec.summary}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                <span className="text-xs font-mono font-medium text-slate-700 tabular-nums">
                  {rec.impactMetric}
                </span>

                <button
                  type="button"
                  onClick={() => {
                    const matched = records.find((r) => r.skuCode === rec.skuCode);
                    onApplyRecommendation({
                      skuCode: rec.skuCode,
                      productName: rec.skuName,
                      category: matched?.category ?? 'Dairy & Cold Chain',
                      platform: rec.platform,
                      orderedQty: rec.suggestedReorderQty,
                      dailyVelocity: matched?.dailyVelocity ?? 150,
                      unitCost: matched?.unitCost ?? 60,
                      slottingZone:
                        rec.focusArea === 'Golden-Zone Slotting'
                          ? 'Golden Zone'
                          : matched?.slottingZone ?? 'Standard Aisle',
                    });
                  }}
                  className="min-h-[40px] px-3.5 py-2 text-xs font-semibold text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span>Log Reorder PO</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
