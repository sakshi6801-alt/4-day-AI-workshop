import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ClipboardPlus,
  Clock,
  RotateCcw,
} from 'lucide-react';
import {
  calculateFillRate,
  calculateRunwayDays,
  computeDashboardMetrics,
  PIPELINE_STAGES,
} from '../data/sampleInventory';
import { OperatorProfile, ScreenId, StockOrderRecord } from '../types/inventory';

interface DashboardScreenProps {
  profile: OperatorProfile;
  records: StockOrderRecord[];
  onNavigate: (screen: ScreenId) => void;
  onAdvanceStage: (id: string) => void;
  onResetSampleData: () => void;
}

export function DashboardScreen({
  profile,
  records,
  onNavigate,
  onAdvanceStage,
  onResetSampleData,
}: DashboardScreenProps) {
  const metrics = computeDashboardMetrics(records);
  const meetsSla = metrics.overallFillRate >= 98.0;
  const meetsLatency = metrics.avgLatencyMinutes <= 30;
  const userAddedCount = records.filter((r) => r.isUserAdded).length;

  return (
    <section
      aria-labelledby="dashboard-heading"
      className="max-w-6xl mx-auto px-4 sm:px-6 py-6 lg:py-10 space-y-8"
    >
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {profile.facilityName} · {profile.operatorName || 'Operations Lead'} · Sample Data
          </p>
          <h1
            id="dashboard-heading"
            className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
          >
            Business Dashboard
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {userAddedCount > 0 && (
            <button
              type="button"
              onClick={onResetSampleData}
              className="min-h-[44px] px-3.5 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:text-slate-900 hover:bg-slate-50 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Sample Data</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => onNavigate('welcome')}
            className="min-h-[44px] px-3.5 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Switch Facility
          </button>
        </div>
      </div>

      {/* 3 Summary Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Inbound Fill-Rate SLA */}
        <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-medium text-slate-600">
                Inbound Fill-Rate SLA
              </h2>
              <span
                className={`inline-flex items-center gap-1 text-xs font-medium ${
                  meetsSla ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {meetsSla ? (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5" />
                )}
                {meetsSla ? 'On Target' : 'Below 98%'}
              </span>
            </div>
            <p className="mt-3 text-3xl font-bold font-mono tabular-nums text-slate-900">
              {metrics.overallFillRate.toFixed(1)}%
            </p>
          </div>
          <p className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 tabular-nums">
            {metrics.totalAccepted.toLocaleString('en-IN')} /{' '}
            {metrics.totalOrdered.toLocaleString('en-IN')} units accepted · Target &gt; 98.0%
          </p>
        </article>

        {/* Card 2: Active Stock Runway */}
        <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-medium text-slate-600">
                Active Stock Runway
              </h2>
              <span
                className={`inline-flex items-center gap-1 text-xs font-medium ${
                  metrics.lowRunwayCount === 0 ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {metrics.lowRunwayCount === 0 ? (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5" />
                )}
                {metrics.lowRunwayCount === 0
                  ? 'Healthy Buffer'
                  : `${metrics.lowRunwayCount} Low-Runway SKU${metrics.lowRunwayCount > 1 ? 's' : ''}`}
              </span>
            </div>
            <p className="mt-3 text-3xl font-bold font-mono tabular-nums text-slate-900">
              {metrics.avgRunwayDays.toFixed(1)}{' '}
              <span className="text-base font-medium font-sans text-slate-500">
                days
              </span>
            </p>
          </div>
          <p className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 tabular-nums">
            {metrics.totalOnHand.toLocaleString('en-IN')} units on hand across{' '}
            {records.length} active SKUs
          </p>
        </article>

        {/* Card 3: PO-to-Shelf Latency */}
        <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-medium text-slate-600">
                PO-to-Shelf Latency
              </h2>
              <span
                className={`inline-flex items-center gap-1 text-xs font-medium ${
                  meetsLatency ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                {meetsLatency ? 'Under 30 min' : 'Dock Delay'}
              </span>
            </div>
            <p className="mt-3 text-3xl font-bold font-mono tabular-nums text-slate-900">
              {metrics.avgLatencyMinutes}{' '}
              <span className="text-base font-medium font-sans text-slate-500">
                min
              </span>
            </p>
          </div>
          <p className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 tabular-nums">
            {metrics.acceptedGrnCount} of {records.length} POs at Accepted GRN · Target &lt; 30 min
          </p>
        </article>
      </div>

      {/* Primary Screen Navigation Buttons */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            Operational Actions
          </h2>
          <p className="text-sm text-slate-500">
            Log an incoming dark-store PO or review purchase analysis &amp; recommendations.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('entry')}
            className="min-h-[48px] px-5 py-2.5 bg-teal-700 hover:bg-teal-800 active:scale-[0.99] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 transition-all whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
          >
            <ClipboardPlus className="w-4 h-4" />
            <span>Add PO &amp; Stock Entry</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="min-h-[48px] px-5 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 transition-all whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
          >
            <BarChart3 className="w-4 h-4" />
            <span>View Reports &amp; Results</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Stock & PO Sync Snapshot */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Inbound PO &amp; Stock Sync Queue
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sample Data · Advance dock arrivals to Accepted GRN to release shelf inventory
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Full Report →
          </button>
        </div>

        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                <th className="py-3 px-6">PO / SKU</th>
                <th className="py-3 px-4">Platform &amp; Zone</th>
                <th className="py-3 px-4">Pipeline Stage</th>
                <th className="py-3 px-4 text-right">Fill-Rate</th>
                <th className="py-3 px-4 text-right">Runway</th>
                <th className="py-3 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {records.slice(0, 5).map((item) => {
                const fillRate = calculateFillRate(item.orderedQty, item.acceptedQty);
                const runway = calculateRunwayDays(item.currentStock, item.dailyVelocity);
                const stageIndex = PIPELINE_STAGES.indexOf(item.stage);
                const isFinal = stageIndex === PIPELINE_STAGES.length - 1;

                return (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-6">
                      <p className="font-medium text-slate-900">{item.productName}</p>
                      <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                        {item.poNumber} · {item.skuCode}
                      </p>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <p className="text-sm text-slate-800">{item.platform}</p>
                      <p className="text-xs text-slate-500">{item.slottingZone}</p>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs font-medium ${
                          isFinal ? 'text-emerald-700' : 'text-amber-700'
                        }`}
                      >
                        {item.stage}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900">
                      {fillRate.toFixed(1)}%
                    </td>
                    <td
                      className={`py-3.5 px-4 text-right font-mono tabular-nums font-medium ${
                        runway < 1.5 ? 'text-red-600' : 'text-slate-900'
                      }`}
                    >
                      {runway.toFixed(1)}d
                    </td>
                    <td className="py-3.5 px-6 text-right">
                      {isFinal ? (
                        <span className="text-xs text-slate-400">Live on App</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onAdvanceStage(item.id)}
                          className="min-h-[36px] px-3 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                        >
                          Advance Stage
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile List Rows */}
        <div className="md:hidden divide-y divide-slate-100">
          {records.slice(0, 5).map((item) => {
            const fillRate = calculateFillRate(item.orderedQty, item.acceptedQty);
            const runway = calculateRunwayDays(item.currentStock, item.dailyVelocity);
            const stageIndex = PIPELINE_STAGES.indexOf(item.stage);
            const isFinal = stageIndex === PIPELINE_STAGES.length - 1;

            return (
              <div key={item.id} className="p-4 space-y-2.5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {item.productName}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {item.platform} · {item.poNumber} · {item.stage}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-mono font-semibold tabular-nums shrink-0 ${
                      runway < 1.5 ? 'text-red-600' : 'text-slate-900'
                    }`}
                  >
                    {runway.toFixed(1)}d
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono tabular-nums">
                    Fill-Rate {fillRate.toFixed(1)}% · {item.currentStock} units
                  </span>
                  {!isFinal ? (
                    <button
                      type="button"
                      onClick={() => onAdvanceStage(item.id)}
                      className="min-h-[36px] px-3 py-1 text-xs font-semibold text-teal-800 bg-teal-50 rounded-lg"
                    >
                      Advance Stage
                    </button>
                  ) : (
                    <span className="text-emerald-700 font-medium">Live on App</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
