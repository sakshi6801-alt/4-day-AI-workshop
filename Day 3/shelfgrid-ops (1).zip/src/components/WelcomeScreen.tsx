import { ArrowRight, Boxes, Download } from 'lucide-react';
import { FACILITY_OPTIONS } from '../data/sampleInventory';
import { OperatorProfile } from '../types/inventory';
import { PWAInstallButton } from './PWAInstallButton';

interface WelcomeScreenProps {
  profile: OperatorProfile;
  onUpdateProfile: (profile: OperatorProfile) => void;
  onContinue: () => void;
}

const PIPELINE_STEPS = [
  {
    step: '01',
    title: 'Supplier Dispatch',
    detail: 'Advance Shipping Notice (ASN) logged in transit; inventory stays non-purchasable.',
  },
  {
    step: '02',
    title: 'Dark Store Dock Arrival',
    detail: 'Mobile HHT barcode scan confirms physical case count during overnight window.',
  },
  {
    step: '03',
    title: 'FEFO & Quality Check',
    detail: 'Batch manufacturing and expiry dates captured to enforce First-Expired, First-Out.',
  },
  {
    step: '04',
    title: 'Accepted GRN Sync',
    detail: 'Digital GRN releases verified units live to storefront shelves within 30 minutes.',
  },
];

export function WelcomeScreen({
  profile,
  onUpdateProfile,
  onContinue,
}: WelcomeScreenProps) {
  return (
    <section
      aria-labelledby="welcome-heading"
      className="max-w-6xl mx-auto px-4 sm:px-6 py-8 lg:py-14"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
        {/* Left Column: App Title, Brief Description, Operator Login & Continue CTA */}
        <div className="lg:col-span-6 flex flex-col justify-between bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
          <div>
            <div className="flex items-center gap-3 text-teal-800 mb-6">
              <div className="w-11 h-11 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center shrink-0">
                <Boxes className="w-6 h-6 text-teal-700" strokeWidth={1.75} />
              </div>
              <span className="text-xs font-medium text-slate-500">
                Warehouse &amp; Dark Store Operations
              </span>
            </div>

            <h1
              id="welcome-heading"
              className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 leading-[1.15] text-balance"
            >
              ShelfGrid Ops
            </h1>

            <p className="mt-4 text-base text-slate-600 leading-relaxed max-w-xl">
              Manage quick-commerce stock tracking, inbound purchase-order (PO)
              fill-rate analysis, FEFO inventory planning, and Golden-Zone product
              recommendations across mother hubs and dark stores.
            </p>

            {/* Quick Operator Sign-In Form */}
            <div className="mt-8 pt-6 border-t border-slate-100 space-y-4">
              <div>
                <label
                  htmlFor="operator-name"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Operator Name
                </label>
                <input
                  id="operator-name"
                  type="text"
                  value={profile.operatorName}
                  onChange={(e) =>
                    onUpdateProfile({ ...profile, operatorName: e.target.value })
                  }
                  placeholder="Enter operator name"
                  className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors"
                />
              </div>

              <div>
                <label
                  htmlFor="facility-select"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Assigned Facility
                </label>
                <select
                  id="facility-select"
                  value={profile.facilityName}
                  onChange={(e) =>
                    onUpdateProfile({ ...profile, facilityName: e.target.value })
                  }
                  className="w-full min-h-[44px] px-3.5 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white transition-colors"
                >
                  {FACILITY_OPTIONS.map((facility) => (
                    <option key={facility} value={facility}>
                      {facility}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
            <button
              type="button"
              onClick={onContinue}
              className="w-full min-h-[48px] px-6 py-3 bg-teal-700 hover:bg-teal-800 active:scale-[0.99] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <PWAInstallButton />
              <a
                href="/downloads/shelfgrid-ops-android-kotlin.zip"
                download="shelfgrid-ops-android-kotlin.zip"
                className="w-full min-h-[44px] px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
              >
                <Download className="w-4 h-4 text-teal-700" />
                <span>Android Kotlin Source (.zip)</span>
              </a>
            </div>
            <p className="text-xs text-slate-500 text-center">
              Install directly on Android via Chrome or open the Kotlin ZIP in Android Studio
            </p>
          </div>
        </div>

        {/* Right Column: Operational Scope & PO-to-Shelf Reference */}
        <div className="lg:col-span-6 bg-slate-900 text-slate-100 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <h2 className="text-lg font-semibold tracking-tight text-white">
              Inbound PO-to-Shelf Control Tower
            </h2>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              Prevent phantom out-of-stocks and SLA debit notes by decoupling
              in-transit dispatches from verified GRN shelf stock.
            </p>

            <div className="mt-7 divide-y divide-slate-800">
              {PIPELINE_STEPS.map((item) => (
                <div key={item.step} className="py-3.5 first:pt-0 last:pb-0 flex gap-4">
                  <span className="font-mono text-xs font-semibold text-teal-400 tabular-nums pt-0.5 shrink-0">
                    {item.step}
                  </span>
                  <div>
                    <h3 className="text-sm font-semibold text-white">{item.title}</h3>
                    <p className="mt-0.5 text-xs text-slate-300 leading-relaxed">
                      {item.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800 grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-slate-400">Fill-Rate Target</p>
              <p className="mt-1 text-xl font-bold font-mono tabular-nums text-white">
                &gt; 98.0%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Dock-to-Shelf</p>
              <p className="mt-1 text-xl font-bold font-mono tabular-nums text-white">
                &lt; 30 min
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Bin Accuracy</p>
              <p className="mt-1 text-xl font-bold font-mono tabular-nums text-white">
                99.7%
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
