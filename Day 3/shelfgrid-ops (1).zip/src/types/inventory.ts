export type ScreenId = 'welcome' | 'dashboard' | 'entry' | 'reports';

export type PlatformChannel =
  | 'Blinkit'
  | 'Zepto'
  | 'Swiggy Instamart'
  | 'Mother Hub Reserve';

export type PipelineStage =
  | 'Dispatched'
  | 'Dock Arrival'
  | 'FEFO Check'
  | 'Accepted GRN';

export type SkuCategory =
  | 'Dairy & Cold Chain'
  | 'Snacks & Beverages'
  | 'Staples & Pantry'
  | 'Personal Care';

export type SlottingZone = 'Golden Zone' | 'Standard Aisle' | 'Cold Storage';

export interface StockOrderRecord {
  id: string;
  poNumber: string;
  skuCode: string;
  productName: string;
  category: SkuCategory;
  platform: PlatformChannel;
  stage: PipelineStage;
  orderedQty: number;
  acceptedQty: number;
  currentStock: number;
  dailyVelocity: number;
  unitCost: number;
  expiryDate: string;
  dockLatencyMinutes: number;
  slottingZone: SlottingZone;
  ringFencedUnits: number;
  createdAt: string;
  isUserAdded?: boolean;
}

export interface RecommendationItem {
  id: string;
  title: string;
  focusArea: 'Golden-Zone Slotting' | 'Inventory Planning' | 'FEFO Compliance' | 'Purchase Analysis';
  priority: 'Action Needed' | 'Optimization' | 'Monitor';
  summary: string;
  impactMetric: string;
  skuName: string;
  skuCode: string;
  suggestedReorderQty: number;
  platform: PlatformChannel;
}

export interface OperatorProfile {
  operatorName: string;
  facilityName: string;
}

export interface PrefillEntry {
  skuCode: string;
  productName: string;
  category: SkuCategory;
  platform: PlatformChannel;
  orderedQty: number;
  dailyVelocity: number;
  unitCost: number;
  slottingZone: SlottingZone;
}
