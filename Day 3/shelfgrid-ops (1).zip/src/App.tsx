import { AnimatePresence, motion, MotionConfig } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import { DashboardScreen } from './components/DashboardScreen';
import { MobileBottomNav } from './components/MobileBottomNav';
import { OfflineIndicator } from './components/PWAInstallButton';
import { ReportsScreen } from './components/ReportsScreen';
import { StockEntryScreen } from './components/StockEntryScreen';
import { TopNavBar } from './components/TopNavBar';
import { WelcomeScreen } from './components/WelcomeScreen';
import {
  FACILITY_OPTIONS,
  INITIAL_SAMPLE_RECORDS,
  PIPELINE_STAGES,
} from './data/sampleInventory';
import {
  OperatorProfile,
  PrefillEntry,
  ScreenId,
  StockOrderRecord,
} from './types/inventory';

const STORAGE_KEY_RECORDS = 'shelfgrid_ops_records_v1';
const STORAGE_KEY_PROFILE = 'shelfgrid_ops_profile_v1';

function loadStoredRecords(): StockOrderRecord[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY_RECORDS);
    if (!raw) return INITIAL_SAMPLE_RECORDS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch {
    // Fallback to initial sample records if storage is unavailable
  }
  return INITIAL_SAMPLE_RECORDS;
}

function loadStoredProfile(): OperatorProfile {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY_PROFILE);
    if (raw) {
      const parsed = JSON.parse(raw) as OperatorProfile;
      if (parsed && typeof parsed.facilityName === 'string') {
        return parsed;
      }
    }
  } catch {
    // Fallback to default operator profile
  }
  return {
    operatorName: 'Aarav Mehta',
    facilityName: FACILITY_OPTIONS[0],
  };
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('welcome');
  const [records, setRecords] = useState<StockOrderRecord[]>(loadStoredRecords);
  const [profile, setProfile] = useState<OperatorProfile>(loadStoredProfile);
  const [prefill, setPrefill] = useState<PrefillEntry | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY_RECORDS, JSON.stringify(records));
    } catch {
      // Ignore storage quota errors
    }
  }, [records]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
    } catch {
      // Ignore storage quota errors
    }
  }, [profile]);

  const handleNavigate = useCallback((screen: ScreenId) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleSaveRecord = useCallback((newRecord: StockOrderRecord) => {
    setRecords((prev) => [newRecord, ...prev]);
  }, []);

  const handleAdvanceStage = useCallback((id: string) => {
    setRecords((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const idx = PIPELINE_STAGES.indexOf(item.stage);
        if (idx === -1 || idx >= PIPELINE_STAGES.length - 1) return item;
        const nextStage = PIPELINE_STAGES[idx + 1];
        const nextStock =
          nextStage === 'Accepted GRN'
            ? item.currentStock + item.acceptedQty
            : item.currentStock;
        return {
          ...item,
          stage: nextStage,
          currentStock: nextStock,
        };
      }),
    );
  }, []);

  const handleDeleteRecord = useCallback((id: string) => {
    setRecords((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const handleResetSampleData = useCallback(() => {
    setRecords(INITIAL_SAMPLE_RECORDS);
  }, []);

  const handleApplyRecommendation = useCallback(
    (entry: PrefillEntry) => {
      setPrefill(entry);
      handleNavigate('entry');
    },
    [handleNavigate],
  );

  const handleClearPrefill = useCallback(() => {
    setPrefill(null);
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
        <TopNavBar activeScreen={activeScreen} onNavigate={handleNavigate} />

        {/* Mobile Compact Brand Bar (non-sticky so mobile sticky stays < 9% via bottom nav) */}
        <div className="md:hidden px-4 pt-4 pb-1 flex items-center justify-between">
          <button
            type="button"
            onClick={() => handleNavigate('welcome')}
            className="text-base font-bold tracking-tight text-slate-900 cursor-pointer"
          >
            ShelfGrid Ops
          </button>
          <span className="text-xs text-slate-500 truncate max-w-[180px]">
            {profile.facilityName}
          </span>
        </div>

        <main className="flex-1 pb-24 md:pb-12">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeScreen}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeScreen === 'welcome' && (
                <WelcomeScreen
                  profile={profile}
                  onUpdateProfile={setProfile}
                  onContinue={() => handleNavigate('dashboard')}
                />
              )}
              {activeScreen === 'dashboard' && (
                <DashboardScreen
                  profile={profile}
                  records={records}
                  onNavigate={handleNavigate}
                  onAdvanceStage={handleAdvanceStage}
                  onResetSampleData={handleResetSampleData}
                />
              )}
              {activeScreen === 'entry' && (
                <StockEntryScreen
                  prefill={prefill}
                  onClearPrefill={handleClearPrefill}
                  onSaveRecord={handleSaveRecord}
                  onNavigate={handleNavigate}
                />
              )}
              {activeScreen === 'reports' && (
                <ReportsScreen
                  records={records}
                  onAdvanceStage={handleAdvanceStage}
                  onDeleteRecord={handleDeleteRecord}
                  onResetSampleData={handleResetSampleData}
                  onApplyRecommendation={handleApplyRecommendation}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        <MobileBottomNav activeScreen={activeScreen} onNavigate={handleNavigate} />
        <OfflineIndicator />
      </div>
    </MotionConfig>
  );
}
