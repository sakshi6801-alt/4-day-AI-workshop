import {
  PipelineStage,
  PrefillEntry,
  RecommendationItem,
  StockOrderRecord,
} from '../types/inventory';

export const PIPELINE_STAGES: PipelineStage[] = [
  'Dispatched',
  'Dock Arrival',
  'FEFO Check',
  'Accepted GRN',
];

export const FACILITY_OPTIONS = [
  'Mumbai Mother Hub · MH-04',
  'Andheri West Dark Store · DS-112',
  'Bengaluru Indiranagar · DS-084',
  'Gurugram Cyber Hub · DS-039',
];

export const INITIAL_SAMPLE_RECORDS: StockOrderRecord[] = [
  {
    id: 'po-101',
    poNumber: 'PO-BLK-8412',
    skuCode: 'SKU-1042',
    productName: 'Amul Gold Full Cream Milk 1L',
    category: 'Dairy & Cold Chain',
    platform: 'Blinkit',
    stage: 'Accepted GRN',
    orderedQty: 480,
    acceptedQty: 476,
    currentStock: 390,
    dailyVelocity: 310,
    unitCost: 64,
    expiryDate: '2026-11-26',
    dockLatencyMinutes: 18,
    slottingZone: 'Cold Storage',
    ringFencedUnits: 120,
    createdAt: '2026-11-22T05:15:00Z',
  },
  {
    id: 'po-102',
    poNumber: 'PO-ZEP-3910',
    skuCode: 'SKU-2088',
    productName: "Lay's India's Magic Masala 50g",
    category: 'Snacks & Beverages',
    platform: 'Zepto',
    stage: 'Accepted GRN',
    orderedQty: 720,
    acceptedQty: 720,
    currentStock: 840,
    dailyVelocity: 340,
    unitCost: 18,
    expiryDate: '2027-03-14',
    dockLatencyMinutes: 21,
    slottingZone: 'Golden Zone',
    ringFencedUnits: 180,
    createdAt: '2026-11-22T04:40:00Z',
  },
  {
    id: 'po-103',
    poNumber: 'PO-SWG-6194',
    skuCode: 'SKU-3115',
    productName: 'Tata Tea Gold Rich Blend 500g',
    category: 'Staples & Pantry',
    platform: 'Swiggy Instamart',
    stage: 'FEFO Check',
    orderedQty: 260,
    acceptedQty: 248,
    currentStock: 145,
    dailyVelocity: 115,
    unitCost: 265,
    expiryDate: '2027-06-30',
    dockLatencyMinutes: 29,
    slottingZone: 'Standard Aisle',
    ringFencedUnits: 60,
    createdAt: '2026-11-22T06:05:00Z',
  },
  {
    id: 'po-104',
    poNumber: 'PO-BLK-8439',
    skuCode: 'SKU-4027',
    productName: 'Epigamia Natural Greek Yogurt 85g',
    category: 'Dairy & Cold Chain',
    platform: 'Blinkit',
    stage: 'Dock Arrival',
    orderedQty: 360,
    acceptedQty: 356,
    currentStock: 110,
    dailyVelocity: 140,
    unitCost: 45,
    expiryDate: '2026-11-28',
    dockLatencyMinutes: 26,
    slottingZone: 'Cold Storage',
    ringFencedUnits: 85,
    createdAt: '2026-11-22T07:10:00Z',
  },
  {
    id: 'po-105',
    poNumber: 'PO-MHB-1104',
    skuCode: 'SKU-5091',
    productName: 'Minimalist Niacinamide Serum 30ml',
    category: 'Personal Care',
    platform: 'Mother Hub Reserve',
    stage: 'Accepted GRN',
    orderedQty: 180,
    acceptedQty: 180,
    currentStock: 310,
    dailyVelocity: 62,
    unitCost: 420,
    expiryDate: '2028-01-15',
    dockLatencyMinutes: 22,
    slottingZone: 'Standard Aisle',
    ringFencedUnits: 75,
    createdAt: '2026-11-21T23:30:00Z',
  },
  {
    id: 'po-106',
    poNumber: 'PO-ZEP-3945',
    skuCode: 'SKU-2190',
    productName: 'Red Bull Energy Drink 250ml',
    category: 'Snacks & Beverages',
    platform: 'Zepto',
    stage: 'Dispatched',
    orderedQty: 400,
    acceptedQty: 384,
    currentStock: 195,
    dailyVelocity: 165,
    unitCost: 98,
    expiryDate: '2027-08-20',
    dockLatencyMinutes: 33,
    slottingZone: 'Standard Aisle',
    ringFencedUnits: 90,
    createdAt: '2026-11-22T08:00:00Z',
  },
];

export const QUICK_SKU_PRESETS: PrefillEntry[] = [
  {
    skuCode: 'SKU-1042',
    productName: 'Amul Gold Full Cream Milk 1L',
    category: 'Dairy & Cold Chain',
    platform: 'Blinkit',
    orderedQty: 450,
    dailyVelocity: 310,
    unitCost: 64,
    slottingZone: 'Cold Storage',
  },
  {
    skuCode: 'SKU-2088',
    productName: "Lay's India's Magic Masala 50g",
    category: 'Snacks & Beverages',
    platform: 'Zepto',
    orderedQty: 600,
    dailyVelocity: 340,
    unitCost: 18,
    slottingZone: 'Golden Zone',
  },
  {
    skuCode: 'SKU-3115',
    productName: 'Tata Tea Gold Rich Blend 500g',
    category: 'Staples & Pantry',
    platform: 'Swiggy Instamart',
    orderedQty: 240,
    dailyVelocity: 115,
    unitCost: 265,
    slottingZone: 'Golden Zone',
  },
  {
    skuCode: 'SKU-4027',
    productName: 'Epigamia Natural Greek Yogurt 85g',
    category: 'Dairy & Cold Chain',
    platform: 'Blinkit',
    orderedQty: 320,
    dailyVelocity: 140,
    unitCost: 45,
    slottingZone: 'Cold Storage',
  },
];

export function calculateFillRate(orderedQty: number, acceptedQty: number): number {
  if (orderedQty <= 0) return 0;
  return Math.min(100, (acceptedQty / orderedQty) * 100);
}

export function calculateRunwayDays(currentStock: number, dailyVelocity: number): number {
  if (dailyVelocity <= 0) return 0;
  return currentStock / dailyVelocity;
}

export function calculateRecommendedReorder(
  currentStock: number,
  dailyVelocity: number,
  targetDays = 3,
): number {
  const targetUnits = Math.ceil(dailyVelocity * targetDays);
  return Math.max(0, targetUnits - currentStock);
}

export function computeDashboardMetrics(records: StockOrderRecord[]) {
  const totalOrdered = records.reduce((acc, r) => acc + r.orderedQty, 0);
  const totalAccepted = records.reduce((acc, r) => acc + r.acceptedQty, 0);
  const overallFillRate = totalOrdered > 0 ? (totalAccepted / totalOrdered) * 100 : 0;

  const totalOnHand = records.reduce((acc, r) => acc + r.currentStock, 0);
  const totalDailyVelocity = records.reduce((acc, r) => acc + r.dailyVelocity, 0);
  const avgRunwayDays = totalDailyVelocity > 0 ? totalOnHand / totalDailyVelocity : 0;

  const lowRunwayCount = records.filter(
    (r) => calculateRunwayDays(r.currentStock, r.dailyVelocity) < 1.5,
  ).length;

  const avgLatencyMinutes =
    records.length > 0
      ? Math.round(
          records.reduce((acc, r) => acc + r.dockLatencyMinutes, 0) / records.length,
        )
      : 0;

  const acceptedGrnCount = records.filter((r) => r.stage === 'Accepted GRN').length;
  const totalSpend = records.reduce(
    (acc, r) => acc + r.acceptedQty * r.unitCost,
    0,
  );
  const shortUnits = records.reduce(
    (acc, r) => acc + Math.max(0, r.orderedQty - r.acceptedQty),
    0,
  );

  return {
    overallFillRate,
    totalOrdered,
    totalAccepted,
    totalOnHand,
    avgRunwayDays,
    lowRunwayCount,
    avgLatencyMinutes,
    acceptedGrnCount,
    totalSpend,
    shortUnits,
  };
}

export function generateSampleRecommendations(
  records: StockOrderRecord[],
): RecommendationItem[] {
  const recommendations: RecommendationItem[] = [];

  // 1. Low stock runway & ring-fencing recommendation
  const lowRunway = [...records]
    .filter((r) => calculateRunwayDays(r.currentStock, r.dailyVelocity) < 1.5)
    .sort(
      (a, b) =>
        calculateRunwayDays(a.currentStock, a.dailyVelocity) -
        calculateRunwayDays(b.currentStock, b.dailyVelocity),
    )[0];

  if (lowRunway) {
    const runway = calculateRunwayDays(lowRunway.currentStock, lowRunway.dailyVelocity);
    const reorderQty = calculateRecommendedReorder(
      lowRunway.currentStock,
      lowRunway.dailyVelocity,
      3,
    );
    recommendations.push({
      id: `rec-runway-${lowRunway.id}`,
      title: `Replenish & Ring-Fence ${lowRunway.productName}`,
      focusArea: 'Inventory Planning',
      priority: 'Action Needed',
      summary: `Current dark-store runway is ${runway.toFixed(
        1,
      )} days (${lowRunway.currentStock} units vs ${lowRunway.dailyVelocity}/day velocity). Raise an overnight mother-hub PO for ${reorderQty} units and ring-fence ${Math.ceil(
        lowRunway.dailyVelocity * 0.6,
      )} units to protect quick-commerce fill rates.`,
      impactMetric: `${reorderQty} units to restore 3.0-day runway`,
      skuName: lowRunway.productName,
      skuCode: lowRunway.skuCode,
      suggestedReorderQty: reorderQty,
      platform: lowRunway.platform,
    });
  }

  // 2. Golden-Zone slotting recommendation for high-velocity items not yet in Golden Zone
  const slotCandidate = [...records]
    .filter((r) => r.slottingZone === 'Standard Aisle' && r.dailyVelocity >= 100)
    .sort((a, b) => b.dailyVelocity - a.dailyVelocity)[0];

  if (slotCandidate) {
    recommendations.push({
      id: `rec-slot-${slotCandidate.id}`,
      title: `Move ${slotCandidate.productName} to Golden-Zone Racks`,
      focusArea: 'Golden-Zone Slotting',
      priority: 'Optimization',
      summary: `Moving ${slotCandidate.dailyVelocity} units/day from Standard Aisle slows picker retrieval. Re-slot to waist-height Golden-Zone bays adjacent to packing stations to hit sub-60s pick paths.`,
      impactMetric: '-18s avg pick path latency',
      skuName: slotCandidate.productName,
      skuCode: slotCandidate.skuCode,
      suggestedReorderQty: calculateRecommendedReorder(
        slotCandidate.currentStock,
        slotCandidate.dailyVelocity,
        3,
      ) || slotCandidate.orderedQty,
      platform: slotCandidate.platform,
    });
  }

  // 3. Fill-Rate SLA / 3-way match recommendation
  const slaBreach = [...records]
    .filter((r) => calculateFillRate(r.orderedQty, r.acceptedQty) < 98.0)
    .sort(
      (a, b) =>
        calculateFillRate(a.orderedQty, a.acceptedQty) -
        calculateFillRate(b.orderedQty, b.acceptedQty),
    )[0];

  if (slaBreach) {
    const rate = calculateFillRate(slaBreach.orderedQty, slaBreach.acceptedQty);
    const shortQty = Math.max(0, slaBreach.orderedQty - slaBreach.acceptedQty);
    recommendations.push({
      id: `rec-sla-${slaBreach.id}`,
      title: `Audit Short-Delivery on ${slaBreach.poNumber}`,
      focusArea: 'Purchase Analysis',
      priority: 'Action Needed',
      summary: `Fill-rate landed at ${rate.toFixed(
        1,
      )}% (${shortQty} units short of ${slaBreach.orderedQty} ordered). Run 3-way PO/ASN/GRN match with dock scan photos before debit-note dispute window closes.`,
      impactMetric: `₹${(shortQty * slaBreach.unitCost).toLocaleString('en-IN')} exposure`,
      skuName: slaBreach.productName,
      skuCode: slaBreach.skuCode,
      suggestedReorderQty: shortQty > 0 ? shortQty : 120,
      platform: slaBreach.platform,
    });
  }

  // 4. FEFO expiry compliance recommendation
  const shortestExpiry = [...records].sort((a, b) =>
    a.expiryDate.localeCompare(b.expiryDate),
  )[0];
  if (shortestExpiry) {
    recommendations.push({
      id: `rec-fefo-${shortestExpiry.id}`,
      title: `Enforce FEFO Dispatch on ${shortestExpiry.productName}`,
      focusArea: 'FEFO Compliance',
      priority: 'Monitor',
      summary: `Earliest tracked batch expires ${shortestExpiry.expiryDate}. Keep HHT scan-enforced FEFO picking active so oldest stock clears before incoming overnight replenishment.`,
      impactMetric: 'Zero expiry shrink target',
      skuName: shortestExpiry.productName,
      skuCode: shortestExpiry.skuCode,
      suggestedReorderQty: Math.max(100, shortestExpiry.dailyVelocity * 2),
      platform: shortestExpiry.platform,
    });
  }

  return recommendations;
}
